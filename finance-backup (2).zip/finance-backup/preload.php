<?php
// preload.php - Load before anything else

// Define exit constants immediately
if (!defined('CodeIgniter\EXIT_SUCCESS')) {
    define('CodeIgniter\EXIT_SUCCESS', 0);
    define('CodeIgniter\EXIT_ERROR', 1);
    define('CodeIgniter\EXIT_CONFIG', 3);
    define('CodeIgniter\EXIT_UNKNOWN_FILE', 4);
    define('CodeIgniter\EXIT_UNKNOWN_CLASS', 5);
    define('CodeIgniter\EXIT_UNKNOWN_METHOD', 6);
    define('CodeIgniter\EXIT_USER_INPUT', 7);
    define('CodeIgniter\EXIT_DATABASE', 8);
    define('CodeIgniter\EXIT__AUTO_MIN', 9);
    define('CodeIgniter\EXIT__AUTO_MAX', 125);
}

// Set environment
if (!defined('ENVIRONMENT')) {
    define('ENVIRONMENT', 'development');
}