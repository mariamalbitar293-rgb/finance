<?php

$hostname = 'localhost';
$username = 'root';
$password = '';
$database = 'financial_system';

$conn = new mysqli($hostname, $username, $password, $database);

if ($conn->connect_error) {
    die("فشل الاتصال بقاعدة البيانات: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");

$sql = "ALTER TABLE `clients` ADD COLUMN `country` VARCHAR(100) DEFAULT NULL AFTER `phone`";

if ($conn->query($sql) === TRUE) {
    echo "✅ تم إضافة عمود 'country' بنجاح إلى جدول 'clients'\n";
} else {
    if (strpos($conn->error, 'Duplicate column name') !== false || 
        strpos($conn->error, 'already exists') !== false) {
        echo "✅ العمود 'country' موجود بالفعل في جدول 'clients'\n";
    } else {
        echo "❌ حدث خطأ: " . $conn->error . "\n";
    }
}

$conn->close();
