<?php

namespace App\Controllers;

use App\Models\AssetModel;
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;

class AssetApi extends ResourceController
{
    use ResponseTrait;

    protected $modelName = 'App\Models\AssetModel';
    protected $format    = 'json';

    public function index()
    {
        return $this->respond($this->model->getAssets());
    }

    public function stats()
    {
        return $this->respond($this->model->getStats());
    }

    private function getRequestData()
    {
        $method = strtolower($this->request->getMethod());
        $data = [];
        
        if ($method === 'post') {
            $data = $this->request->getPost();
        } else {
            $data = $this->request->getPost();
            
            if (empty($data)) {
                $data = $this->request->getVar();
                if (is_object($data)) {
                    $data = (array) $data;
                }
            }
            
            if (empty($data) && !empty($_POST)) {
                $data = $_POST;
            }
            
            if (empty($data)) {
                $rawInput = $this->request->getBody();
                if (!empty($rawInput)) {
                    $contentType = $this->request->getHeaderLine('Content-Type');
                    if (strpos($contentType, 'application/x-www-form-urlencoded') !== false) {
                        parse_str($rawInput, $parsedData);
                        if (!empty($parsedData)) {
                            $data = $parsedData;
                        }
                    }
                }
            }
        }

        if (is_array($data)) {
            foreach ($data as $key => $value) {
                if (is_string($value)) {
                    $data[$key] = trim(htmlspecialchars($value, ENT_QUOTES, 'UTF-8'));
                }
            }
        }

        return $data ?: [];
    }

    public function create()
    {
        $data = $this->getRequestData();

        $file = $this->request->getFile('image');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            $newName = $file->getRandomName();
            $file->move(WRITEPATH . 'uploads/assets', $newName);
            $data['image_url'] = 'uploads/assets/' . $newName;
        }

        $data['book_value'] = (float) ($data['book_value'] ?? 0);
        $data['market_value'] = (float) ($data['market_value'] ?? 0);
        $data['depreciation_rate'] = (float) ($data['depreciation_rate'] ?? 0);

        $required = ['name', 'type', 'purchase_date', 'book_value', 'market_value'];
        foreach ($required as $field) {
            if (empty($data[$field])) {
                return $this->fail("الحقل '$field' مطلوب.");
            }
        }
        
        if (empty($data['serial'])) {
            $data['serial'] = null;
        }

        if (!$this->model->insert($data)) {
            return $this->fail($this->model->errors());
        }

        return $this->respondCreated(['message' => 'تم إضافة الأصل بنجاح']);
    }

    public function update($id = null)
    {
        if (!$id) {
            return $this->fail('معرف الأصل مطلوب', 400);
        }

        $data = $this->getRequestData();
        
        if (empty($data) && !empty($_POST)) {
            $data = $_POST;
        }
        
        if (empty($data)) {
            log_message('error', 'Update request with empty data. Method: ' . $this->request->getMethod() . ', Content-Type: ' . $this->request->getHeaderLine('Content-Type'));
            return $this->fail('لم يتم استلام البيانات من الطلب. تأكد من إرسال البيانات بشكل صحيح.', 400);
        }

        unset($data['id']);

        $imageFile = $this->request->getFile('image');
        if ($imageFile && $imageFile->isValid() && !$imageFile->hasMoved()) {
            $uploadPath = ROOTPATH . 'public/uploads/assets';
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }

            $newName = $imageFile->getRandomName();
            $imageFile->move($uploadPath, $newName);
            $data['image_url'] = 'uploads/assets/' . $newName;

            $oldAsset = $this->model->find($id);
            if ($oldAsset && !empty($oldAsset['image_url'])) {
                $oldPath = ROOTPATH . 'public/' . $oldAsset['image_url'];
                if (file_exists($oldPath)) {
                    @unlink($oldPath);
                }
            }
        }

        if (isset($data['book_value'])) $data['book_value'] = (float)$data['book_value'];
        if (isset($data['market_value'])) $data['market_value'] = (float)$data['market_value'];
        if (isset($data['depreciation_rate'])) $data['depreciation_rate'] = (float)$data['depreciation_rate'];

        $data = array_filter($data, function($value) {
            return $value !== '' && $value !== null;
        });

        if (empty($data)) {
            return $this->respond(['status' => 'success', 'message' => 'لا توجد تغييرات للحفظ']);
        }

        if (!$this->model->update($id, $data)) {
            $errors = $this->model->errors();
            log_message('error', 'Failed to update asset: ' . json_encode($errors));
            return $this->fail($errors ?: 'فشل التحديث في قاعدة البيانات', 400);
        }

        return $this->respond(['status' => 'success', 'message' => 'تم تحديث الأصل بنجاح']);
    }

    public function delete($id = null)
    {
        if (!$id || !$this->model->find($id)) {
            return $this->failNotFound('الأصل غير موجود');
        }

        $asset = $this->model->find($id);
        if ($asset && !empty($asset['image_url'])) {
            $path = WRITEPATH . $asset['image_url'];
            if (file_exists($path)) @unlink($path);
        }

        if (!$this->model->delete($id)) {
            return $this->fail('فشل الحذف');
        }

        return $this->respondDeleted(['message' => 'تم حذف الأصل بنجاح']);
    }
}