<?php
namespace App\Controllers;

class Debug extends BaseController
{
    public function yearly()
    {
        echo "<html><body style='font-family: Arial; padding: 20px; direction: rtl;'>";
        echo "<h1>🔍 تشخيص Yearly Reports</h1>";
        
        
        echo "<h2>1. التحقق من YearlyReportModel</h2>";
        
        if (!class_exists('\App\Models\YearlyReportModel')) {
            echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px;'>";
            echo "❌ YearlyReportModel غير موجود";
            echo "</div>";
            echo "</body></html>";
            return;
        }
        
        $model = new \App\Models\YearlyReportModel();
        
        
        echo "<h2>2. معلومات الاتصال</h2>";
        $dbConfig = new \Config\Database();
        
        echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px;'>";
        echo "<strong>قاعدة البيانات:</strong> " . $dbConfig->default['database'] . "<br>";
        echo "<strong>المضيف:</strong> " . $dbConfig->default['hostname'] . "<br>";
        echo "<strong>المستخدم:</strong> " . $dbConfig->default['username'] . "<br>";
        echo "<strong>الجدول:</strong> yearly_reports<br>";
        echo "</div>";
        
        
        echo "<h2>3. اختبار قاعدة البيانات المباشر</h2>";
        
        try {
            $db = \Config\Database::connect();
            $tables = $db->listTables();
            
            if (in_array('yearly_reports', $tables)) {
                echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px;'>";
                echo "✅ جدول yearly_reports موجود";
                echo "</div>";
                
                
                $query = $db->table('yearly_reports')->get();
                $data = $query->getResultArray();
                
                echo "<h3>البيانات في الجدول (" . count($data) . " سجل):</h3>";
                
                if (count($data) > 0) {
                    echo "<table border='1' cellpadding='8' style='border-collapse: collapse; width: 100%;'>";
                    echo "<tr style='background: #343a40; color: white;'>";
                    echo "<th>ID</th><th>السنة</th><th>الإيرادات</th><th>المصروفات</th><th>الأرباح</th><th>تاريخ الإنشاء</th>";
                    echo "</tr>";
                    
                    foreach ($data as $row) {
                        echo "<tr>";
                        echo "<td>{$row['id']}</td>";
                        echo "<td><strong>{$row['year']}</strong></td>";
                        echo "<td>" . number_format($row['revenue']) . "</td>";
                        echo "<td>" . number_format($row['expenses']) . "</td>";
                        echo "<td>" . number_format($row['profit']) . "</td>";
                        echo "<td>{$row['created_at']}</td>";
                        echo "</tr>";
                    }
                    
                    echo "</table>";
                    
                    
                    echo "<h3>تفاصيل budget_data:</h3>";
                    
                    foreach ($data as $row) {
                        echo "<div style='background: #f8f9fa; padding: 10px; margin: 10px 0; border-radius: 5px;'>";
                        echo "<strong>سنة {$row['year']}:</strong><br>";
                        
                        if (!empty($row['budget_data'])) {
                            $budget = json_decode($row['budget_data'], true);
                            if (json_last_error() === JSON_ERROR_NONE && is_array($budget)) {
                                echo "<ul>";
                                foreach ($budget as $key => $value) {
                                    echo "<li>$key: " . number_format($value) . "</li>";
                                }
                                echo "</ul>";
                            } else {
                                echo "خطأ في فك JSON أو بيانات غير صالحة<br>";
                                echo "البيانات الخام: " . htmlspecialchars(substr($row['budget_data'], 0, 100)) . "...";
                            }
                        } else {
                            echo "بيانات الميزانية فارغة";
                        }
                        echo "</div>";
                    }
                } else {
                    echo "<div style='background: #fff3cd; padding: 15px; border-radius: 5px;'>";
                    echo "⚠ الجدول موجود ولكنه فارغ";
                    echo "</div>";
                }
            } else {
                echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px;'>";
                echo "❌ جدول yearly_reports غير موجود في قاعدة البيانات";
                echo "</div>";
            }
            
        } catch (\Exception $e) {
            echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px;'>";
            echo "❌ خطأ في الاتصال: " . $e->getMessage();
            echo "</div>";
        }
        
        
        echo "<h2>4. اختبار YearlyReportModel</h2>";
        
        $debugInfo = $model->debugInfo();
        
        echo "<div style='background: #e9ecef; padding: 15px; border-radius: 5px;'>";
        echo "<strong>حالة الاتصال:</strong> " . ($debugInfo['connection'] ?? 'غير معروف') . "<br>";
        echo "<strong>عدد السجلات:</strong> " . ($debugInfo['row_count'] ?? 0) . "<br>";
        echo "<strong>إصدار MySQL:</strong> " . ($debugInfo['mysql_version'] ?? 'غير معروف') . "<br>";
        echo "<strong>ترميز قاعدة البيانات:</strong> " . ($debugInfo['database_charset'] ?? 'غير معروف') . "<br>";
        echo "</div>";
        
        
        echo "<h2>5. اختبار getAvailableYears()</h2>";
        $years = $model->getAvailableYears();
        
        if (!empty($years)) {
            echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px;'>";
            echo "السنوات المتاحة (" . count($years) . " سنة):<br>";
            echo "<ul>";
            foreach ($years as $year) {
                echo "<li>سنة {$year['year']}</li>";
            }
            echo "</ul>";
            echo "</div>";
        } else {
            echo "<div style='background: #fff3cd; padding: 15px; border-radius: 5px;'>";
            echo "⚠ لم يتم العثور على سنوات";
            echo "</div>";
        }
        
        
        echo "<h2>6. اختبار getYearlyData()</h2>";
        
        $testYears = [date('Y'), date('Y')-1, date('Y')-2];
        
        foreach ($testYears as $testYear) {
            echo "<h3>بيانات سنة $testYear:</h3>";
            $yearData = $model->getYearlyData($testYear);
            
            $bgColor = isset($yearData['source']) && $yearData['source'] === 'database' ? '#d4edda' : '#fff3cd';
            
            echo "<div style='background: $bgColor; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
            echo "<strong>المصدر:</strong> " . ($yearData['source'] ?? 'غير معروف');
            
            if (isset($yearData['source']) && $yearData['source'] === 'database') {
                echo " ✅ (من قاعدة البيانات)";
            } else {
                echo " ⚠ (افتراضي)";
            }
            
            echo "<br>";
            echo "<strong>الإيرادات:</strong> " . number_format($yearData['revenue'] ?? 0) . "<br>";
            echo "<strong>المصروفات:</strong> " . number_format($yearData['expenses'] ?? 0) . "<br>";
            echo "<strong>الأرباح:</strong> " . number_format($yearData['profit'] ?? 0) . "<br>";
            
            if (isset($yearData['budget_data']) && is_array($yearData['budget_data'])) {
                echo "<strong>بيانات الميزانية:</strong><br>";
                echo "<ul>";
                foreach ($yearData['budget_data'] as $key => $value) {
                    echo "<li>$key: " . number_format($value) . "</li>";
                }
                echo "</ul>";
            }
            echo "</div>";
        }
        
        
        echo "<h2>7. إجراءات</h2>";
        
        echo "<div style='margin: 20px 0;'>";
        echo "<a href='" . site_url('debug/yearly-reset') . "' 
              onclick='return confirm(\"هل تريد حقاً إعادة تعيين البيانات؟\")'
              style='background: #dc3545; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px; margin: 5px; display: inline-block;'>
              🔄 إعادة تعيين البيانات
              </a>";
        
        echo "<a href='" . site_url('debug/yearly-add') . "'
              style='background: #28a745; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px; margin: 5px; display: inline-block;'>
              ➕ إضافة سنوات إضافية
              </a>";
        
        echo "<a href='" . site_url('dashboard/yearlyReports') . "'
              style='background: #007bff; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px; margin: 5px; display: inline-block;'>
              📊 الذهاب إلى التقارير السنوية
              </a>";
        
        echo "<a href='" . current_url() . "'
              style='background: #6c757d; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px; margin: 5px; display: inline-block;'>
              🔄 تحديث الصفحة
              </a>";
        echo "</div>";
        
        
        echo "<h2>8. سجلات النظام (logs)</h2>";
        
        $logFile = WRITEPATH . 'logs/log-' . date('Y-m-d') . '.log';
        if (file_exists($logFile)) {
            $logs = file_get_contents($logFile);
            $yearlyLogs = array_filter(explode("\n", $logs), function($line) {
                return strpos($line, 'YearlyReportModel') !== false;
            });
            
            if (!empty($yearlyLogs)) {
                echo "<div style='background: #f8f9fa; padding: 15px; border-radius: 5px; max-height: 300px; overflow-y: auto;'>";
                echo "<pre style='font-size: 12px;'>";
                foreach (array_slice($yearlyLogs, -20) as $log) {
                    echo htmlspecialchars($log) . "\n";
                }
                echo "</pre>";
                echo "</div>";
            } else {
                echo "<p>لا توجد سجلات حديثة لـ YearlyReportModel</p>";
            }
        } else {
            echo "<p>ملف السجلات غير موجود</p>";
        }
        
        echo "</body></html>";
    }
    
    public function yearlyReset()
    {
        $model = new \App\Models\YearlyReportModel();
        $result = $model->resetData();
        
        echo "<html><body style='font-family: Arial; padding: 20px; direction: rtl;'>";
        
        if ($result['success']) {
            echo "<h1 style='color: green;'>✅ " . $result['message'] . "</h1>";
        } else {
            echo "<h1 style='color: red;'>❌ " . $result['message'] . "</h1>";
        }
        
        echo "<p>سيتم إعادة التوجيه خلال 3 ثوان...</p>";
        echo "<a href='" . site_url('debug/yearly') . "'>العودة الآن</a>";
        
        echo "<script>
            setTimeout(function() {
                window.location.href = '" . site_url('debug/yearly') . "';
            }, 3000);
        </script>";
        
        echo "</body></html>";
    }
    
    public function yearlyAdd()
    {
        $model = new \App\Models\YearlyReportModel();
        
        
        $currentYear = date('Y');
        $additionalYears = [];
        
        for ($i = 3; $i < 8; $i++) {
            $year = $currentYear - $i;
            $additionalYears[] = $year;
        }
        
        foreach ($additionalYears as $year) {
            $model->getYearlyData($year);
        }
        
        echo "<html><body style='font-family: Arial; padding: 20px; direction: rtl;'>";
        echo "<h1 style='color: green;'>✅ تم إضافة سنوات إضافية</h1>";
        echo "<p>السنوات المضافة: " . implode(', ', $additionalYears) . "</p>";
        echo "<p>سيتم إعادة التوجيه خلال 3 ثوان...</p>";
        echo "<a href='" . site_url('debug/yearly') . "'>العودة الآن</a>";
        
        echo "<script>
            setTimeout(function() {
                window.location.href = '" . site_url('debug/yearly') . "';
            }, 3000);
        </script>";
        
        echo "</body></html>";
    }
}