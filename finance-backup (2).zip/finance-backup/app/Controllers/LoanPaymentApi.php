<?php

namespace App\Controllers;

use App\Models\LoanPaymentModel;
use CodeIgniter\API\ResponseTrait;

class LoanPaymentApi extends \CodeIgniter\Controller
{
    use ResponseTrait;

    protected $model;

    public function __construct()
    {
        $this->model = new LoanPaymentModel();
    }

    public function index()
    {
        $clientId = $this->request->getGet('client_id');
        if ($clientId) {
            $payments = $this->model->getClientPayments($clientId);
        } else {
            $payments = $this->model->orderBy('payment_date', 'DESC')->findAll();
        }
        return $this->respond($payments);
    }

    public function create()
    {
        $data = $this->request->getJSON(true);
        if (empty($data)) $data = $this->request->getPost();

        if (empty($data['client_id']) || empty($data['amount'])) {
            return $this->fail('معرف العميل والمبلغ مطلوبان', 400);
        }

        if (!$this->model->insert($data)) {
            return $this->fail($this->model->errors(), 400);
        }

        return $this->respondCreated(['status' => 'success', 'message' => 'تم تسجيل الدفعة بنجاح']);
    }
}
