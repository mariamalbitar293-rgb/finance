<?php

namespace App\Controllers;

use App\Models\CommitmentModel;
use CodeIgniter\API\ResponseTrait;

class CommitmentApi extends \CodeIgniter\RESTful\ResourceController
{
    use ResponseTrait;

    protected $modelName = 'App\Models\CommitmentModel';
    protected $format = 'json';

    public function index()
    {
        $commitments = $this->model->getCommitments();
        return $this->respond($commitments);
    }

    public function stats()
    {
        $stats = $this->model->getStats();
        return $this->respond($stats);
    }

    public function show($id = null)
    {
        if (empty($id)) {
            return $this->respond([
                'success' => false,
                'message' => 'معرف الالتزام مطلوب'
            ], 400);
        }

        $commitment = $this->model->find($id);
        if (!$commitment) {
            return $this->respond([
                'success' => false,
                'message' => 'الالتزام غير موجود'
            ], 404);
        }
        
        return $this->respond([
            'success' => true,
            'data' => $commitment
        ]);
    }

    public function create()
    {
        $data = $this->request->getJSON(true);

        if (empty($data['name']) || empty($data['amount']) || empty($data['payment_day']) || empty($data['start_date'])) {
            return $this->respond([
                'success' => false,
                'message' => 'الحقول المطلوبة ناقصة: الاسم، المبلغ، يوم الدفع، تاريخ البدء'
            ], 400);
        }

        $cleanData = [
            'name' => $data['name'],
            'type' => $data['type'] ?? 'monthly',
            'amount' => floatval($data['amount']),
            'payment_day' => intval($data['payment_day']),
            'start_date' => $data['start_date'],
            'end_date' => $data['end_date'] ?? null,
            'recipient' => $data['recipient'] ?? '',
            'status' => $data['status'] ?? 'active',
            'notes' => $data['notes'] ?? ''
        ];

        if ($cleanData['type'] === 'debt') {
            $cleanData['paid_amount'] = floatval($data['paid_amount'] ?? 0);
            $cleanData['monthly_payment'] = floatval($data['monthly_payment'] ?? 0);
        }

        if (!$this->model->insert($cleanData)) {
            $errors = $this->model->errors();
            return $this->respond([
                'success' => false,
                'message' => 'فشل إضافة الالتزام',
                'errors' => $errors
            ], 400);
        }

        $insertedId = $this->model->getInsertID();
        return $this->respondCreated([
            'success' => true,
            'message' => 'تم إضافة الالتزام بنجاح',
            'id' => $insertedId
        ]);
    }

    public function update($id = null)
    {
        if (empty($id)) {
            return $this->respond([
                'success' => false,
                'message' => 'معرف الالتزام مطلوب'
            ], 400);
        }

        $existing = $this->model->find($id);
        if (!$existing) {
            return $this->respond([
                'success' => false,
                'message' => 'الالتزام غير موجود'
            ], 404);
        }

        $data = $this->request->getJSON(true);

        if (empty($data)) {
            return $this->respond([
                'success' => false,
                'message' => 'لم يتم إرسال أي بيانات'
            ], 400);
        }

        $cleanData = [];
        
        if (isset($data['name'])) {
            $name = trim($data['name']);
            if (empty($name)) {
                return $this->respond([
                    'success' => false,
                    'message' => 'اسم الالتزام لا يمكن أن يكون فارغاً'
                ], 400);
            }
            $cleanData['name'] = $name;
        }
        
        if (isset($data['start_date'])) {
            if (empty($data['start_date'])) {
                return $this->respond([
                    'success' => false,
                    'message' => 'تاريخ البدء لا يمكن أن يكون فارغاً'
                ], 400);
            }
            $cleanData['start_date'] = $data['start_date'];
        }
        
        if (isset($data['amount'])) {
            $amount = floatval($data['amount']);
            if ($amount <= 0) {
                return $this->respond([
                    'success' => false,
                    'message' => 'المبلغ يجب أن يكون أكبر من صفر'
                ], 400);
            }
            $cleanData['amount'] = $amount;
        }
        
        if (isset($data['payment_day'])) {
            $paymentDay = intval($data['payment_day']);
            if ($paymentDay < 1 || $paymentDay > 31) {
                return $this->respond([
                    'success' => false,
                    'message' => 'يوم الدفع يجب أن يكون بين 1 و 31'
                ], 400);
            }
            $cleanData['payment_day'] = $paymentDay;
        }
        
        if (isset($data['type'])) $cleanData['type'] = $data['type'];
        if (isset($data['end_date'])) $cleanData['end_date'] = $data['end_date'] ?: null;
        if (isset($data['recipient'])) $cleanData['recipient'] = trim($data['recipient']);
        if (isset($data['status'])) $cleanData['status'] = $data['status'];
        if (isset($data['notes'])) $cleanData['notes'] = trim($data['notes']);

        if (isset($data['paid_amount'])) $cleanData['paid_amount'] = floatval($data['paid_amount'] ?? 0);
        if (isset($data['monthly_payment'])) $cleanData['monthly_payment'] = floatval($data['monthly_payment'] ?? 0);
        
        if (empty($cleanData)) {
            return $this->respond([
                'success' => false,
                'message' => 'لم يتم إرسال أي بيانات للتحديث'
            ], 400);
        }

        if (!$this->model->update($id, $cleanData)) {
            $errors = $this->model->errors();
            return $this->respond([
                'success' => false,
                'message' => 'فشل تحديث الالتزام',
                'errors' => $errors
            ], 400);
        }

        return $this->respond([
            'success' => true,
            'message' => 'تم تحديث الالتزام بنجاح'
        ]);
    }

    public function delete($id = null)
    {
        if (empty($id)) {
            return $this->respond([
                'success' => false,
                'message' => 'معرف الالتزام مطلوب'
            ], 400);
        }

        $existing = $this->model->find($id);
        if (!$existing) {
            return $this->respond([
                'success' => false,
                'message' => 'الالتزام غير موجود'
            ], 404);
        }

        if (!$this->model->delete($id)) {
            $errors = $this->model->errors();
            return $this->respond([
                'success' => false,
                'message' => 'فشل حذف الالتزام',
                'errors' => $errors
            ], 400);
        }

        return $this->respondDeleted([
            'success' => true,
            'message' => 'تم حذف الالتزام بنجاح'
        ]);
    }

    public function advancePayment($id = null)
    {
        if (empty($id)) {
            return $this->respond([
                'success' => false,
                'message' => 'معرف الالتزام مطلوب'
            ], 400);
        }

        $commitment = $this->model->find($id);
        if (!$commitment) {
            return $this->respond([
                'success' => false,
                'message' => 'الالتزام غير موجود'
            ], 404);
        }

        $data = $this->request->getJSON(true);
        
        if (empty($data['amount']) || floatval($data['amount']) <= 0) {
            return $this->respond([
                'success' => false,
                'message' => 'المبلغ المدفوع يجب أن يكون أكبر من صفر'
            ], 400);
        }

        $advanceAmount = floatval($data['amount']);
        $currentPaidAmount = floatval($commitment['paid_amount'] ?? 0);
        $totalAmount = floatval($commitment['amount']);
        
        $newPaidAmount = $currentPaidAmount + $advanceAmount;
        if ($newPaidAmount > $totalAmount) {
            return $this->respond([
                'success' => false,
                'message' => 'المبلغ المدفوع يتجاوز المبلغ الإجمالي للالتزام'
            ], 400);
        }

        $updateData = [
            'paid_amount' => $newPaidAmount
        ];

        if ($newPaidAmount >= $totalAmount) {
            $updateData['status'] = 'completed';
        } elseif ($commitment['status'] === 'pending') {
            $updateData['status'] = 'active';
        }

        if (!$this->model->update($id, $updateData)) {
            $errors = $this->model->errors();
            return $this->respond([
                'success' => false,
                'message' => 'فشل تسجيل الدفعة المقدمة',
                'errors' => $errors
            ], 400);
        }

        return $this->respond([
            'success' => true,
            'message' => 'تم تسجيل الدفعة المقدمة بنجاح',
            'data' => [
                'paid_amount' => $newPaidAmount,
                'remaining' => $totalAmount - $newPaidAmount,
                'status' => $updateData['status'] ?? $commitment['status']
            ]
        ]);
    }
}