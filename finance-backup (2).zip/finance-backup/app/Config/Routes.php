<?php

namespace Config;

use CodeIgniter\Router\RouteCollection;

$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Main');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override(function($message = '') {
    header('Location: /auth/login', true, 302);
    exit;
});


$routes->get('/', 'Main::index');


$routes->group('auth', function(RouteCollection $routes) {
    $routes->get('login', 'Auth::login');
    $routes->post('login', 'Auth::doLogin');
    $routes->get('register', 'Auth::register');
    $routes->post('register', 'Auth::doRegister');
    $routes->get('logout', 'Auth::logout');
});

$routes->group('dashboard', function(RouteCollection $routes) {
    $routes->get('/', 'Dashboard::index');
    $routes->get('clients', 'Dashboard::clients');
    $routes->get('yearlyReports', 'Dashboard::yearlyReports');
    $routes->get('salaries', 'Dashboard::salaries');
    $routes->get('commitments', 'Dashboard::commitments');
    $routes->get('assets', 'Dashboard::assets');
    $routes->get('monthlyReports', 'MonthlyReportController::index');
    $routes->get('monthlyReports/export', 'MonthlyReportController::exportExcel');
});


$routes->group('api', function(RouteCollection $routes) {
    // Clients API
    $routes->get('clients', 'ClientApi::index');
    $routes->post('clients', 'ClientApi::create');
    $routes->put('clients/(:num)', 'ClientApi::update/$1');
    $routes->delete('clients/(:num)', 'ClientApi::delete/$1');
    $routes->get('clients/stats', 'ClientApi::stats');

    $routes->get('loan-payments', 'LoanPaymentApi::index');
    $routes->post('loan-payments', 'LoanPaymentApi::create');

    $routes->get('salaries', 'SalaryApi::index');
    $routes->get('salaries/stats', 'SalaryApi::stats');
    $routes->post('salaries', 'SalaryApi::create');
    $routes->put('salaries/(:num)', 'SalaryApi::update/$1');
    $routes->get('salaries/(:num)', 'SalaryApi::show/$1');
    $routes->delete('salaries/(:num)', 'SalaryApi::delete/$1');

    $routes->get('commitments', 'CommitmentApi::index');
    $routes->get('commitments/stats', 'CommitmentApi::stats');
    $routes->get('commitments/(:num)', 'CommitmentApi::show/$1');
    $routes->post('commitments', 'CommitmentApi::create');
    $routes->put('commitments/(:num)', 'CommitmentApi::update/$1');
    $routes->delete('commitments/(:num)', 'CommitmentApi::delete/$1');
    $routes->post('commitments/(:num)/advance-payment', 'CommitmentApi::advancePayment/$1');

    
    $routes->get('assets', 'AssetApi::index');
    $routes->get('assets/stats', 'AssetApi::stats');
    $routes->post('assets', 'AssetApi::create');
    $routes->match(['put', 'post'], 'assets/(:num)', 'AssetApi::update/$1');
    $routes->delete('assets/(:num)', 'AssetApi::delete/$1');

    
    $routes->get('yearly', 'YearlyReportApi::index');
    $routes->get('yearly/(:num)', 'YearlyReportApi::show/$1');
    $routes->get('yearly-test', 'YearlyTest::index');
    $routes->get('yearlyReports', 'Dashboard::yearlyReports');
});