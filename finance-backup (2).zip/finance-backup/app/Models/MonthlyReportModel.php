<?php

namespace App\Models;

use CodeIgniter\Model;

class MonthlyReportModel extends Model
{
    protected $table = 'monthly_reports';
    protected $primaryKey = 'id';
    protected $allowedFields = ['year', 'month', 'total_income', 'total_expenses', 'net_profit', 'income_details', 'expense_details'];
    protected $useTimestamps = true;

    public function getOrCreateReport($year, $month, $forceRecalculate = false)
    {
        $income = $this->calculateIncome($year, $month);
        $expenses = $this->calculateExpenses($year, $month);
        
        $reportData = [
            'year' => $year,
            'month' => $month,
            'total_income' => $income['total'],
            'total_expenses' => $expenses['total'],
            'net_profit' => $income['total'] - $expenses['total'],
            'income_details' => json_encode($income['details']),
            'expense_details' => json_encode($expenses['details'])
        ];
        
        $existingReport = $this->where('year', $year)->where('month', $month)->first();
        
        if ($existingReport) {
            $this->update($existingReport['id'], $reportData);
            $reportData['id'] = $existingReport['id'];
        } else {
            $this->insert($reportData);
            $reportData['id'] = $this->getInsertID();
        }
        
        return $reportData;
    }

    private function calculateIncome($year, $month)
    {
        $clientModel = new \App\Models\ClientModel();
        $startDate = "{$year}-{$month}-01";
        $endDate = date('Y-m-t', strtotime($startDate));
        
        $clients = $clientModel->where('date >=', $startDate)
                              ->where('date <=', $endDate)
                              ->findAll();
        
        $total = 0;
        $details = [];
        
        foreach ($clients as $client) {
            $total += floatval($client['paid'] ?? 0);
        }
        
        $details['مدخولات العملاء'] = $total;
        
        return ['total' => $total, 'details' => $details];
    }

    private function calculateExpenses($year, $month)
    {
        $salaryModel = new \App\Models\SalaryModel();
        $commitmentModel = new \App\Models\CommitmentModel();
        
        $startDate = "{$year}-{$month}-01";
        $endDate = date('Y-m-t', strtotime($startDate));
        
        $salaries = $salaryModel->where('payment_date >=', $startDate)
                               ->where('payment_date <=', $endDate)
                               ->findAll();
        $salaryTotal = 0;
        foreach ($salaries as $salary) {
            $salaryTotal += floatval($salary['net_salary'] ?? 0);
        }
        
        $builder = $commitmentModel->builder();
        $commitments = $builder->where('type', 'monthly')
                              ->where('status', 'active')
                              ->where('start_date <=', $endDate)
                              ->groupStart()
                                  ->where('end_date IS NULL')
                                  ->orWhere('end_date >=', $startDate)
                              ->groupEnd()
                              ->get()
                              ->getResultArray();
        $commitmentTotal = 0;
        foreach ($commitments as $commitment) {
            $commitmentTotal += floatval($commitment['amount'] ?? 0);
        }
        
        $total = $salaryTotal + $commitmentTotal;
        
        $details = [
            'الرواتب' => $salaryTotal,
            'الالتزامات الشهرية' => $commitmentTotal,
        ];
        
        return ['total' => $total, 'details' => $details];
    }

    public function getAvailableYears()
    {
        $yearsSet = [];
        
        $monthlyYears = $this->select('year')->distinct()->orderBy('year', 'DESC')->findAll();
        foreach ($monthlyYears as $row) {
            if (isset($row['year'])) {
                $yearsSet[$row['year']] = true;
            }
        }
        
        try {
            $db = \Config\Database::connect();
            $builder = $db->table('clients');
            $clients = $builder->select('YEAR(date) as year', false)
                               ->distinct()
                               ->orderBy('year', 'DESC')
                               ->get()
                               ->getResultArray();
            foreach ($clients as $row) {
                if (isset($row['year']) && $row['year']) {
                    $yearsSet[(int)$row['year']] = true;
                }
            }
        } catch (\Exception $e) {
            log_message('error', 'Error getting years from clients: ' . $e->getMessage());
        }
        
        try {
            $db = \Config\Database::connect();
            $builder = $db->table('salaries');
            $salaries = $builder->select('YEAR(payment_date) as year', false)
                               ->distinct()
                               ->orderBy('year', 'DESC')
                               ->get()
                               ->getResultArray();
            foreach ($salaries as $row) {
                if (isset($row['year']) && $row['year']) {
                    $yearsSet[(int)$row['year']] = true;
                }
            }
        } catch (\Exception $e) {
            log_message('error', 'Error getting years from salaries: ' . $e->getMessage());
        }
        
        try {
            $yearlyModel = new \App\Models\YearlyReportModel();
            $yearlyYears = $yearlyModel->select('year')->distinct()->orderBy('year', 'DESC')->findAll();
            foreach ($yearlyYears as $row) {
                if (isset($row['year'])) {
                    $yearsSet[$row['year']] = true;
                }
            }
        } catch (\Exception $e) {
            log_message('error', 'Error getting years from yearly_reports: ' . $e->getMessage());
        }
        
        if (empty($yearsSet)) {
            $currentYear = (int)date('Y');
            for ($i = 0; $i <= 5; $i++) {
                $yearsSet[$currentYear - $i] = true;
            }
        }
        
        $years = array_keys($yearsSet);
        rsort($years);
        
        return $years;
    }
}
