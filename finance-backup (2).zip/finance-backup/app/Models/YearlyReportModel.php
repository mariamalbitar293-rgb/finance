<?php
namespace App\Models;
use CodeIgniter\Model;

class YearlyReportModel extends Model
{
    protected $table = 'yearly_reports';
    protected $primaryKey = 'id';
    protected $allowedFields = ['year', 'revenue', 'expenses', 'profit', 'budget_data'];
    protected $useTimestamps = true;
    protected $returnType = 'array';
    
    
    public function getAvailableYears()
    {
        try {
            
            log_message('info', 'YearlyReportModel: محاولة جلب السنوات من قاعدة البيانات');
            
            $builder = $this->db->table($this->table);
            
            $years = $builder->select('year')
                            ->distinct()
                            ->orderBy('year', 'DESC')
                            ->get()
                            ->getResultArray();
            
            log_message('info', 'YearlyReportModel: عدد السنوات الموجودة: ' . count($years));
            
            if (empty($years)) {
                log_message('warning', 'YearlyReportModel: لا توجد سنوات في قاعدة البيانات، ');
                $this->addDefaultYears();
                return $this->getAvailableYears(); 
            }
            
            log_message('debug', 'YearlyReportModel: السنوات: ' . json_encode($years));
            return $years;
            
        } catch (\Exception $e) {
            log_message('error', 'YearlyReportModel getAvailableYears Error: ' . $e->getMessage());
            
            $currentYear = date('Y');
            $years = [];
            for ($i = 0; $i < 5; $i++) {
                $years[] = ['year' => $currentYear - $i];
            }
            return $years;
        }
    }
    
    
    public function getYearlyData($year)
    {
        try {
            log_message('info', "YearlyReportModel: جلب بيانات سنة $year من قاعدة البيانات");
            
            $builder = $this->db->table($this->table);
            
            $data = $builder->where('year', $year)
                           ->get()
                           ->getRowArray();
            
            
            if ($data) {
                log_message('info', "YearlyReportModel: وجدت بيانات السنة $year في قاعدة البيانات");
                
                
                if (isset($data['budget_data']) && is_string($data['budget_data'])) {
                    $budgetArray = json_decode($data['budget_data'], true);
                    if (json_last_error() === JSON_ERROR_NONE) {
                        $data['budget_data'] = $budgetArray;
                    } else {
                        log_message('warning', "YearlyReportModel: خطأ في فك JSON للسنة $year");
                        $data['budget_data'] = $this->getDefaultBudgetArray();
                    }
                }
                
                
                $data['source'] = 'database';
                return $data;
                
            } else {
                log_message('warning', "YearlyReportModel: لم أجد بيانات السنة $year في قاعدة البيانات، سأضيفها");
                
                
                $newData = $this->createYearData($year);
                $this->insert($newData);
                
                $newData['source'] = 'created_and_saved';
                return $newData;
            }
            
        } catch (\Exception $e) {
            log_message('error', "YearlyReportModel getYearlyData Error for year $year: " . $e->getMessage());
            
            
            return [
                'year' => $year,
                'revenue' => $this->calculateRevenue($year),
                'expenses' => $this->calculateExpenses($year),
                'profit' => $this->calculateProfit($year),
                'budget_data' => $this->getDefaultBudgetArray(),
                'source' => 'fallback'
            ];
        }
    }
    
    
    public function getMultipleYears($years)
    {
        try {
            if (empty($years)) {
                return [];
            }
            
            $builder = $this->db->table($this->table);
            
            $data = $builder->whereIn('year', $years)
                           ->orderBy('year', 'DESC')
                           ->get()
                           ->getResultArray();
            
            $result = [];
            foreach ($data as $row) {
                
                if (isset($row['budget_data']) && is_string($row['budget_data'])) {
                    $budgetArray = json_decode($row['budget_data'], true);
                    if (json_last_error() === JSON_ERROR_NONE) {
                        $row['budget_data'] = $budgetArray;
                    }
                }
                
                $result[$row['year']] = $row;
                $result[$row['year']]['source'] = 'database';
            }
            
            
            foreach ($years as $year) {
                if (!isset($result[$year])) {
                    $result[$year] = $this->createYearData($year);
                    $result[$year]['source'] = 'created_and_saved';
                    
                    
                    $this->insert($result[$year]);
                }
            }
            
            krsort($result);
            return $result;
            
        } catch (\Exception $e) {
            log_message('error', 'YearlyReportModel getMultipleYears Error: ' . $e->getMessage());
            
            
            $currentYear = date('Y');
            $result = [];
            for ($i = 0; $i < 3; $i++) {
                $year = $currentYear - $i;
                $result[$year] = [
                    'year' => $year,
                    'revenue' => $this->calculateRevenue($year),
                    'expenses' => $this->calculateExpenses($year),
                    'profit' => $this->calculateProfit($year),
                    'budget_data' => $this->getDefaultBudgetArray(),
                    'source' => 'fallback'
                ];
            }
            
            return $result;
        }
    }
    
    
    private function addDefaultYears()
    {
        $currentYear = date('Y');
        $defaultData = [];
        
        for ($i = 0; $i < 5; $i++) {
            $year = $currentYear - $i;
            $defaultData[] = [
                'year' => $year,
                'revenue' => $this->calculateRevenue($year),
                'expenses' => $this->calculateExpenses($year),
                'profit' => $this->calculateProfit($year),
                'budget_data' => json_encode($this->getDefaultBudgetArray()),
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ];
        }
        
        try {
            $this->insertBatch($defaultData);
            log_message('info', 'YearlyReportModel: تم إضافة سنوات افتراضية إلى قاعدة البيانات');
        } catch (\Exception $e) {
            log_message('error', 'YearlyReportModel addDefaultYears Error: ' . $e->getMessage());
        }
    }
    
    
    private function createYearData($year)
    {
        return [
            'year' => $year,
            'revenue' => $this->calculateRevenue($year),
            'expenses' => $this->calculateExpenses($year),
            'profit' => $this->calculateProfit($year),
            'budget_data' => $this->getDefaultBudgetArray(),
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];
    }
    
    
    private function calculateRevenue($year)
    {
        $currentYear = date('Y');
        $baseRevenue = 34500;
        $yearsDiff = $currentYear - $year;
        
        if ($yearsDiff <= 0) {
            return $baseRevenue;
        }
        
        return round($baseRevenue * (1 - ($yearsDiff * 0.05)));
    }
    
    private function calculateExpenses($year)
    {
        $currentYear = date('Y');
        $baseExpenses = 18200;
        $yearsDiff = $currentYear - $year;
        
        if ($yearsDiff <= 0) {
            return $baseExpenses;
        }
        
        return round($baseExpenses * (1 - ($yearsDiff * 0.03)));
    }
    
    private function calculateProfit($year)
    {
        return $this->calculateRevenue($year) - $this->calculateExpenses($year);
    }
    
    private function getDefaultBudgetArray()
    {
        return [
            'salaries' => 7800,
            'operational' => 4750,
            'marketing' => 2850,
            'assets' => 2300,
            'other' => 1500
        ];
    }
    
    
    public function debugInfo()
    {
        $info = [
            'model' => 'YearlyReportModel',
            'table' => $this->table,
            'timestamp' => date('Y-m-d H:i:s')
        ];
        
        try {
            
            $builder = $this->db->table($this->table);
            $count = $builder->countAllResults();
            
            $info['connection'] = '✅ متصل';
            $info['row_count'] = $count;
            
            
            $sample = $builder->orderBy('year', 'DESC')->limit(3)->get()->getResultArray();
            
            
            foreach ($sample as &$row) {
                if (isset($row['budget_data']) && is_string($row['budget_data'])) {
                    $decoded = json_decode($row['budget_data'], true);
                    if (json_last_error() === JSON_ERROR_NONE) {
                        $row['budget_data'] = $decoded;
                    }
                }
            }
            
            $info['sample_data'] = $sample;
            
            
            $query = $this->db->query("SELECT VERSION() as version");
            $info['mysql_version'] = $query->getRow()->version ?? 'غير معروف';
            
            
            $query = $this->db->query("SHOW VARIABLES LIKE 'character_set_database'");
            $info['database_charset'] = $query->getRow()->Value ?? 'غير معروف';
            
        } catch (\Exception $e) {
            $info['connection'] = '❌ خطأ: ' . $e->getMessage();
            $info['error'] = $e->getMessage();
        }
        
        return $info;
    }
    
    
    public function testCurrentYearData()
    {
        $currentYear = date('Y');
        $data = $this->getYearlyData($currentYear);
        
        return [
            'year' => $currentYear,
            'data' => $data,
            'source' => $data['source'] ?? 'unknown',
            'is_from_database' => isset($data['source']) && $data['source'] === 'database'
        ];
    }
    
    
    public function resetData()
    {
        try {
            
            $this->db->table($this->table)->truncate();
            
            
            $this->addDefaultYears();
            
            return [
                'success' => true,
                'message' => 'تم إعادة تهيئة البيانات بنجاح'
            ];
            
        } catch (\Exception $e) {
            return [
                'success' => false,
                'message' => 'خطأ: ' . $e->getMessage()
            ];
        }
    }
}