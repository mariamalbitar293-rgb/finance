<?php

namespace App\Models;

use CodeIgniter\Model;

class CommitmentModel extends Model
{
    protected $table = 'commitments';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'name', 'type', 'amount', 'payment_day', 'start_date', 'end_date',
        'recipient', 'status', 'notes', 'paid_amount', 'monthly_payment'
    ];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    
    public function getCommitments()
    {
        return $this->orderBy('payment_day', 'ASC')->findAll();
    }

    
    public function getStats()
    {
        $builder = $this->builder();

        $monthly = $builder->selectSum('amount', 'total')
                          ->where('type', 'monthly')
                          ->where('status', 'active')
                          ->get()
                          ->getRowArray();

        $debts = $builder->select('SUM(amount) as total, SUM(paid_amount) as paid')
                        ->where('type', 'debt')
                        ->where('status', 'active')
                        ->get()
                        ->getRowArray();

        $deductions = $builder->selectSum('amount', 'total')
                             ->whereIn('type', ['deduction', 'yearly'])
                             ->where('status', 'active')
                             ->get()
                             ->getRowArray();

        $activeCount = $builder->where('status', 'active')->countAllResults();

        return [
            'total_monthly'     => $monthly['total'] ?? 0,
            'total_debts'       => ($debts['total'] ?? 0) - ($debts['paid'] ?? 0),
            'total_deductions'  => $deductions['total'] ?? 0,
            'active_count'      => $activeCount
        ];
    }
}