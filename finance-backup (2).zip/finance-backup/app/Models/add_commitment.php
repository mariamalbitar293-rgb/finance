<div class="modal-overlay" id="addCommitmentModal">
    <div class="modal">
        <div style="padding: 25px; border-bottom: 1px solid #f0f0f0; display: flex; justify-content: space-between; align-items: center;">
            <h2 style="color: var(--dark-color); margin: 0; display: flex; align-items: center; gap: 10px;">
                <i class="fas fa-hand-holding-usd"></i> ط¥ط¶ط§ظپط© ط§ظ„طھط²ط§ظ… ط¬ط¯ظٹط¯
            </h2>
            <button style="background: none; border: none; font-size: 1.5rem; color: var(--gray-color); cursor: pointer;" id="closeCommitmentModalBtn">&times;</button>
        </div>
        
        <div style="padding: 25px; max-height: 70vh; overflow-y: auto;">
            <form id="addCommitmentForm">
                <input type="hidden" id="commitmentId">
                <div style="display: flex; gap: 20px; margin-bottom: 25px; flex-wrap: wrap;">
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">ط§ط³ظ… ط§ظ„ط§ظ„طھط²ط§ظ…</label>
                        <input type="text" id="commitmentName" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" placeholder="ط£ط¯ط®ظ„ ط§ط³ظ… ط§ظ„ط§ظ„طھط²ط§ظ…" required>
                    </div>
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">ظ†ظˆط¹ ط§ظ„ط§ظ„طھط²ط§ظ…</label>
                        <select id="commitmentType" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" required>
                            <option value="monthly">ط´ظ‡ط±ظٹ</option>
                            <option value="debt">ط¯ظٹظ†</option>
                            <option value="deduction">ط®طµظ…</option>
                        </select>
                    </div>
                </div>
                
                <div style="display: flex; gap: 20px; margin-bottom: 25px; flex-wrap: wrap;">
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">ط§ظ„ظ…ط¨ظ„ط؛ (ط¯ظٹظ†ط§ط±)</label>
                        <input type="number" id="commitmentAmount" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" placeholder="ط§ظ„ظ…ط¨ظ„ط؛ ط§ظ„ط´ظ‡ط±ظٹ/ط§ظ„ط¥ط¬ظ…ط§ظ„ظٹ" required min="1">
                    </div>
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">ظٹظˆظ… ط§ظ„ط¯ظپط¹</label>
                        <input type="number" id="paymentDay" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" placeholder="ظٹظˆظ… ط§ظ„ط¯ظپط¹ ط§ظ„ط´ظ‡ط±ظٹ (1-31)" required min="1" max="31">
                    </div>
                </div>
                
                <div style="display: flex; gap: 20px; margin-bottom: 25px; flex-wrap: wrap;" id="startDateGroup">
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">طھط§ط±ظٹط® ط§ظ„ط¨ط¯ط،</label>
                        <input type="date" id="startDate" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" required>
                    </div>
                    <div style="flex: 1; min-width: 250px; display: none;" id="endDateGroup">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">طھط§ط±ظٹط® ط§ظ„ط§ظ†طھظ‡ط§ط،</label>
                        <input type="date" id="endDate" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;">
                    </div>
                </div>
                
                <div style="display: flex; gap: 20px; margin-bottom: 25px; flex-wrap: wrap;" id="debtFieldsGroup">
                    <div style="flex: 1; min-width: 250px; display: none;" id="paidAmountGroup">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">ط§ظ„ظ…ط¨ظ„ط؛ ط§ظ„ظ…ط¯ظپظˆط¹ (ط¯ظٹظ†ط§ط±)</label>
                        <input type="number" id="paidAmount" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" placeholder="ط§ظ„ظ…ط¨ظ„ط؛ ط§ظ„ط°ظٹ طھظ… ط¯ظپط¹ظ‡" min="0">
                    </div>
                    <div style="flex: 1; min-width: 250px; display: none;" id="monthlyPaymentGroup">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">ط§ظ„ط¯ظپط¹ط© ط§ظ„ط´ظ‡ط±ظٹط© (ط¯ظٹظ†ط§ط±)</label>
                        <input type="number" id="monthlyPayment" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" placeholder="ط§ظ„ط¯ظپط¹ط© ط§ظ„ط´ظ‡ط±ظٹط©" min="1">
                    </div>
                </div>
                
                <div style="display: flex; gap: 20px; margin-bottom: 25px; flex-wrap: wrap;">
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">ط§ظ„ظ…ط³طھظ„ظ…/ط§ظ„ط¯ط§ط¦ظ†</label>
                        <input type="text" id="recipient" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" placeholder="ط£ط¯ط®ظ„ ط§ط³ظ… ط§ظ„ظ…ط³طھظ„ظ… ط£ظˆ ط§ظ„ط¬ظ‡ط©">
                    </div>
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">ط§ظ„ط­ط§ظ„ط©</label>
                        <select id="status" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;">
                            <option value="active" selected>ظ†ط´ط·</option>
                            <option value="inactive">ط؛ظٹط± ظ†ط´ط·</option>
                        </select>
                    </div>
                </div>
                
                <div style="margin-bottom: 25px;">
                    <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">ظ…ظ„ط§ط­ط¸ط§طھ ط¥ط¶ط§ظپظٹط©</label>
                    <textarea id="commitmentNotes" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease; min-height: 100px;" placeholder="ط£ط¶ظپ ط£ظٹ ظ…ظ„ط§ط­ط¸ط§طھ ط­ظˆظ„ ط§ظ„ط§ظ„طھط²ط§ظ…..."></textarea>
                </div>
            </form>
        </div>
        
        <div style="padding: 20px 25px; background-color: #f8f9fa; display: flex; justify-content: flex-end; gap: 15px; border-top: 1px solid #f0f0f0;">
            <button class="btn btn-secondary" id="cancelAddCommitmentBtn">ط¥ظ„ط؛ط§ط،</button>
            <button class="btn btn-success" id="saveCommitmentBtn">
                <i class="fas fa-save"></i> ط­ظپط¸ ط§ظ„ط§ظ„طھط²ط§ظ…
            </button>
        </div>
    </div>
</div>