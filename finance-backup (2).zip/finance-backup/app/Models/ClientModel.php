<?php
namespace App\Models;

use CodeIgniter\Model;

class ClientModel extends Model
{
    protected $table = 'clients';
    protected $primaryKey = 'id';
    protected $allowedFields = ['name', 'phone', 'country', 'principal', 'paid', 'date', 'status', 'notes', 'monthly_payment', 'installment_duration_months', 'loan_start_date'];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
    
    public function getStats()
    {
        $builder = $this->db->table($this->table);
        
        $stats = [
            'total_principal' => 0,
            'total_paid' => 0,
            'total_remaining' => 0,
            'total_clients' => 0
        ];
        
        $result = $builder->selectSum('principal', 'total_principal')
                         ->selectSum('paid', 'total_paid')
                         ->selectCount('id', 'total_clients')
                         ->get()
                         ->getRowArray();
        
        if ($result) {
            $stats['total_principal'] = $result['total_principal'] ?? 0;
            $stats['total_paid'] = $result['total_paid'] ?? 0;
            $stats['total_remaining'] = $stats['total_principal'] - $stats['total_paid'];
            $stats['total_clients'] = $result['total_clients'] ?? 0;
        }
        
        return $stats;
    }
}