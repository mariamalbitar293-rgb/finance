<?= $this->extend('layouts/main') ?>

<?= $this->section('title') ?>
العملاء
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="content-wrapper">
    <div class="content-header">
        <div class="header-actions">
            <div class="search-box">
                <i class="fas fa-search"></i>
                <input type="text" id="clientSearch" placeholder="ابحث بالاسم أو الهاتف أو الدولة أو الملاحظات...">
            </div>
            
            <div class="filter-box" style="margin-right: 15px;">
                <select id="statusFilter" class="form-select">
                    <option value="all">جميع الحالات</option>
                    <option value="paid">مسددون بالكامل</option>
                    <option value="partial">مسددون جزئياً</option>
                    <option value="pending">غير مسددين</option>
                </select>
            </div>
            
            <div class="action-buttons">
                <button class="btn btn-primary" id="addClientBtn">
                    <i class="fas fa-user-plus"></i> إضافة عميل
                </button>
            </div>
        </div>
    </div>
    
    <div class="content-body">
        
        <div class="stats-cards">
            <div class="stat-card">
                <div class="stat-icon" style="background-color: rgba(41, 128, 185, 0.1); color: #2980b9;">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-info">
                    <h3 id="totalClients">0</h3>
                    <span>إجمالي العملاء</span>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon" style="background-color: rgba(39, 174, 96, 0.1); color: #27ae60;">
                    <i class="fas fa-money-bill-wave"></i>
                </div>
                <div class="stat-info">
                    <h3 id="totalPrincipal">0</h3>
                    <span>إجمالي المبالغ</span>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon" style="background-color: rgba(52, 152, 219, 0.1); color: #3498db;">
                    <i class="fas fa-hand-holding-usd"></i>
                </div>
                <div class="stat-info">
                    <h3 id="totalPaid">0</h3>
                    <span>إجمالي المدفوع</span>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon" style="background-color: rgba(231, 76, 60, 0.1); color: #e74c3c;">
                    <i class="fas fa-exclamation-triangle"></i>
                </div>
                <div class="stat-info">
                    <h3 id="totalRemaining">0</h3>
                    <span>إجمالي المتبقي</span>
                </div>
            </div>
        </div>
        
        <div class="main-card">
            <div class="card-header">
                <h3><i class="fas fa-list"></i> قائمة العملاء</h3>
                <div class="card-actions">
                    <button class="btn-icon" id="refreshClientsBtn" title="تحديث">
                        <i class="fas fa-sync-alt"></i>
                    </button>
                </div>
            </div>
            
            <div class="card-body">
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>اسم العميل</th>
                                <th>الدولة</th>
                                <th>المبلغ الأساسي</th>
                                <th>المسدد</th>
                                <th>المتبقي</th>
                                <th>مدة التقسيط</th>
                                <th>ملاحظات</th>
                                <th>التاريخ</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody id="clientsTableBody">
                            <tr>
                                <td colspan="9" style="text-align:center; padding: 40px;">
                                    جاري تحميل البيانات...
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
const baseURL = '<?= base_url() ?>';
let clientsData = [];


async function loadClientsData() {
    try {
        const [clientsRes, statsRes] = await Promise.all([
            fetch(`${baseURL}/api/clients`),
            fetch(`${baseURL}/api/clients/stats`)
        ]);

        if (!clientsRes.ok || !statsRes.ok) {
            throw new Error('فشل الاتصال بالخادم');
        }

        clientsData = await clientsRes.json();
        const stats = await statsRes.json();

        renderClientsTable();
        updateStatsCards(stats);
        setupFilters();
    } catch (error) {
        const tbody = document.getElementById('clientsTableBody');
        if (tbody) {
            tbody.innerHTML = `<tr><td colspan="9" style="color: red; text-align: center;">فشل تحميل البيانات<br>${error.message}</td></tr>`;
        }
        console.error(error);
    }
}


function updateStatsCards(stats) {
    document.getElementById('totalClients').textContent = stats.total_clients || 0;
    document.getElementById('totalPrincipal').textContent = Number(stats.total_principal || 0).toLocaleString();
    document.getElementById('totalPaid').textContent = Number(stats.total_paid || 0).toLocaleString();
    document.getElementById('totalRemaining').textContent = Number(stats.total_remaining || 0).toLocaleString();
}


function renderClientsTable() {
    const tbody = document.getElementById('clientsTableBody');
    if (!tbody) return;

    tbody.innerHTML = '';

        if (clientsData.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;">لا يوجد عملاء مسجلين حالياً</td></tr>';
        return;
    }

    clientsData.forEach(client => {
        const remaining = (client.principal || 0) - (client.paid || 0);
        const monthlyPayment = client.monthly_payment || 0;
        const duration = client.installment_duration_months || 0;
        const startDate = client.loan_start_date || client.date;
        
        let monthsRemaining = '';
        let endDate = '';
        if (monthlyPayment > 0 && duration > 0) {
            const monthsLeft = Math.ceil(remaining / monthlyPayment);
            monthsRemaining = `${monthsLeft} شهر متبقي`;
            if (startDate) {
                const start = new Date(startDate);
                const end = new Date(start);
                end.setMonth(end.getMonth() + duration);
                endDate = `ينتهي: ${end.toLocaleDateString('ar-SA')}`;
            }
        }
        
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${client.name || ''}</td>
            <td>${client.country || 'غير محدد'}</td>
            <td>${Number(client.principal || 0).toLocaleString()} دينار</td>
            <td>${Number(client.paid || 0).toLocaleString()} دينار</td>
            <td style="color: ${remaining > 0 ? '#e74c3c' : '#27ae60'}; font-weight: bold;">
                ${Number(remaining).toLocaleString()} دينار
            </td>
            <td>
                ${duration > 0 ? `${duration} شهر` : 'غير محدد'}
                ${monthlyPayment > 0 ? `<br><small>${Number(monthlyPayment).toLocaleString()} د/شهر</small>` : ''}
                ${monthsRemaining ? `<br><small style="color: #3498db;">${monthsRemaining}</small>` : ''}
            </td>
            <td>${client.notes || 'لا توجد'}</td>
            <td>${client.date || ''}</td>
            <td>
                <button class="btn-action btn-edit" onclick="editClient(${client.id})" title="تعديل">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn-action btn-delete" onclick="deleteClient(${client.id})" title="حذف">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
}


function setupFilters() {
    const searchInput = document.getElementById('clientSearch');
    const statusFilter = document.getElementById('statusFilter');

    function applyFilters() {
        const term = (searchInput?.value || '').toLowerCase();
        const status = statusFilter?.value || 'all';

        document.querySelectorAll('#clientsTableBody tr').forEach(row => {
            if (row.cells.length < 9) return;

            const name = row.cells[0].textContent.toLowerCase();
            const country = row.cells[1].textContent.toLowerCase();
            const notes = row.cells[6].textContent.toLowerCase();
            const paid = parseFloat(row.cells[3].textContent.replace(/[^0-9.-]/g, '')) || 0;
            const principal = parseFloat(row.cells[2].textContent.replace(/[^0-9.-]/g, '')) || 0;

            let clientStatus = 'pending';
            if (paid >= principal && paid > 0) clientStatus = 'paid';
            else if (paid > 0) clientStatus = 'partial';

            const matchSearch = name.includes(term) || country.includes(term) || notes.includes(term);
            const matchStatus = status === 'all' || clientStatus === status;

            row.style.display = matchSearch && matchStatus ? '' : 'none';
        });
    }

    if (searchInput) searchInput.addEventListener('input', applyFilters);
    if (statusFilter) statusFilter.addEventListener('change', applyFilters);
}


function updatePaymentProgress() {
    const principal = parseFloat(document.getElementById('principalAmount')?.value || 0);
    const paid = parseFloat(document.getElementById('paidAmount')?.value || 0);
    const progress = document.getElementById('paymentProgress');
    const percent = document.getElementById('paymentPercentage');

    if (!progress || !percent) return;

    const percentage = principal > 0 ? (paid / principal) * 100 : 0;
    progress.style.width = percentage + '%';
    percent.textContent = Math.round(percentage) + '%';
}


function openAddClientModal() {
    const modal = document.getElementById('addClientModal');
    if (!modal) return;

    const title = modal.querySelector('h2');
    if (title) title.textContent = 'إضافة عميل جديد';

    const form = document.getElementById('addClientForm');
    if (form) form.reset();

    const clientId = document.getElementById('clientId');
    if (clientId) clientId.value = '';

    const clientDate = document.getElementById('clientDate');
    if (clientDate) clientDate.value = new Date().toISOString().slice(0,10);

    updatePaymentProgress();
    modal.style.display = 'block';
}


function editClient(id) {
    const client = clientsData.find(c => c.id == id);
    if (!client) {
        alert('العميل غير موجود');
        return;
    }

    const modal = document.getElementById('addClientModal');
    if (!modal) return;

    const title = modal.querySelector('h2');
    if (title) title.textContent = 'تعديل بيانات العميل';

    const setValue = (id, value) => {
        const el = document.getElementById(id);
        if (el) el.value = value || '';
    };

    setValue('clientId', client.id);
    setValue('clientName', client.name);
    setValue('clientPhone', client.phone);
    setValue('clientCountry', client.country);
    setValue('principalAmount', client.principal);
    setValue('paidAmount', client.paid);
    setValue('clientDate', client.date);
    setValue('clientNotes', client.notes);
    setValue('monthlyPayment', client.monthly_payment);
    setValue('installmentDuration', client.installment_duration_months);
    setValue('loanStartDate', client.loan_start_date);

    updateLoanInfo();
    updatePaymentProgress();
    modal.style.display = 'block';
}


async function deleteClient(id) {
    if (!confirm('هل أنت متأكد من حذف هذا العميل؟')) return;

    try {
        const response = await fetch(`${baseURL}/api/clients/${id}`, { method: 'DELETE' });
        if (response.ok) {
            alert('تم حذف العميل بنجاح');
            loadClientsData();
        } else {
            alert('فشل الحذف');
        }
    } catch (error) {
        alert('فشل الاتصال');
    }
}


async function saveClient() {
    const modal = document.getElementById('addClientModal');
    if (!modal) return;

    const id = document.getElementById('clientId')?.value.trim() || '';

    const data = {
        name: document.getElementById('clientName')?.value.trim() || '',
        phone: document.getElementById('clientPhone')?.value.trim() || '',
        country: document.getElementById('clientCountry')?.value.trim() || '',
        principal: parseFloat(document.getElementById('principalAmount')?.value) || 0,
        paid: parseFloat(document.getElementById('paidAmount')?.value) || 0,
        date: document.getElementById('clientDate')?.value || '',
        notes: document.getElementById('clientNotes')?.value.trim() || '',
        monthly_payment: parseFloat(document.getElementById('monthlyPayment')?.value) || null,
        installment_duration_months: parseInt(document.getElementById('installmentDuration')?.value) || null,
        loan_start_date: document.getElementById('loanStartDate')?.value || null,
    };

    
    data.status = (data.paid >= data.principal && data.paid > 0) ? 'paid' : (data.paid > 0 ? 'partial' : 'pending');

    try {
        const url = id ? `${baseURL}/api/clients/${id}` : `${baseURL}/api/clients`;
        const method = id ? 'PUT' : 'POST';

        const response = await fetch(url, {
            method: method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        if (response.ok) {
            alert(id ? 'تم تحديث العميل بنجاح' : 'تم إضافة العميل بنجاح');
            modal.style.display = 'none';
            loadClientsData();
        } else {
            alert('فشل الحفظ: ' + (result.message || 'خطأ في الخادم'));
        }
    } catch (error) {
        console.error(error);
        alert('فشل الاتصال بالخادم');
    }
}


document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('addClientBtn')?.addEventListener('click', openAddClientModal);
    document.getElementById('saveClientBtn')?.addEventListener('click', saveClient);
    document.getElementById('refreshClientsBtn')?.addEventListener('click', loadClientsData);

    
    document.getElementById('closeModalBtn')?.addEventListener('click', () => {
        document.getElementById('addClientModal').style.display = 'none';
    });

    
    document.getElementById('cancelAddClientBtn')?.addEventListener('click', () => {
        document.getElementById('addClientModal').style.display = 'none';
    });

    
    document.getElementById('principalAmount')?.addEventListener('input', () => {
        updatePaymentProgress();
        updateLoanInfo();
    });
    document.getElementById('paidAmount')?.addEventListener('input', () => {
        updatePaymentProgress();
        updateLoanInfo();
    });
    document.getElementById('monthlyPayment')?.addEventListener('input', updateLoanInfo);
    document.getElementById('installmentDuration')?.addEventListener('input', updateLoanInfo);
    document.getElementById('loanStartDate')?.addEventListener('change', updateLoanInfo);

    loadClientsData();
});

function updateLoanInfo() {
    const principal = parseFloat(document.getElementById('principalAmount')?.value) || 0;
    const paid = parseFloat(document.getElementById('paidAmount')?.value) || 0;
    const monthlyPayment = parseFloat(document.getElementById('monthlyPayment')?.value) || 0;
    const duration = parseInt(document.getElementById('installmentDuration')?.value) || 0;
    const startDate = document.getElementById('loanStartDate')?.value;
    
    const remaining = principal - paid;
    const loanInfo = document.getElementById('loanInfo');
    
    if (monthlyPayment > 0 && duration > 0 && remaining > 0) {
        const monthsLeft = Math.ceil(remaining / monthlyPayment);
        loanInfo.style.display = 'block';
        document.getElementById('remainingAmount').textContent = `المبلغ المتبقي: ${Number(remaining).toLocaleString()} دينار`;
        document.getElementById('monthsRemaining').textContent = `المدة المتبقية: ${monthsLeft} شهر`;
        
        if (startDate) {
            const start = new Date(startDate);
            const end = new Date(start);
            end.setMonth(end.getMonth() + duration);
            document.getElementById('endDate').textContent = `تاريخ انتهاء التقسيط: ${end.toLocaleDateString('ar-SA')}`;
        } else {
            document.getElementById('endDate').textContent = '';
        }
    } else {
        loanInfo.style.display = 'none';
    }
}
</script>

<?= $this->endSection() ?>