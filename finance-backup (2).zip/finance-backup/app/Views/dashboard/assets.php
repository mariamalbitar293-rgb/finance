<?= $this->extend('layouts/main') ?>
<?= $this->section('title') ?>
الأصول الثابتة
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<div class="section-header">
    <h2><i class="fas fa-server"></i> الأصول الثابتة</h2>
    <div class="controls">
        <button class="btn btn-primary" id="addAssetBtn">
            <i class="fas fa-plus"></i> إضافة أصل جديد
        </button>
        <button class="btn btn-success" id="exportAssetsBtn">
            <i class="fas fa-file-export"></i> تصدير JSON
        </button>
        <button class="btn btn-secondary" id="printAssetsBtn">
            <i class="fas fa-print"></i> طباعة
        </button>
    </div>
</div>


<div class="filters-bar" style="margin-bottom: 20px; display: flex; gap: 15px; flex-wrap: wrap; align-items: center;">
    <div class="form-group" style="min-width: 250px;">
        <label for="assetSearch"><i class="fas fa-search"></i> بحث</label>
        <input type="text" id="assetSearch" placeholder="اسم الأصل، الرقم التسلسلي، الوصف...">
    </div>
    <div class="form-group">
        <label for="assetTypeFilter">النوع</label>
        <select id="assetTypeFilter">
            <option value="all">جميع الأنواع</option>
            <option value="servers">سيرفرات</option>
            <option value="equipment">معدات</option>
            <option value="property">عقارات</option>
            <option value="vehicles">مركبات</option>
            <option value="other">أخرى</option>
        </select>
    </div>
</div>


<div class="stats-cards">
    <div class="stat-card card-1">
        <div class="stat-info">
            <h3>إجمالي القيمة الدفترية</h3>
            <div class="value" id="totalBookValue">0 <span style="font-size: 1rem;">دينار</span></div>
        </div>
        <div class="stat-icon"><i class="fas fa-book"></i></div>
    </div>
    <div class="stat-card card-2">
        <div class="stat-info">
            <h3>القيمة السوقية</h3>
            <div class="value" id="totalMarketValue">0 <span style="font-size: 1rem;">دينار</span></div>
        </div>
        <div class="stat-icon"><i class="fas fa-chart-line"></i></div>
    </div>
    <div class="stat-card card-3">
        <div class="stat-info">
            <h3>عدد الأصول النشطة</h3>
            <div class="value" id="activeAssets">0</div>
        </div>
        <div class="stat-icon"><i class="fas fa-server"></i></div>
    </div>
    <div class="stat-card card-4">
        <div class="stat-info">
            <h3>الإهلاك السنوي</h3>
            <div class="value" id="annualDepreciation">0 <span style="font-size: 1rem;">دينار</span></div>
        </div>
        <div class="stat-icon"><i class="fas fa-percentage"></i></div>
    </div>
</div>


<div class="assets-grid" id="assetsGrid">
    <div style="grid-column: 1 / -1; text-align:center; padding:80px; color:#999;">
        جاري تحميل الأصول...
    </div>
</div>


<div class="modal-overlay" id="addAssetModal" style="display: none;">
    <div class="modal-container">
        <div class="modal-header">
            <h3 id="modalTitle"><i class="fas fa-server"></i> إضافة أصل جديد</h3>
            <button class="close-modal" onclick="closeModal('addAssetModal')"><i class="fas fa-times"></i></button>
        </div>
        <div class="modal-body">
            <form id="assetForm" enctype="multipart/form-data">
                <input type="hidden" id="assetId">
                <div class="form-row">
                    <div class="form-group">
                        <label for="assetName">اسم الأصل *</label>
                        <input type="text" id="assetName" required>
                    </div>
                    <div class="form-group">
                        <label for="assetType">نوع الأصل *</label>
                        <select id="assetType" required>
                            <option value="servers">سيرفرات</option>
                            <option value="equipment">معدات</option>
                            <option value="property">عقارات</option>
                            <option value="vehicles">مركبات</option>
                            <option value="other">أخرى</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="assetSerial">رقم تسلسلي (اختياري)</label>
                        <input type="text" id="assetSerial" placeholder="اختياري">
                    </div>
                    <div class="form-group">
                        <label for="purchaseDate">تاريخ الشراء *</label>
                        <input type="date" id="purchaseDate" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="bookValue">القيمة الدفترية *</label>
                        <input type="number" id="bookValue" min="1" required>
                    </div>
                    <div class="form-group">
                        <label for="marketValue">القيمة السوقية *</label>
                        <input type="number" id="marketValue" min="1" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="depreciationRate">معدل الإهلاك السنوي (%)</label>
                        <input type="number" id="depreciationRate" min="0" max="100" step="0.1" value="10">
                    </div>
                    <div class="form-group">
                        <label for="assetStatus">الحالة</label>
                        <select id="assetStatus">
                            <option value="active">نشط</option>
                            <option value="inactive">غير نشط</option>
                            <option value="maintenance">تحت الصيانة</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="paymentPeriod">فترة الدفع</label>
                        <select id="paymentPeriod">
                            <option value="none">لا يوجد</option>
                            <option value="4_months">4 أشهر</option>
                            <option value="6_months">6 أشهر</option>
                            <option value="1_year">سنة واحدة</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="paymentStartDate">تاريخ بداية الدفع</label>
                        <input type="date" id="paymentStartDate">
                    </div>
                </div>
                <div class="form-group">
                    <label for="assetDescription">الوصف</label>
                    <textarea id="assetDescription" rows="3"></textarea>
                </div>
                <div class="form-group">
                    <label for="image">صورة الأصل (اختياري)</label>
                    <input type="file" id="image" accept="image/*">
                    <small>اختر صورة جديدة لتغيير الصورة الحالية</small>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('addAssetModal')">إلغاء</button>
            <button class="btn btn-primary" id="saveAssetBtn">حفظ الأصل</button>
        </div>
    </div>
</div>

<script>
const baseURL = '<?= base_url() ?>';
let assetsData = [];
let filteredAssets = [];

async function loadAssets() {
    try {
        console.log('جاري جلب البيانات من:', `${baseURL}/api/assets`);
        const [assetsRes, statsRes] = await Promise.all([
            fetch(`${baseURL}/api/assets`),
            fetch(`${baseURL}/api/assets/stats`)
        ]);

        
        console.log('حالة assets:', assetsRes.status, assetsRes.statusText);
        console.log('حالة stats:', statsRes.status, statsRes.statusText);

        if (!assetsRes.ok) {
            throw new Error(`خطأ في جلب الأصول: ${assetsRes.status} ${assetsRes.statusText}`);
        }
        if (!statsRes.ok) {
            throw new Error(`خطأ في جلب الإحصائيات: ${statsRes.status} ${statsRes.statusText}`);
        }

        assetsData = await assetsRes.json();
        const stats = await statsRes.json();

        console.log('تم جلب الأصول بنجاح:', assetsData);
        console.log('تم جلب الإحصائيات بنجاح:', stats);

        filteredAssets = [...assetsData];
        renderAssetsGrid();
        updateStats(stats);
        setupEventListeners();

    } catch (err) {
        console.error('خطأ كامل:', err);

        
        document.getElementById('assetsGrid').innerHTML = 
            `<div style="grid-column: 1/-1; text-align:center; padding:80px; color:red; font-family: monospace;">
                <h3>فشل تحميل البيانات</h3>
                <p><strong>السبب:</strong> ${err.message}</p>
                <p><strong>baseURL:</strong> ${baseURL}</p>
                <p>افتح Console (F12) لمزيد من التفاصيل</p>
            </div>`;
    }
}

function renderAssetsGrid(assets = filteredAssets) {
    const grid = document.getElementById('assetsGrid');
    grid.innerHTML = '';

    if (assets.length === 0) {
        grid.innerHTML = `<div style="grid-column: 1 / -1; text-align:center; padding:80px; color:#999;">
            <i class="fas fa-box-open" style="font-size:64px;"></i>
            <h3>لا توجد أصول مطابقة للبحث</h3>
        </div>`;
        return;
    }

    assets.forEach(asset => {
        const iconMap = {
            servers: 'fa-server',
            equipment: 'fa-desktop',
            property: 'fa-building',
            vehicles: 'fa-car',
            other: 'fa-box'
        };
        const icon = iconMap[asset.type] || 'fa-box';

        
        const purchaseDate = new Date(asset.purchase_date);
        const currentDate = new Date();
        const yearsDiff = (currentDate - purchaseDate) / (1000 * 60 * 60 * 24 * 365.25);
        const accumulatedDep = asset.book_value * (asset.depreciation_rate / 100) * yearsDiff;
        const currentValue = Math.max(0, asset.book_value - accumulatedDep);

        const card = document.createElement('div');
        card.className = 'asset-card';
        card.innerHTML = `
            <div class="asset-image">
                ${asset.image_url ?
                    `<img src="${baseURL}/${asset.image_url}" alt="${asset.name}">` :
                    `<i class="fas ${icon}" style="font-size:48px; color:#999;"></i>`
                }
            </div>
            <div class="asset-details">
                <h3>${asset.name}</h3>
                <div class="asset-meta">
                    <span>${asset.serial || 'لا يوجد رقم تسلسلي'}</span>
                    <span>شراء: ${asset.purchase_date}</span>
                </div>
                <div class="asset-value">${Number(asset.book_value).toLocaleString()} دينار</div>
                <div style="margin:10px 0; font-size:0.9rem; color:#555;">
                    سوقية: ${Number(asset.market_value).toLocaleString()} دينار<br>
                    <strong>القيمة الحالية: ${Math.round(currentValue).toLocaleString()} دينار</strong>
                </div>
                <div class="asset-status ${asset.status === 'active' ? 'paid' : 'pending'}">
                    ${asset.status === 'active' ? 'نشط' : asset.status === 'maintenance' ? 'تحت الصيانة' : 'غير نشط'}
                </div>
                ${asset.payment_period && asset.payment_period !== 'none' ? `
                <div style="margin:10px 0; padding:10px; background:#e8f4f8; border-radius:8px; font-size:0.9rem;">
                    <strong>فترة الدفع:</strong> ${asset.payment_period === '4_months' ? '4 أشهر' : asset.payment_period === '6_months' ? '6 أشهر' : 'سنة واحدة'}<br>
                    ${asset.payment_start_date ? `<strong>من:</strong> ${asset.payment_start_date}` : ''}
                    ${asset.payment_end_date ? `<br><strong>إلى:</strong> ${asset.payment_end_date}` : ''}
                </div>
                ` : ''}
                <div style="margin-top:15px; display:flex; gap:10px;">
                    <button class="btn btn-secondary" onclick="editAsset(${asset.id})">تعديل</button>
                    <button class="btn btn-danger" onclick="deleteAsset(${asset.id})">حذف</button>
                </div>
            </div>
        `;
        grid.appendChild(card);
    });
}

function updateStats(stats) {
    document.getElementById('totalBookValue').innerHTML = `${Number(stats.total_book_value || 0).toLocaleString()} <span style="font-size: 1rem;">دينار</span>`;
    document.getElementById('totalMarketValue').innerHTML = `${Number(stats.total_market_value || 0).toLocaleString()} <span style="font-size: 1rem;">دينار</span>`;
    document.getElementById('annualDepreciation').innerHTML = `${Number(stats.total_depreciation || 0).toLocaleString()} <span style="font-size: 1rem;">دينار</span>`;
    document.getElementById('activeAssets').textContent = stats.active_count || 0;
}


function setupEventListeners() {
    const searchInput = document.getElementById('assetSearch');
    const typeFilter = document.getElementById('assetTypeFilter');

    searchInput?.addEventListener('input', filterAssets);
    typeFilter?.addEventListener('change', filterAssets);
}

function filterAssets() {
    const searchTerm = document.getElementById('assetSearch')?.value.toLowerCase() || '';
    const selectedType = document.getElementById('assetTypeFilter')?.value || 'all';

    filteredAssets = assetsData.filter(asset => {
        const matchesSearch = asset.name.toLowerCase().includes(searchTerm) ||
                              asset.serial.toLowerCase().includes(searchTerm) ||
                              (asset.description && asset.description.toLowerCase().includes(searchTerm));

        const matchesType = selectedType === 'all' || asset.type === selectedType;

        return matchesSearch && matchesType;
    });

    renderAssetsGrid();
}


function exportAssetsData() {
    const dataStr = JSON.stringify(filteredAssets, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `assets-export-${new Date().toISOString().slice(0,10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
}


function openAddAssetModal() {
    document.getElementById('modalTitle').textContent = 'إضافة أصل جديد';
    document.getElementById('assetForm').reset();
    document.getElementById('assetId').value = '';
    document.getElementById('purchaseDate').valueAsDate = new Date();
    openModal('addAssetModal');
}

function editAsset(id) {
    const asset = assetsData.find(a => a.id == id);
    if (!asset) return;

    document.getElementById('assetId').value = asset.id;
    document.getElementById('assetName').value = asset.name;
    document.getElementById('assetType').value = asset.type;
    document.getElementById('assetSerial').value = asset.serial;
    document.getElementById('purchaseDate').value = asset.purchase_date;
    document.getElementById('bookValue').value = asset.book_value;
    document.getElementById('marketValue').value = asset.market_value;
    document.getElementById('depreciationRate').value = asset.depreciation_rate || 10;
    document.getElementById('assetStatus').value = asset.status;
    document.getElementById('assetDescription').value = asset.description || '';
    document.getElementById('paymentPeriod').value = asset.payment_period || 'none';
    document.getElementById('paymentStartDate').value = asset.payment_start_date || '';
    
    if (asset.payment_period && asset.payment_start_date) {
        const start = new Date(asset.payment_start_date);
        const end = new Date(start);
        if (asset.payment_period === '4_months') {
            end.setMonth(end.getMonth() + 4);
        } else if (asset.payment_period === '6_months') {
            end.setMonth(end.getMonth() + 6);
        } else if (asset.payment_period === '1_year') {
            end.setFullYear(end.getFullYear() + 1);
        }
    }
    
    document.getElementById('modalTitle').textContent = 'تعديل الأصل';

    openModal('addAssetModal');
}

async function saveAsset() {
    const modal = document.getElementById('addAssetModal');
    if (!modal) return;

    const id = document.getElementById('assetId')?.value.trim() || '';

    const formData = new FormData();
    
    formData.append('name', document.getElementById('assetName').value.trim());
    formData.append('type', document.getElementById('assetType').value);
    formData.append('serial', document.getElementById('assetSerial').value.trim());
    formData.append('purchase_date', document.getElementById('purchaseDate').value);
    formData.append('book_value', document.getElementById('bookValue').value);
    formData.append('market_value', document.getElementById('marketValue').value);
    formData.append('depreciation_rate', document.getElementById('depreciationRate').value || '10');
    formData.append('status', document.getElementById('assetStatus').value);
    formData.append('description', document.getElementById('assetDescription').value.trim());
    formData.append('payment_period', document.getElementById('paymentPeriod').value);
    
    const paymentStartDate = document.getElementById('paymentStartDate').value;
    if (paymentStartDate) {
        formData.append('payment_start_date', paymentStartDate);
        const start = new Date(paymentStartDate);
        const end = new Date(start);
        const period = document.getElementById('paymentPeriod').value;
        if (period === '4_months') {
            end.setMonth(end.getMonth() + 4);
        } else if (period === '6_months') {
            end.setMonth(end.getMonth() + 6);
        } else if (period === '1_year') {
            end.setFullYear(end.getFullYear() + 1);
        }
        if (period !== 'none') {
            formData.append('payment_end_date', end.toISOString().split('T')[0]);
        }
    }

    const imageFile = document.getElementById('image').files[0];
    if (imageFile) {
        formData.append('image', imageFile);
    }

    try {
        let url = `${baseURL}/api/assets`;
        let method = 'POST';

        if (id) {
            url += `/${id}`;
            method = 'POST';
        }

        const response = await fetch(url, {
            method: method,
            body: formData
        });

        let result;
        try {
            result = await response.json();
        } catch (e) {
            result = { message: await response.text() };
        }

        if (response.ok) {
            alert(id ? 'تم تحديث الأصل بنجاح' : 'تم إضافة الأصل بنجاح');
            modal.style.display = 'none';
            loadAssets();
        } else {
            alert('فشل الحفظ: ' + (result.message || 'خطأ في البيانات المرسلة'));
        }
    } catch (error) {
        console.error(error);
        alert('فشل الاتصال بالخادم');
    }
}
async function deleteAsset(id) {
    if (!confirm('تأكيد حذف الأصل؟')) return;
    try {
        const response = await fetch(`${baseURL}/api/assets/${id}`, { method: 'DELETE' });
        if (response.ok) {
            alert('تم الحذف بنجاح');
            loadAssets();
        } else {
            alert('فشل الحذف');
        }
    } catch (err) {
        alert('فشل الاتصال');
    }
}

function openModal(id) { document.getElementById(id).style.display = 'flex'; }
function closeModal(id) { document.getElementById(id).style.display = 'none'; }


document.addEventListener('DOMContentLoaded', () => {
    loadAssets();

    document.getElementById('addAssetBtn')?.addEventListener('click', openAddAssetModal);
    document.getElementById('saveAssetBtn')?.addEventListener('click', saveAsset);
    document.getElementById('exportAssetsBtn')?.addEventListener('click', exportAssetsData);
    document.getElementById('printAssetsBtn')?.addEventListener('click', () => window.print());
});
</script>
<?= $this->endSection() ?>