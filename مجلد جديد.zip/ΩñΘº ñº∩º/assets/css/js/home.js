let map;
let markers = [];

function initMap() {
    map = L.map('jordanMap').setView([31.9539, 35.9106], 7);
    
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);
    
    map.on('click', function(e) {
        markers.forEach(marker => map.removeLayer(marker));
        markers = [];
        
        const marker = L.marker(e.latlng).addTo(map)
            .bindPopup(`موقع مختار: ${e.latlng.lat.toFixed(4)}, ${e.latlng.lng.toFixed(4)}`)
            .openPopup();
        
        markers.push(marker);
    });
    
    const cities = [
        {name: "عمان", coords: [31.9539, 35.9106]},
        {name: "الزرقاء", coords: [32.0608, 36.0942]},
        {name: "إربد", coords: [32.5556, 35.85]},
        {name: "العقبة", coords: [29.5267, 35.0078]},
        {name: "الكرك", coords: [31.1822, 35.6997]}
    ];
    
    cities.forEach(city => {
        const marker = L.marker(city.coords).addTo(map)
            .bindPopup(city.name);
        markers.push(marker);
    });
}

const translations = {
    ar: {
        "site_title": "مركز اتصال خطوات الأردن",
        "home": "الرئيسية",
        "guest": "زائر",
        "not_logged_in": "غير مسجل",
        "hero_title": "مركز اتصال خطوات الأردن",
        "hero_description": "لا تفوت أي مكالمة مهمة مرة أخرى<br>كل مكالمة هي فرصة ضائعة لنمو عملك",
        "call_now": "اتصل بنا الآن",
        "login_title": "تسجيل الدخول",
        "username": "اسم المستخدم",
        "username_placeholder": "أدخل اسم المستخدم",
        "password": "كلمة المرور",
        "password_placeholder": "أدخل كلمة المرور",
        "remember_me": "تذكرني",
        "login": "تسجيل الدخول",
        "forgot_password": "نسيت كلمة المرور؟",
        "our_features": "ميزاتنا",
        "feature1_title": "خدمات رقمية متكاملة",
        "feature1_desc": "نقدم مجموعة من الخدمات الرقمية لمساعدة المؤسسات على النمو والتوسع بشكل أفضل وأكثر كفاءة.",
        "feature2_title": "بناء العلامات التجارية",
        "feature2_desc": "بناء علامات تجارية مستدامة مع العملاء لضمان استمرارية العلاقة وزيادة الولاء للعلامة التجارية.",
        "feature3_title": "تحليل الأداء",
        "feature3_desc": "مركز الاتصال يوظف أنظمة متقدمة لفحص تجربة العميل ورؤية الإنتاجية والأداء المالي المدروس.",
        "feature4_title": "بناء قاعدة بيانات",
        "feature4_desc": "بناء قاعدة بيانات المنتجات التي تقوم بخدمتها والعملاء المستهدفين لتحسين الخدمات المقدمة.",
        "jordan_map": "خريطة الأردن",
        "map_instructions": "انقر على الخريطة لوضع علامة على موقع معين. استخدم أزرار التكبير والتصغير للتحكم في مستوى التكبير.",
        "contact_us": "تواصل معنا",
        "company_address": "مؤسسة خطوات الأردن",
        "website": "الموقع الإلكتروني",
        "send_message": "أرسل رسالة",
        "full_name": "الاسم الكامل",
        "name_placeholder": "أدخل اسمك الكامل",
        "email": "البريد الإلكتروني",
        "email_placeholder": "أدخل بريدك الإلكتروني",
        "message": "الرسالة",
        "message_placeholder": "اكتب رسالتك هنا",
        "send": "إرسال الرسالة",
        "quick_links": "روابط سريعة",
        "contact_info": "معلومات الاتصال",
        "jordan": "الأردن",
        "copyright": "جميع الحقوق محفوظة © 2024 مؤسسة خطوات الأردن"
    },
    en: {
        "site_title": "Jordan Steps Call Center",
        "home": "Home",
        "guest": "Guest",
        "not_logged_in": "Not Logged In",
        "hero_title": "Jordan Steps Call Center",
        "hero_description": "Don't miss any important call again<br>Every call is a missed opportunity for your business growth",
        "call_now": "Call Us Now",
        "login_title": "Login",
        "username": "Username",
        "username_placeholder": "Enter your username",
        "password": "Password",
        "password_placeholder": "Enter your password",
        "remember_me": "Remember me",
        "login": "Login",
        "forgot_password": "Forgot password?",
        "our_features": "Our Features",
        "feature1_title": "Integrated Digital Services",
        "feature1_desc": "We provide a range of digital services to help organizations grow and expand more efficiently.",
        "feature2_title": "Building Brands",
        "feature2_desc": "Building sustainable brands with customers to ensure relationship continuity and increased brand loyalty.",
        "feature3_title": "Performance Analysis",
        "feature3_desc": "The call center employs advanced systems to examine customer experience and view productivity and studied financial performance.",
        "feature4_title": "Building Database",
        "feature4_desc": "Building a database of products you serve and target customers to improve the services provided.",
        "jordan_map": "Jordan Map",
        "map_instructions": "Click on the map to place a marker on a specific location. Use the zoom buttons to control the zoom level.",
        "contact_us": "Contact Us",
        "company_address": "Jordan Steps Foundation, Between Al-Daqn Al-Sawda",
        "website": "Website",
        "send_message": "Send Message",
        "full_name": "Full Name",
        "name_placeholder": "Enter your full name",
        "email": "Email",
        "email_placeholder": "Enter your email",
        "message": "Message",
        "message_placeholder": "Write your message here",
        "send": "Send Message",
        "quick_links": "Quick Links",
        "contact_info": "Contact Information",
        "jordan": "Jordan",
        "copyright": "All rights reserved © 2024 Jordan Steps Foundation"
    }
};

$(document).ready(function() {
    initMap();
    
    const savedLanguage = localStorage.getItem('language') || 'ar';
    changeLanguage(savedLanguage);
    
    checkLoginStatus();
    
    $('.language-option').click(function() {
        const lang = $(this).data('lang');
        changeLanguage(lang);
    });
    
    $('#zoomIn').click(function() {
        map.zoomIn();
    });
    
    $('#zoomOut').click(function() {
        map.zoomOut();
    });
    
    $('#resetMap').click(function() {
        map.setView([31.9539, 35.9106], 7);
        markers.forEach(marker => map.removeLayer(marker));
        markers = [];
    });
    
    $(window).scroll(function() {
        if ($(this).scrollTop() > 300) {
            $('#scrollToTop').addClass('show');
        } else {
            $('#scrollToTop').removeClass('show');
        }
    });
    
    $('#scrollToTop').click(function() {
        $('html, body').animate({scrollTop: 0}, 800);
        return false;
    });
    
    $('#loginForm').submit(function(e) {
        e.preventDefault();
        const username = $('#username').val();
        const password = $('#password').val();
        
        if (username && password) {
            localStorage.setItem('isLoggedIn', 'true');
            localStorage.setItem('currentUser', JSON.stringify({
                name: username,
                role: 'مستخدم'
            }));
            
            updateUserInterface();
            
            $('.loading').show();
            setTimeout(() => {
                $('.loading').hide();
                alert('تم تسجيل الدخول بنجاح! سيتم تحويلك إلى صفحة التقارير.');
                window.location.href = 'reports.html';
            }, 1500);
        } else {
            const loginAlert = $('#loginAlert');
            if (loginAlert.length) {
                loginAlert.removeClass('d-none').text('يرجى إدخال اسم المستخدم وكلمة المرور');
                setTimeout(() => {
                    loginAlert.addClass('d-none');
                }, 3000);
            } else {
                alert('يرجى إدخال اسم المستخدم وكلمة المرور');
            }
        }
    });
    
    const userProfile = $('#userProfile');
    if (userProfile.length) {
        userProfile.click(function() {
            if (localStorage.getItem('isLoggedIn') === 'true') {
                if (confirm('هل تريد تسجيل الخروج؟')) {
                    localStorage.removeItem('isLoggedIn');
                    localStorage.removeItem('currentUser');
                    updateUserInterface();
                    alert('تم تسجيل الخروج بنجاح');
                }
            }
        });
    }
    
    $('.contact-form form').submit(function(e) {
        e.preventDefault();
        $('.loading').show();
        
        setTimeout(() => {
            $('.loading').hide();
            alert('تم إرسال رسالتك بنجاح! سنتواصل معك قريباً.');
            $('.contact-form form')[0].reset();
        }, 2000);
    });
});

function checkLoginStatus() {
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    if (isLoggedIn) {
        updateUserInterface();
    }
}

function updateUserInterface() {
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
    
    if (isLoggedIn && currentUser) {
        if ($('#userName').length) {
            $('#userName').text(currentUser.name);
        }
        if ($('#userRole').length) {
            $('#userRole').text(currentUser.role);
        }
        if ($('#userInitial').length) {
            $('#userInitial').text(currentUser.name.charAt(0));
        }
    } else {
        if ($('#userName').length) {
            $('#userName').text('زائر');
        }
        if ($('#userRole').length) {
            $('#userRole').text('غير مسجل');
        }
        if ($('#userInitial').length) {
            $('#userInitial').text('?');
        }
    }
}

function changeLanguage(lang) {
    $('html').attr('dir', lang === 'ar' ? 'rtl' : 'ltr');
    $('html').attr('lang', lang);
    
    $('#currentLanguage').text(lang === 'ar' ? 'العربية' : 'English');
    
    $('[data-i18n]').each(function() {
        const key = $(this).data('i18n');
        if (translations[lang][key]) {
            $(this).html(translations[lang][key]);
        }
    });
    
    $('[data-i18n-placeholder]').each(function() {
        const key = $(this).data('i18n-placeholder');
        if (translations[lang][key]) {
            $(this).attr('placeholder', translations[lang][key]);
        }
    });
    
    localStorage.setItem('language', lang);
}
