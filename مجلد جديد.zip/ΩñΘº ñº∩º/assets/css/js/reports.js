$(document).ready(function() {
    initAllCharts();
    initSidebar();
    initTabs();
    initQuickStats();
    initNewReportButtons();
});

function initAllCharts() {
    const loyaltyCtx = document.getElementById('loyaltyDistributionChart')?.getContext('2d');
    if (loyaltyCtx) {
        new Chart(loyaltyCtx, {
            type: 'doughnut',
            data: {
                labels: ['بلاتينيوم 4.7%', 'ذهبي 16%', 'فضي 29.4%', 'برونزي 41.1%', 'جديد 8.8%'],
                datasets: [{
                    data: [248, 842, 1542, 2154, 461],
                    backgroundColor: [
                        '#E5E4E2',
                        '#FFD700',
                        '#C0C0C0',
                        '#CD7F32',
                        '#17a2b8'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        rtl: true,
                        labels: {
                            font: {
                                family: 'Cairo'
                            }
                        }
                    },
                    title: {
                        display: true,
                        text: 'توزيع العملاء حسب مستوى الولاء',
                        font: {
                            family: 'Cairo',
                            size: 16
                        }
                    }
                }
            }
        });
    }

    const returnCtx = document.getElementById('returnRateChart')?.getContext('2d');
    if (returnCtx) {
        new Chart(returnCtx, {
            type: 'bar',
            data: {
                labels: ['VIP', 'ذهبي', 'فضي', 'برونزي', 'جديد', 'غير نشطين'],
                datasets: [{
                    label: 'معدل العودة (%)',
                    data: [94, 82, 65, 42, 28, 12],
                    backgroundColor: [
                        '#E5E4E2',
                        '#FFD700',
                        '#C0C0C0',
                        '#CD7F32',
                        '#17a2b8',
                        '#dc3545'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                            callback: function(value) {
                                return value + '%';
                            }
                        }
                    }
                }
            }
        });
    }

    const upgradeCtx = document.getElementById('upgradeOpportunitiesChart')?.getContext('2d');
    if (upgradeCtx) {
        new Chart(upgradeCtx, {
            type: 'radar',
            data: {
                labels: ['التكرار', 'القيمة', 'المدة', 'التقييمات', 'الولاء', 'الإحالات'],
                datasets: [
                    {
                        label: 'محمد',
                        data: [95, 90, 88, 92, 85, 90],
                        borderColor: '#2c5aa0',
                        backgroundColor: 'rgba(44, 90, 160, 0.2)'
                    },
                    {
                        label: 'سارة',
                        data: [85, 88, 82, 85, 78, 80],
                        borderColor: '#28a745',
                        backgroundColor: 'rgba(40, 167, 69, 0.2)'
                    },
                    {
                        label: 'متوسط العملاء',
                        data: [65, 70, 60, 68, 55, 58],
                        borderColor: '#6c757d',
                        backgroundColor: 'transparent',
                        borderDash: [5, 5]
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    r: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });
    }

    const timeCtx = document.getElementById('preferencesTimeChart')?.getContext('2d');
    if (timeCtx) {
        new Chart(timeCtx, {
            type: 'polarArea',
            data: {
                labels: ['صباح (8-12)', 'ظهر (12-4)', 'مساء (4-8)', 'ليل (8-12)'],
                datasets: [{
                    data: [15, 42, 35, 8],
                    backgroundColor: [
                        '#FFD700',
                        '#28a745',
                        '#dc3545',
                        '#2c5aa0'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'التفضيل حسب الوقت'
                    }
                }
            }
        });
    }

    const dayCtx = document.getElementById('preferencesDayChart')?.getContext('2d');
    if (dayCtx) {
        new Chart(dayCtx, {
            type: 'bar',
            data: {
                labels: ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'],
                datasets: [{
                    label: 'عدد الطلبات',
                    data: [2845, 2458, 2584, 2758, 3542, 4258, 3985],
                    backgroundColor: '#2c5aa0'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'التفضيل حسب اليوم'
                    }
                }
            }
        });
    }

    const typeCtx = document.getElementById('preferencesTypeChart')?.getContext('2d');
    if (typeCtx) {
        new Chart(typeCtx, {
            type: 'pie',
            data: {
                labels: ['توصيل', 'استلام', 'تناول في المطعم'],
                datasets: [{
                    data: [65, 25, 10],
                    backgroundColor: ['#28a745', '#ffc107', '#dc3545']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'نوع الطلب المفضل'
                    }
                }
            }
        });
    }

    const empPerfCtx = document.getElementById('employeePerformanceChart')?.getContext('2d');
    if (empPerfCtx) {
        new Chart(empPerfCtx, {
            type: 'bar',
            data: {
                labels: ['أحمد', 'سارة', 'محمد', 'يوسف'],
                datasets: [
                    {
                        label: 'الكفاءة %',
                        data: [92, 85, 72, 58],
                        backgroundColor: '#28a745'
                    },
                    {
                        label: 'متوسط الوقت (دقيقة)',
                        data: [12.5, 14.2, 18.4, 24.8],
                        backgroundColor: '#dc3545',
                        yAxisID: 'y1'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        title: {
                            display: true,
                            text: 'الكفاءة %'
                        }
                    },
                    y1: {
                        position: 'right',
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'الوقت (دقيقة)'
                        },
                        grid: {
                            drawOnChartArea: false
                        }
                    }
                }
            }
        });
    }

    const empRatingCtx = document.getElementById('employeeRatingChart')?.getContext('2d');
    if (empRatingCtx) {
        new Chart(empRatingCtx, {
            type: 'line',
            data: {
                labels: ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'],
                datasets: [
                    {
                        label: 'أحمد',
                        data: [4.5, 4.6, 4.7, 4.8, 4.8, 4.9, 4.9, 5.0, 5.0, 5.0, 5.0, 5.0],
                        borderColor: '#2c5aa0',
                        tension: 0.4
                    },
                    {
                        label: 'سارة',
                        data: [4.2, 4.3, 4.4, 4.5, 4.5, 4.6, 4.6, 4.7, 4.7, 4.8, 4.8, 4.8],
                        borderColor: '#28a745',
                        tension: 0.4
                    },
                    {
                        label: 'المتوسط العام',
                        data: [3.8, 3.9, 4.0, 4.1, 4.1, 4.2, 4.2, 4.2, 4.3, 4.3, 4.3, 4.4],
                        borderColor: '#6c757d',
                        borderDash: [5, 5],
                        tension: 0.4
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 5
                    }
                }
            }
        });
    }

    const campaignCtx = document.getElementById('campaignPerformanceChart')?.getContext('2d');
    if (campaignCtx) {
        new Chart(campaignCtx, {
            type: 'bar',
            data: {
                labels: ['عرض رمضان', 'برنامج الولاء', 'عروض نهاية الأسبوع', 'وسائل التواصل', 'البريد الإلكتروني'],
                datasets: [
                    {
                        label: 'العائد (آلاف)',
                        data: [85, 42, 18, 28, 15],
                        backgroundColor: '#28a745',
                        yAxisID: 'y'
                    },
                    {
                        label: 'ROI %',
                        data: [467, 425, 260, 133, 185],
                        backgroundColor: '#ffc107',
                        yAxisID: 'y1'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        type: 'linear',
                        position: 'left',
                        title: {
                            display: true,
                            text: 'العائد (آلاف ₪)'
                        }
                    },
                    y1: {
                        type: 'linear',
                        position: 'right',
                        title: {
                            display: true,
                            text: 'ROI %'
                        },
                        grid: {
                            drawOnChartArea: false
                        }
                    }
                }
            }
        });
    }

    const shiftCtx = document.getElementById('shiftAnalysisChart')?.getContext('2d');
    if (shiftCtx) {
        new Chart(shiftCtx, {
            type: 'line',
            data: {
                labels: ['الأسبوع 1', 'الأسبوع 2', 'الأسبوع 3', 'الأسبوع 4'],
                datasets: [
                    {
                        label: 'تحول صباحي',
                        data: [18.2, 18.5, 18.8, 18.5],
                        borderColor: '#2c5aa0',
                        tension: 0.4
                    },
                    {
                        label: 'تحول مسائي',
                        data: [23.5, 24.8, 24.2, 23.8],
                        borderColor: '#28a745',
                        tension: 0.4
                    },
                    {
                        label: 'تحول ليلي',
                        data: [8.2, 8.5, 8.4, 8.3],
                        borderColor: '#dc3545',
                        tension: 0.4
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'طلبات/ساعة'
                        }
                    }
                }
            }
        });
    }

    const skillCtx = document.getElementById('skillDevelopmentChart')?.getContext('2d');
    if (skillCtx) {
        new Chart(skillCtx, {
            type: 'radar',
            data: {
                labels: ['خدمة العملاء', 'إدارة الوقت', 'مهارات البيع', 'حل المشكلات', 'العمل الجماعي', 'التواصل'],
                datasets: [
                    {
                        label: 'قبل التدريب',
                        data: [65, 58, 62, 55, 70, 68],
                        borderColor: '#6c757d',
                        backgroundColor: 'rgba(108, 117, 125, 0.1)'
                    },
                    {
                        label: 'بعد التدريب',
                        data: [88, 85, 80, 82, 92, 90],
                        borderColor: '#28a745',
                        backgroundColor: 'rgba(40, 167, 69, 0.1)'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    r: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });
    }

    const trainingCtx = document.getElementById('trainingImpactChart')?.getContext('2d');
    if (trainingCtx) {
        new Chart(trainingCtx, {
            type: 'bar',
            data: {
                labels: ['رضا العملاء', 'مبيعات/موظف', 'وقت المعالجة', 'دقة الطلبات', 'رضا الموظفين'],
                datasets: [{
                    label: 'التحسن %',
                    data: [28, 22, -15, 18, 25],
                    backgroundColor: [
                        '#28a745',
                        '#28a745',
                        '#dc3545',
                        '#28a745',
                        '#28a745'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'التحسن %'
                        }
                    }
                }
            }
        });
    }

    const satisfactionCtx = document.getElementById('satisfactionChart')?.getContext('2d');
    if (satisfactionCtx) {
        new Chart(satisfactionCtx, {
            type: 'bar',
            data: {
                labels: ['الراتب والمكافآت', 'بيئة العمل', 'فرص التطوير', 'التواصل الإداري', 'توزيع المهام', 'ساعات العمل'],
                datasets: [{
                    label: 'معدل الرضا %',
                    data: [85, 88, 82, 75, 80, 78],
                    backgroundColor: '#2c5aa0'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        title: {
                            display: true,
                            text: 'معدل الرضا %'
                        }
                    }
                }
            }
        });
    }

    const peakCtx = document.getElementById('peakHoursChart')?.getContext('2d');
    if (peakCtx) {
        new Chart(peakCtx, {
            type: 'line',
            data: {
                labels: ['8:00', '10:00', '12:00', '14:00', '16:00', '18:00', '20:00', '22:00'],
                datasets: [
                    {
                        label: 'عدد الطلبات',
                        data: [85, 185, 5248, 4852, 325, 4852, 2542, 842],
                        borderColor: '#dc3545',
                        backgroundColor: 'rgba(220, 53, 69, 0.1)',
                        tension: 0.4,
                        fill: true
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    }

    const branchCtx = document.getElementById('branchComparisonChart')?.getContext('2d');
    if (branchCtx) {
        new Chart(branchCtx, {
            type: 'bar',
            data: {
                labels: ['الصويفية', 'العبدلي', 'شارع الجامعة', 'الجبيهة', 'الشميساني', 'صويلح'],
                datasets: [
                    {
                        label: 'المبيعات (آلاف ₪)',
                        data: [228.5, 245, 198.4, 185.2, 165.8, 142.5],
                        backgroundColor: '#2c5aa0'
                    },
                    {
                        label: 'رضا العملاء %',
                        data: [96, 89, 92, 82, 85, 78],
                        backgroundColor: '#28a745',
                        yAxisID: 'y1'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'المبيعات (آلاف ₪)'
                        }
                    },
                    y1: {
                        position: 'right',
                        beginAtZero: true,
                        max: 100,
                        title: {
                            display: true,
                            text: 'رضا العملاء %'
                        },
                        grid: {
                            drawOnChartArea: false
                        }
                    }
                }
            }
        });
    }

    const efficiencyCtx = document.getElementById('orderEfficiencyChart')?.getContext('2d');
    if (efficiencyCtx) {
        new Chart(efficiencyCtx, {
            type: 'line',
            data: {
                labels: ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'],
                datasets: [
                    {
                        label: 'وقت المعالجة (دقيقة)',
                        data: [22.5, 21.8, 20.4, 19.2, 18.8, 18.5, 18.2, 18.0, 17.8, 17.5, 17.2, 17.0],
                        borderColor: '#dc3545',
                        backgroundColor: 'rgba(220, 53, 69, 0.1)',
                        tension: 0.4,
                        fill: true
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'وقت المعالجة (دقيقة)'
                        }
                    }
                }
            }
        });
    }

    const supplyCtx = document.getElementById('supplyChainChart')?.getContext('2d');
    if (supplyCtx) {
        new Chart(supplyCtx, {
            type: 'doughnut',
            data: {
                labels: ['الموردون الأساسيون', 'الموردون الثانويون', 'التخزين الداخلي', 'النقل الداخلي'],
                datasets: [{
                    data: [45, 25, 20, 10],
                    backgroundColor: [
                        '#2c5aa0',
                        '#28a745',
                        '#ffc107',
                        '#dc3545'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'توزيع تكاليف سلسلة التوريد'
                    }
                }
            }
        });
    }

    const orderValueCtx = document.getElementById('orderValueChart')?.getContext('2d');
    if (orderValueCtx) {
        new Chart(orderValueCtx, {
            type: 'bar',
            data: {
                labels: ['عالية (>150)', 'متوسطة (50-150)', 'منخفضة (<50)'],
                datasets: [{
                    label: 'عدد الطلبات',
                    data: [1248, 6542, 4690],
                    backgroundColor: ['#28a745', '#ffc107', '#dc3545']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    }

    const profitCtx = document.getElementById('profitMarginChart')?.getContext('2d');
    if (profitCtx) {
        new Chart(profitCtx, {
            type: 'line',
            data: {
                labels: ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'],
                datasets: [
                    {
                        label: 'هامش الربح %',
                        data: [32, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44],
                        borderColor: '#28a745',
                        backgroundColor: 'rgba(40, 167, 69, 0.1)',
                        tension: 0.4,
                        fill: true
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 50
                    }
                }
            }
        });
    }

    const clvCtx = document.getElementById('clvChart')?.getContext('2d');
    if (clvCtx) {
        new Chart(clvCtx, {
            type: 'line',
            data: {
                labels: ['2019', '2020', '2021', '2022', '2023'],
                datasets: [
                    {
                        label: 'VIP (بلاتينيوم)',
                        data: [6500, 7200, 7800, 8200, 8400],
                        borderColor: '#E5E4E2',
                        tension: 0.4
                    },
                    {
                        label: 'ذهبي',
                        data: [2800, 3000, 3100, 3150, 3200],
                        borderColor: '#FFD700',
                        tension: 0.4
                    },
                    {
                        label: 'فضي',
                        data: [1500, 1650, 1750, 1800, 1850],
                        borderColor: '#C0C0C0',
                        tension: 0.4
                    },
                    {
                        label: 'المتوسط العام',
                        data: [1800, 1950, 2150, 2350, 2480],
                        borderColor: '#2c5aa0',
                        borderWidth: 3,
                        tension: 0.4
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'متوسط CLV (₪)'
                        }
                    }
                }
            }
        });
    }

    const channelCtx = document.getElementById('interactionChannelChart')?.getContext('2d');
    if (channelCtx) {
        new Chart(channelCtx, {
            type: 'pie',
            data: {
                labels: ['الهاتف', 'الواتساب', 'البريد الإلكتروني', 'التطبيق', 'زيارة الفرع'],
                datasets: [{
                    data: [35, 28, 15, 18, 4],
                    backgroundColor: [
                        '#2c5aa0',
                        '#28a745',
                        '#ffc107',
                        '#dc3545',
                        '#6c757d'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'قنوات التواصل مع العملاء'
                    }
                }
            }
        });
    }

    const interactionCtx = document.getElementById('interactionTypeChart')?.getContext('2d');
    if (interactionCtx) {
        new Chart(interactionCtx, {
            type: 'bar',
            data: {
                labels: ['استفسارات', 'طلبات', 'شكاوى', 'مقترحات', 'متابعة'],
                datasets: [{
                    label: 'عدد التفاعلات',
                    data: [3245, 2854, 248, 185, 893],
                    backgroundColor: '#2c5aa0'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'عدد التفاعلات'
                        }
                    }
                }
            }
        });
    }

    const complaintCtx = document.getElementById('complaintTrendChart')?.getContext('2d');
    if (complaintCtx) {
        new Chart(complaintCtx, {
            type: 'line',
            data: {
                labels: ['يناير', 'فبراير', 'مارس'],
                datasets: [
                    {
                        label: 'عدد الشكاوى',
                        data: [95, 82, 71],
                        borderColor: '#dc3545',
                        backgroundColor: 'rgba(220, 53, 69, 0.1)',
                        tension: 0.4,
                        fill: true
                    },
                    {
                        label: 'معدل الحل %',
                        data: [88, 91, 94],
                        borderColor: '#28a745',
                        backgroundColor: 'transparent',
                        tension: 0.4,
                        yAxisID: 'y1'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'عدد الشكاوى'
                        }
                    },
                    y1: {
                        position: 'right',
                        beginAtZero: true,
                        max: 100,
                        title: {
                            display: true,
                            text: 'معدل الحل %'
                        },
                        grid: {
                            drawOnChartArea: false
                        }
                    }
                }
            }
        });
    }

    const dashboardPerfCtx = document.getElementById('dashboardPerformanceChart')?.getContext('2d');
    if (dashboardPerfCtx) {
        new Chart(dashboardPerfCtx, {
            type: 'radar',
            data: {
                labels: ['المبيعات', 'رضا العملاء', 'كفاءة الموظفين', 'الجودة', 'الربحية', 'النمو'],
                datasets: [
                    {
                        label: 'الأداء الفعلي',
                        data: [85, 94, 88, 90, 82, 78],
                        borderColor: '#2c5aa0',
                        backgroundColor: 'rgba(44, 90, 160, 0.2)'
                    },
                    {
                        label: 'الهدف',
                        data: [90, 95, 90, 92, 85, 85],
                        borderColor: '#28a745',
                        backgroundColor: 'transparent',
                        borderDash: [5, 5]
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    r: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });
    }

    const dashboardTrendCtx = document.getElementById('dashboardTrendChart')?.getContext('2d');
    if (dashboardTrendCtx) {
        new Chart(dashboardTrendCtx, {
            type: 'line',
            data: {
                labels: ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'],
                datasets: [
                    {
                        label: 'مؤشر الأداء',
                        data: [78, 80, 82, 81, 83, 85, 84, 86, 85, 87, 86, 85],
                        borderColor: '#2c5aa0',
                        backgroundColor: 'rgba(44, 90, 160, 0.1)',
                        tension: 0.4,
                        fill: true
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });
    }

    const todayPerfCtx = document.getElementById('todayPerformanceChart')?.getContext('2d');
    if (todayPerfCtx) {
        const now = new Date();
        const hours = [];
        const data = [];
       
        for (let i = 8; i <= now.getHours(); i++) {
            hours.push(i + ':00');
            let value = 20 + Math.random() * 80;
            if (i >= 12 && i <= 14) value = 60 + Math.random() * 40;
            if (i >= 19 && i <= 21) value = 70 + Math.random() * 30;
            data.push(Math.round(value));
        }
       
        new Chart(todayPerfCtx, {
            type: 'line',
            data: {
                labels: hours,
                datasets: [
                    {
                        label: 'طلبات/ساعة',
                        data: data,
                        borderColor: '#2c5aa0',
                        backgroundColor: 'rgba(44, 90, 160, 0.1)',
                        tension: 0.4,
                        fill: true
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'عدد الطلبات'
                        }
                    }
                }
            }
        });
    }
}

function showReport(reportId) {
    $('.report-view').removeClass('active');
    
    const $targetReport = $(`#${reportId}`);
    if ($targetReport.length) {
        $targetReport.addClass('active');
        
        $('#reportTabs .report-tab').removeClass('active');
        $(`.report-tab[data-report="${reportId}"]`).addClass('active');
        
        $('.report-link').removeClass('active');
        $(`.report-link[data-report="${reportId}"]`).addClass('active');
    } else {
        $('#loyalty-distribution').addClass('active');
    }
}

function addReportTab(reportId, reportName, reportIcon) {
    let tabExists = false;
    $('#reportTabs .report-tab').each(function() {
        if ($(this).data('report') === reportId) {
            tabExists = true;
            return false;
        }
    });
    
    if (!tabExists) {
        const newTab = `
            <div class="report-tab" data-report="${reportId}">
                <i class="${reportIcon}"></i>
                <span>${reportName}</span>
                <span class="report-tab-close"><i class="fas fa-times"></i></span>
            </div>
        `;
        $('#reportTabs').append(newTab);
        
        if ($('#reportTabs .report-tab').length > 5) {
            $('#reportTabs .report-tab:first').remove();
        }
    }
}

function initSidebar() {
    $('#reportSearch').on('input', function() {
        const searchTerm = $(this).val().toLowerCase();
        if (searchTerm.length === 0) {
            $('.report-item').show();
            return;
        }
       
        $('.report-item').each(function() {
            const text = $(this).text().toLowerCase();
            if (text.includes(searchTerm)) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    });
   
    $(document).on('click', '.report-link', function(e) {
        e.preventDefault();
        e.stopPropagation();
        
        $('.report-link').removeClass('active');
        $(this).addClass('active');
       
        const reportId = $(this).data('report');
        const reportName = $(this).find('span').text().trim() || $(this).text().trim();
        const reportIcon = $(this).find('i').attr('class');
       
        markRecentlyViewed(reportId);
       
        $('.loading').show();
       
        setTimeout(() => {
            showReport(reportId);
            addReportTab(reportId, reportName, reportIcon);
            $('#reportTabs .report-tab').removeClass('active');
            $(`.report-tab[data-report="${reportId}"]`).addClass('active');
            $('.loading').hide();
        }, 300);
    });
   
    const recentReports = JSON.parse(localStorage.getItem('recentReports') || '[]');
    updateRecentlyViewedIndicators(recentReports);
}

function initTabs() {
    $(document).on('click', '.report-tab', function(e) {
        e.stopPropagation();
        
        const reportId = $(this).data('report');
        showReport(reportId);
        $('.report-link').removeClass('active');
        $(`.report-link[data-report="${reportId}"]`).addClass('active');
    });
   
    $(document).on('click', '.report-tab-close', function(e) {
        e.stopPropagation();
       
        const tab = $(this).closest('.report-tab');
        const reportId = tab.data('report');
       
        if (tab.hasClass('active')) {
            const nextTab = tab.next('.report-tab');
            const prevTab = tab.prev('.report-tab');
           
            if (nextTab.length > 0) {
                nextTab.click();
            } else if (prevTab.length > 0) {
                prevTab.click();
            } else {
                showReport('loyalty-distribution');
                $('.report-link').removeClass('active');
                $('.report-link[data-report="loyalty-distribution"]').addClass('active');
            }
        }
       
        tab.remove();
    });
}

function initQuickStats() {
    updateQuickStats();
    setInterval(updateQuickStats, 30000);
}

function markRecentlyViewed(reportId) {
    let recentReports = JSON.parse(localStorage.getItem('recentReports') || '[]');
    recentReports = recentReports.filter(id => id !== reportId);
    recentReports.unshift(reportId);
    recentReports = recentReports.slice(0, 5);
    localStorage.setItem('recentReports', JSON.stringify(recentReports));
    updateRecentlyViewedIndicators(recentReports);
}

function updateRecentlyViewedIndicators(recentReports) {
    $('.report-link').removeClass('recently-viewed');
    recentReports.forEach(reportId => {
        $(`.report-link[data-report="${reportId}"]`).addClass('recently-viewed');
    });
}

function updateQuickStats() {
    const today = new Date();
    const hours = today.getHours();
   
    let activeCustomers = 428;
    let avgOrders = 2.4;
    let returningThisMonth = 1248;
   
    if (hours >= 12 && hours < 15) {
        activeCustomers = Math.floor(Math.random() * 50) + 480;
        avgOrders = 2.8;
    } else if (hours >= 18 && hours < 21) {
        activeCustomers = Math.floor(Math.random() * 60) + 520;
        avgOrders = 3.2;
    } else {
        activeCustomers = Math.floor(Math.random() * 30) + 400;
    }
   
    $('.quick-stats .stat-item:nth-child(1) .stat-value').text(activeCustomers.toLocaleString());
    $('.quick-stats .stat-item:nth-child(2) .stat-value').text(avgOrders.toFixed(1));
    $('.quick-stats .stat-item:nth-child(3) .stat-value').text(returningThisMonth.toLocaleString());
}

function initNewReportButtons() {
    $(document).on('click', '.btn-outline-secondary:contains("طباعة")', function() {
        const reportTitle = $(this).closest('.dashboard-card').find('.card-title').text();
        alert(`جاري طباعة تقرير: ${reportTitle}\nسيتم فتح نافذة الطباعة.`);
        window.print();
    });

    $(document).on('click', '.btn-primary:contains("تصدير")', function() {
        const reportTitle = $(this).closest('.dashboard-card').find('.card-title').text();
        alert(`جاري تصدير تقرير: ${reportTitle}\nسيتم تحميل ملف Excel.`);
        setTimeout(() => {
            alert('تم تصدير التقرير بنجاح!');
        }, 1500);
    });

    $('.btn-primary:contains("تقرير جديد")').click(function() {
        $('.loading').show();
        setTimeout(() => {
            $('.loading').hide();
            $('.report-link[data-report="custom-report-builder"]').click();
        }, 1000);
    });

    $(document).on('click', '.btn-sm', function() {
        const action = $(this).text();
        const row = $(this).closest('tr');
        const name = row.find('td').eq(1).text().trim();
       
        switch(action) {
            case 'حملة ولاء حصرية':
                alert(`جاري إطلاق حملة ولاء حصرية لـ ${name}`);
                break;
            case 'عرض ترقية':
                alert(`جاري إرسال عرض ترقية لـ ${name}`);
                break;
            case 'تحفيز العودة':
                alert(`جاري إرسال تحفيز العودة لـ ${name}`);
                break;
            case 'إعادة جذب عاجلة':
                alert(`جاري إطلاق حملة إعادة جذب عاجلة لـ ${name}`);
                break;
            case 'ترقية':
                alert(`جاري ترقية الموظف: ${name}`);
                break;
            case 'مكافأة':
                alert(`جاري منح مكافأة للموظف: ${name}`);
                break;
            case 'تدريب':
                alert(`جاري جدولة تدريب للموظف: ${name}`);
                break;
            case 'مراجعة':
                alert(`جاري جدولة مراجعة أداء للموظف: ${name}`);
                break;
            case 'تفاصيل التحقيق':
                alert(`جاري فتح صفحة تفاصيل التحقيق للتنبيه`);
                break;
            case 'بدء خطة علاجية':
                alert(`جاري إنشاء خطة علاجية جديدة`);
                break;
            case 'تحليل الأسباب':
                alert(`جاري تحليل أسباب المشكلة`);
                break;
            case 'إعادة توزيع المهام':
                alert(`جاري إعادة توزيع المهام على الموظفين`);
                break;
        }
    });

    $('.btn-primary:contains("إنشاء التقرير الآن")').click(function() {
        $('.loading').show();
        setTimeout(() => {
            $('.loading').hide();
            alert('تم إنشاء التقرير المخصص بنجاح!\nيمكنك عرضه الآن في قائمة التقارير.');
        }, 2000);
    });

    $('.btn-outline-secondary:contains("معاينة قبل الإنشاء")').click(function() {
        alert('جاري تحميل معاينة التقرير...\nستظهر المعاينة في نافذة منبثقة.');
    });

    $('.btn-outline-primary:contains("تحميل")').click(function() {
        const templateName = $(this).closest('.card').find('.card-title').text();
        alert(`جاري تحميل قالب: ${templateName}`);
    });

    $('.btn-danger:contains("معالجة الكل")').click(function() {
        if (confirm('هل أنت متأكد من معالجة جميع التنبيهات العاجلة؟')) {
            $('.alert').fadeOut();
            alert('تمت معالجة جميع التنبيهات بنجاح.');
        }
    });

    $('.btn-primary:contains("تحديث الآن")').click(function() {
        $('.loading').show();
        setTimeout(() => {
            $('.loading').hide();
            alert('تم تحديث بيانات أداء اليوم بنجاح.');
            updateQuickStats();
        }, 1000);
    });
}