document.addEventListener('DOMContentLoaded', function() {
    const navbarToggle = document.getElementById('navbarToggle');
    const navbarNav = document.getElementById('navbarNav');
    
    if (navbarToggle && navbarNav) {
        navbarToggle.addEventListener('click', function() {
            navbarNav.classList.toggle('show');
            this.innerHTML = navbarNav.classList.contains('show') 
                ? '<i class="fas fa-times"></i>' 
                : '<i class="fas fa-bars"></i>';
        });

        document.addEventListener('click', function(event) {
            if (!navbarNav.contains(event.target) && !navbarToggle.contains(event.target)) {
                navbarNav.classList.remove('show');
                navbarToggle.innerHTML = '<i class="fas fa-bars"></i>';
            }
        });
    }

    document.querySelectorAll('.language-tab').forEach(tab => {
        tab.addEventListener('click', function() {
            document.querySelectorAll('.language-tab').forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            
            const lang = this.dataset.lang;
            showToast(`تم التبديل إلى ${lang === 'ar' ? 'اللغة العربية' : 'اللغة الإنجليزية'}`);
        });
    });

    document.getElementById('uploadLogo').addEventListener('click', function() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = 'image/*';
        input.onchange = function(e) {
            if (e.target.files[0]) {
                const reader = new FileReader();
                reader.onload = function(event) {
                    document.querySelectorAll('.logo-preview img').forEach(img => {
                        img.src = event.target.result;
                    });
                    showToast('تم رفع الشعار بنجاح');
                };
                reader.readAsDataURL(e.target.files[0]);
            }
        };
        input.click();
    });

    document.getElementById('saveBtn').addEventListener('click', function() {
        showLoading();
        setTimeout(() => {
            hideLoading();
            showToast('تم حفظ جميع الإعدادات بنجاح');
        }, 1500);
    });

    document.getElementById('resetBtn').addEventListener('click', function() {
        if (confirm('هل أنت متأكد من إعادة تعيين جميع الإعدادات؟ سيتم فقدان جميع التغييرات غير المحفوظة.')) {
            showLoading();
            setTimeout(() => {
                hideLoading();
                document.querySelectorAll('.form-control').forEach(input => {
                    if (input.tagName === 'INPUT') {
                        input.value = input.defaultValue;
                    } else if (input.tagName === 'TEXTAREA') {
                        input.value = input.defaultValue;
                    }
                });
                showToast('تم إعادة تعيين جميع الإعدادات');
            }, 1000);
        }
    });

    document.querySelector('.notification-icon').addEventListener('click', function() {
        alert('التنبيهات:\n1. إعدادات النظام تم تحديثها\n2. هناك 3 مطاعم تحتاج تفعيل\n3. تقرير الأداء الأسبوعي جاهز');
    });

    const newsletterBtn = document.querySelector('.newsletter-btn');
    if (newsletterBtn) {
        newsletterBtn.addEventListener('click', function() {
            const emailInput = document.querySelector('.newsletter-input');
            if (emailInput && emailInput.value) {
                showToast('تم الاشتراك في النشرة البريدية بنجاح', 'success');
                emailInput.value = '';
            } else {
                showToast('يرجى إدخال بريد إلكتروني', 'error');
            }
        });
    }

    document.querySelectorAll('.social-links a').forEach(link => {
        link.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
        });
        
        link.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });

    let saveTimeout;
    document.querySelectorAll('.form-control').forEach(input => {
        input.addEventListener('input', function() {
            clearTimeout(saveTimeout);
            saveTimeout = setTimeout(() => {
                showToast('تغييرات غير محفوظة - اضغط على زر الحفظ', 'warning');
            }, 5000);
        });
    });

    document.addEventListener('keydown', function(e) {
        if ((e.ctrlKey || e.metaKey) && e.key === 's') {
            e.preventDefault();
            document.getElementById('saveBtn').click();
        }
        if (e.key === 'Escape') {
            document.getElementById('resetBtn').click();
        }
    });
});

function showToast(message, type = 'success') {
    const toast = document.getElementById('toast');
    const toastMessage = document.getElementById('toastMessage');
    
    if (type === 'error') {
        toast.style.background = 'var(--danger-color)';
    } else if (type === 'warning') {
        toast.style.background = 'var(--warning-color)';
    } else {
        toast.style.background = 'var(--success-color)';
    }
    
    toastMessage.textContent = message;
    toast.style.display = 'flex';
    
    setTimeout(() => {
        toast.style.animation = 'slideIn 0.3s ease reverse';
        setTimeout(() => {
            toast.style.display = 'none';
            toast.style.animation = 'slideIn 0.3s ease';
        }, 300);
    }, 3000);
}

function showLoading() {
    const loading = document.getElementById('loading');
    if (loading) loading.style.display = 'block';
}

function hideLoading() {
    const loading = document.getElementById('loading');
    if (loading) loading.style.display = 'none';
}