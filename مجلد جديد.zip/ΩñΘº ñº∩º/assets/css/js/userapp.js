const appUsersData = [
    {
        id: 1,
        name: "أحمد ",
        username: "ahmed_m",
        email: "ahmed@jordansteps.com",
        phone: "0791234567",
        role: "branch_manager",
        restaurant: "Fire-Fly",
        branch: "فرع خلدا",
        active: true,
        created: "2024-01-15",
        lastLogin: "2024-03-20",
        avatarColor: "#dc3545"
    },
    {
        id: 2,
        name: "سارة",
        username: "sara_k",
        email: "sara@jordansteps.com",
        phone: "0797654321",
        role: "Kitchen chef",
        restaurant: "Subway",
        branch: "جبيهة",
        active: true,
        created: "2024-02-20",
        lastLogin: "2024-03-19",
        avatarColor: "#28a745"
    },
    {
        id: 3,
        name: "محمد",
        username: "mohammed_a",
        email: "mohammed@jordansteps.com",
        phone: "0795554444",
        role: "Cashier",
        restaurant: "Wazzap Dog",
        branch: "خلدا",
        active: true,
        created: "2024-03-10",
        lastLogin: "2024-03-18",
        avatarColor: "#17a2b8"
    },
    {
        id: 4,
        name: "يوسف",
        username: "yousef_a",
        email: "yousef@jordansteps.com",
        phone: "0796667777",
        role: "Branch Printer",
        restaurant: "Tandoori Master",
        branch: "الجبيهة",
        active: false,
        created: "2024-04-05",
        lastLogin: "2024-02-15",
        avatarColor: "#ffc107"
    },
    {
        id: 5,
        name: "فاطمة",
        username: "fatima_y",
        email: "fatima@jordansteps.com",
        phone: "0798889999",
        role: "Cashier & Kitchen",
        restaurant: "Fire-Fly",
        branch: "الجبيهة",
        active: true,
        created: "2024-05-15",
        lastLogin: "2024-03-17",
        avatarColor: "#6f42c1"
    },
    {
        id: 6,
        name: "خالد",
        username: "khaled_s",
        email: "khaled@jordansteps.com",
        phone: "0791112222",
        role: "Kitchen tablet",
        restaurant: "Subway",
        branch: "خلدا",
        active: true,
        created: "2024-06-22",
        lastLogin: "2024-03-16",
        avatarColor: "#2c5aa0"
    },
    {
        id: 7,
        name: "نور",
        username: "nour_m",
        email: "nour@jordansteps.com",
        phone: "0793334444",
        role: "branch_manager",
        restaurant: "Wazzap Dog",
        branch: "خلدا",
        active: true,
        created: "2024-07-18",
        lastLogin: "2024-03-15",
        avatarColor: "#e83e8c"
    },
    {
        id: 8,
        name: "علي",
        username: "ali_h",
        email: "ali@jordansteps.com",
        phone: "0795556666",
        role: "Delivery Orders only",
        restaurant: "Tandoori Master",
        branch: "الجبيهة",
        active: false,
        created: "2024-08-30",
        lastLogin: "2024-01-20",
        avatarColor: "#20c997"
    },
];

document.addEventListener('DOMContentLoaded', function() {
    initApp();
});

function initApp() {
    document.getElementById('navbarToggle').addEventListener('click', function() {
        const navbarNav = document.getElementById('navbarNav');
        navbarNav.classList.toggle('show');
        this.innerHTML = navbarNav.classList.contains('show') 
            ? '<i class="fas fa-times"></i>' 
            : '<i class="fas fa-bars"></i>';
    });

    document.addEventListener('click', function(event) {
        const navbarNav = document.getElementById('navbarNav');
        const navbarToggle = document.getElementById('navbarToggle');
        
        if (!navbarNav.contains(event.target) && !navbarToggle.contains(event.target)) {
            navbarNav.classList.remove('show');
            navbarToggle.innerHTML = '<i class="fas fa-bars"></i>';
        }
    });

    document.getElementById('addUserBtn').addEventListener('click', function() {
        const fullName = document.getElementById('fullName').value;
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const role = document.getElementById('role').value;
        const restaurant = document.getElementById('restaurant').value;
        const branch = document.getElementById('branch').value;
        const email = document.getElementById('email').value;
        const phone = document.getElementById('phone').value;
        
        if (fullName && username && password && restaurant && branch) {
            showLoading();
            
            const newUser = {
                id: appUsersData.length + 1,
                name: fullName,
                username: username.toLowerCase().replace(/\s+/g, '_'),
                email: email || `${username}@jordansteps.com`,
                phone: phone || "0790000000",
                role: role,
                restaurant: getRestaurantName(restaurant),
                branch: getBranchName(branch),
                active: true,
                created: new Date().toISOString().split('T')[0],
                lastLogin: new Date().toISOString().split('T')[0],
                avatarColor: getRandomColor()
            };
            
            setTimeout(() => {
                appUsersData.unshift(newUser);
                renderTable();
                updateStats();
                hideLoading();
                
                showNotification(`تم إضافة المستخدم "${fullName}" بنجاح`, 'success');
                
                document.querySelectorAll('.form-control').forEach(input => {
                    input.value = '';
                });
            }, 1500);
        } else {
            showNotification('يرجى ملء جميع الحقول المطلوبة (*)', 'error');
        }
    });

    document.getElementById('resetBtn').addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelectorAll('.form-control').forEach(input => {
            input.value = '';
        });
        showNotification('تم إعادة تعيين جميع الحقول بنجاح', 'success');
    });

    document.getElementById('bulkAddBtn').addEventListener('click', function() {
        showNotification('فتح نافذة الإضافة الجماعية للمستخدمين', 'info');
    });

    document.getElementById('exportBtn').addEventListener('click', function() {
        showLoading();
        setTimeout(() => {
            hideLoading();
            showNotification('تم تصدير بيانات المستخدمين بنجاح', 'success');
        }, 1000);
    });

    document.getElementById('filterBtn').addEventListener('click', function() {
        showNotification('فتح نافذة تصفية المستخدمين', 'info');
    });

    document.getElementById('searchInput').addEventListener('input', function(e) {
        const searchTerm = e.target.value.toLowerCase();
        if (searchTerm.length >= 2) {
            const filtered = appUsersData.filter(user => 
                user.name.toLowerCase().includes(searchTerm) ||
                user.username.toLowerCase().includes(searchTerm) ||
                user.email.toLowerCase().includes(searchTerm) ||
                user.restaurant.toLowerCase().includes(searchTerm) ||
                user.branch.toLowerCase().includes(searchTerm)
            );
            renderTable(filtered);
        } else if (searchTerm.length === 0) {
            renderTable();
        }
    });

    document.getElementById('prevBtn').addEventListener('click', function() {
        showNotification('الانتقال للصفحة السابقة', 'info');
    });

    document.getElementById('nextBtn').addEventListener('click', function() {
        showNotification('الانتقال للصفحة التالية', 'info');
    });

    document.getElementById('notificationIcon').addEventListener('click', function() {
        showNotification('لديك 4 تنبيهات جديدة', 'info');
    });

    const newsletterBtn = document.querySelector('.newsletter-btn');
    if (newsletterBtn) {
        newsletterBtn.addEventListener('click', function() {
            const emailInput = document.querySelector('.newsletter-input');
            if (emailInput && emailInput.value) {
                showNotification('تم الاشتراك في النشرة البريدية بنجاح', 'success');
                emailInput.value = '';
            } else {
                showNotification('يرجى إدخال بريد إلكتروني', 'error');
            }
        });
    }

    document.querySelectorAll('.social-links a').forEach(link => {
        link.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
        });
        
        link.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });

    renderTable();
    updateStats();
}

function renderTable(users = appUsersData) {
    const tableBody = document.querySelector('#usersTable tbody');
    
    tableBody.innerHTML = '';
    
    users.forEach(user => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>
                <div class="user-info-cell">
                    <div class="user-avatar-small" style="background: ${user.avatarColor}">
                        ${user.name.charAt(0).toUpperCase()}
                    </div>
                    <div class="user-details">
                        <div class="name">${user.name}</div>
                        <div class="meta">
                            <i class="fas fa-envelope"></i> ${user.email}<br>
                            <i class="fas fa-phone"></i> ${user.phone}
                        </div>
                    </div>
                </div>
            </td>
            <td>
                <div style="font-weight: 600; color: var(--primary-color); margin-bottom: 5px;">
                    ${user.username}
                </div>
                <div style="font-size: 11px; color: var(--gray-color);">
                    ID: ${user.id}
                </div>
            </td>
            <td>
                <span class="role-badge ${getRoleBadgeClass(user.role)}">
                    <i class="fas ${getRoleIcon(user.role)}"></i>
                    ${getRoleText(user.role)}
                </span>
            </td>
            <td>
                <div style="font-weight: 600;">${user.restaurant}</div>
                <div style="font-size: 11px; color: var(--gray-color); margin-top: 3px;">
                    <i class="fas fa-utensils"></i>
                </div>
            </td>
            <td>
                <div style="font-weight: 600;">${user.branch}</div>
                <div style="font-size: 11px; color: var(--gray-color); margin-top: 3px;">
                    <i class="fas fa-map-marker-alt"></i>
                </div>
            </td>
            <td>
                <div class="status-toggle ${user.active ? 'active' : ''}" 
                     onclick="toggleUserStatus(${user.id})" 
                     title="${user.active ? 'نشط - انقر لإلغاء التفعيل' : 'معطل - انقر للتفعيل'}">
                </div>
                <div style="font-size: 11px; color: ${user.active ? 'var(--success-color)' : 'var(--gray-color)'}; margin-top: 5px;">
                    ${user.active ? '✅ نشط' : '⛔ معطل'}
                </div>
                <div style="font-size: 10px; color: var(--gray-color); margin-top: 2px;">
                    ${user.lastLogin}
                </div>
            </td>
            <td>
                <div class="action-buttons">
                    <button class="btn-icon btn-reset" title="إعادة تعيين كلمة المرور" onclick="resetPassword(${user.id})">
                        <i class="fas fa-key"></i>
                    </button>
                    <button class="btn-icon btn-api" title="إدارة API والصلاحيات" onclick="manageAPI(${user.id})">
                        <i class="fas fa-code"></i>
                    </button>
                    <button class="btn-icon btn-edit" title="تعديل بيانات المستخدم" onclick="editUser(${user.id})">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn-icon btn-delete" title="حذف المستخدم" onclick="deleteUser(${user.id})">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
                <div style="font-size: 11px; color: var(--gray-color); margin-top: 5px;">
                    تم الإنشاء: ${user.created}
                </div>
            </td>
        `;
        tableBody.appendChild(row);
    });
}

function updateStats() {
    const total = appUsersData.length;
    const active = appUsersData.filter(u => u.active).length;
    const restaurants = [...new Set(appUsersData.filter(u => u.active).map(u => u.restaurant))].length;
    const branches = [...new Set(appUsersData.filter(u => u.active).map(u => u.branch))].length;
    
    document.getElementById('totalUsers').textContent = total;
    document.getElementById('activeUsers').textContent = active;
    document.getElementById('activeRestaurants').textContent = restaurants;
    document.getElementById('activeBranches').textContent = branches;
}

function getRestaurantName(value) {
    const restaurants = {
        'fire-fly': 'Fire-Fly',
        'subway': 'Subway',
        'wazzap-dog': 'Wazzap Dog',
        'Shanab Shawerma': 'Shanab Shawerma',
        'grillo shawarma': 'grillo shawarma',
        'MLT Burger': 'MLT Burger',
        'فروج ابو العبد': 'فروج ابو العبد',
        'عصير تايم': 'عصير تايم',
        'spot sandwich': 'Spot sandwich',
        'tandoori master': 'Tandoori Master'
    };
    return restaurants[value] || value;
}

function getBranchName(value) {
    const branches = {
        'khalda': 'فرع خلدا',
        'jubeiha': 'الجبيهة',
    };
    return branches[value] || value;
}

function getRoleText(role) {
    const roles = {
        'branch_manager': 'مدير فرع',
        'Kitchen chef': 'شيف المطبخ',
        'Cashier': 'كاشير',
        'Kitchen tablet': 'تابلت المطبخ',
        'Cashier & Kitchen': 'كاشير ومطبخ',
        'Delivery Orders only': 'طلبات التوصيل فقط',
        'Central Printer': 'الطابعة المركزية',
        'Branch Printer': 'طابعة الفرع'
    };
    return roles[role] || role;
}

function getRoleIcon(role) {
    const icons = {
        'branch_manager': 'fa-user-tie',
        'Kitchen chef': 'fa-utensils',
        'Cashier': 'fa-cash-register',
        'Kitchen tablet': 'fa-tablet-alt',
        'Cashier & Kitchen': 'fa-tasks',
        'Delivery Orders only': 'fa-shipping-fast',
        'Central Printer': 'fa-print',
        'Branch Printer': 'fa-print'
    };
    return icons[role] || 'fa-user';
}

function getRoleBadgeClass(role) {
    const classes = {
        'branch_manager': 'badge-manager',
        'Kitchen chef': 'badge-employee',
        'Cashier': 'badge-employee',
        'Kitchen tablet': 'badge-employee',
        'Cashier & Kitchen': 'badge-employee',
        'Delivery Orders only': 'badge-employee',
        'Central Printer': 'badge-printer',
        'Branch Printer': 'badge-printer'
    };
    return classes[role] || 'badge-employee';
}

function getRandomColor() {
    const colors = [
        '#dc3545', '#28a745', '#17a2b8', '#ffc107',
        '#6c757d', '#2c5aa0', '#6610f2', '#e83e8c',
        '#fd7e14', '#20c997', '#6f42c1'
    ];
    return colors[Math.floor(Math.random() * colors.length)];
}

function toggleUserStatus(id) {
    const user = appUsersData.find(u => u.id === id);
    if (user) {
        user.active = !user.active;
        user.lastLogin = new Date().toISOString().split('T')[0];
        const status = user.active ? 'تفعيل' : 'إلغاء تفعيل';
        showNotification(`تم ${status} المستخدم "${user.name}"`, 'success');
        renderTable();
        updateStats();
    }
}

function editUser(id) {
    const user = appUsersData.find(u => u.id === id);
    if (user) {
        document.getElementById('fullName').value = user.name;
        document.getElementById('username').value = user.username;
        document.getElementById('password').value = '********';
        document.getElementById('role').value = user.role;
        document.getElementById('email').value = user.email;
        document.getElementById('phone').value = user.phone;
        
        showNotification(`جاري تعديل بيانات "${user.name}"`, 'info');
        
        document.querySelector('.form-container').scrollIntoView({ behavior: 'smooth' });
    }
}

function resetPassword(id) {
    const user = appUsersData.find(u => u.id === id);
    if (user) {
        if (confirm(`هل تريد إعادة تعيين كلمة مرور المستخدم "${user.name}"؟`)) {
            showLoading();
            setTimeout(() => {
                hideLoading();
                showNotification(`تم إعادة تعيين كلمة المرور للمستخدم "${user.name}"`, 'success');
            }, 1000);
        }
    }
}

function manageAPI(id) {
    const user = appUsersData.find(u => u.id === id);
    if (user) {
        showNotification(`فتح صفحة إدارة API والصلاحيات للمستخدم "${user.name}"`, 'info');
    }
}

function deleteUser(id) {
    const user = appUsersData.find(u => u.id === id);
    if (user && confirm(`هل أنت متأكد من حذف المستخدم "${user.name}"؟\nهذا الإجراء لا يمكن التراجع عنه.`)) {
        const index = appUsersData.findIndex(u => u.id === id);
        if (index !== -1) {
            appUsersData.splice(index, 1);
            renderTable();
            updateStats();
            showNotification(`تم حذف المستخدم "${user.name}" بنجاح`, 'success');
        }
    }
}

function showNotification(message, type = 'info') {
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => notification.remove());
    
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : type === 'warning' ? 'exclamation-triangle' : 'info-circle'}"></i>
        ${message}
    `;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

function showLoading() {
    document.getElementById('loading').style.display = 'block';
}

function hideLoading() {
    document.getElementById('loading').style.display = 'none';
}