const usersData = [
    {
        id: 1,
        username: "admin",
        displayName: "مدير النظام",
        email: "admin@jordansteps.com",
        type: "admin",
        status: "active",
        lastLogin: "الآن",
        createdAt: "2023-01-15"
    },
    {
        id: 2,
        username: "osama",
        displayName: "أسامة",
        email: "o.rabadi@mystore.jo",
        type: "rest_owner",
        status: "inactive",
        lastLogin: "2025-06-24 06:55",
        createdAt: "2024-05-20"
    },
    {
        id: 3,
        username: "ahmed",
        displayName: "أحمد",
        email: "yhammed999@gmail.com",
        type: "rest_owner",
        status: "inactive",
        lastLogin: "—",
        createdAt: "2024-08-15"
    },
    {
        id: 4,
        username: "محمد",
        displayName: "محمد",
        email: "Mohammad@hotmail.com",
        type: "emp",
        status: "active",
        lastLogin: "2025-10-09 11:57",
        createdAt: "2024-11-03"
    },
    {
        id: 5,
        username: "محمود",
        displayName: "محمود",
        email: "mariam@jordansteps.com",
        type: "admin",
        status: "active",
        lastLogin: "الآن",
        createdAt: "2024-01-10"
    },
    {
        id: 6,
        username: "خالد",
        displayName: "خالد",
        email: "ahmed@restaurant.com",
        type: "rest_owner",
        status: "active",
        lastLogin: "2025-11-15 09:30",
        createdAt: "2024-03-22"
    },
    {
        id: 7,
        username: "سارة",
        displayName: "سارة الموظفة",
        email: "sara@company.com",
        type: "emp",
        status: "active",
        lastLogin: "2025-11-14 16:45",
        createdAt: "2024-06-18"
    },
    {
        id: 8,
        username: "user123",
        displayName: "مستخدم عادي",
        email: "user123@gmail.com",
        type: "user",
        status: "inactive",
        lastLogin: "2025-10-30 14:20",
        createdAt: "2024-09-05"
    }
];

let currentPage = 1;
const itemsPerPage = 6;
let filteredUsers = [...usersData];
let editingUserId = null;

document.addEventListener('DOMContentLoaded', function() {
    initApp();
});

function initApp() {
    document.getElementById('navbarToggle').addEventListener('click', function() {
        const navbarNav = document.querySelector('.navbar-nav');
        if (navbarNav) {
            navbarNav.classList.toggle('show');
            this.innerHTML = navbarNav.classList.contains('show') 
                ? '<i class="fas fa-times"></i>' 
                : '<i class="fas fa-bars"></i>';
        }
    });

    document.addEventListener('click', function(event) {
        const navbarNav = document.querySelector('.navbar-nav');
        const navbarToggle = document.getElementById('navbarToggle');
        
        if (!navbarNav.contains(event.target) && !navbarToggle.contains(event.target)) {
            navbarNav.classList.remove('show');
            if (navbarToggle) navbarToggle.innerHTML = '<i class="fas fa-bars"></i>';
        }
    });

    const modal = document.getElementById('userModal');
    const modalClose = document.getElementById('modalClose');
    const modalCancel = document.getElementById('modalCancel');

    document.getElementById('addUserBtn').addEventListener('click', function() {
        editingUserId = null;
        document.getElementById('modalTitle').textContent = 'إضافة مستخدم جديد';
        document.getElementById('modalPassword').required = true;
        resetModalForm();
        modal.style.display = 'flex';
    });

    modalClose.addEventListener('click', function() {
        modal.style.display = 'none';
    });

    modalCancel.addEventListener('click', function() {
        modal.style.display = 'none';
    });

    window.addEventListener('click', function(event) {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });

    document.getElementById('userForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const username = document.getElementById('modalUsername').value;
        const email = document.getElementById('modalEmail').value;
        const type = document.getElementById('modalType').value;
        const displayName = document.getElementById('modalDisplayName').value;
        
        if (editingUserId) {
            const userIndex = usersData.findIndex(u => u.id === editingUserId);
            if (userIndex !== -1) {
                usersData[userIndex] = {
                    ...usersData[userIndex],
                    username,
                    email,
                    type,
                    displayName
                };
                showNotification(`تم تحديث المستخدم "${username}" بنجاح`, 'success');
            }
        } else {
            const newUser = {
                id: usersData.length + 1,
                username,
                displayName: displayName || username,
                email,
                type,
                status: "active",
                lastLogin: "—",
                createdAt: new Date().toISOString().split('T')[0]
            };
            usersData.unshift(newUser);
            showNotification(`تم إضافة المستخدم "${username}" بنجاح`, 'success');
        }
        
        filteredUsers = [...usersData];
        currentPage = 1;
        renderTable();
        updateStats();
        modal.style.display = 'none';
    });

    document.getElementById('searchBtn').addEventListener('click', function() {
        performSearch();
    });

    document.getElementById('searchForm').addEventListener('submit', function(e) {
        e.preventDefault();
        performSearch();
    });

    document.getElementById('resetBtn').addEventListener('click', function(e) {
        e.preventDefault();
        document.getElementById('usernameSearch').value = '';
        document.getElementById('emailSearch').value = '';
        document.getElementById('typeSearch').value = '';
        document.getElementById('statusSearch').value = '';
        filteredUsers = [...usersData];
        currentPage = 1;
        renderTable();
        updateStats();
        showNotification('تم إعادة تعيين جميع الحقول بنجاح', 'success');
    });

    document.getElementById('exportBtn').addEventListener('click', function() {
        showLoading();
        setTimeout(() => {
            hideLoading();
            showNotification('تم تصدير بيانات المستخدمين بنجاح', 'success');
        }, 1000);
    });

    document.getElementById('refreshBtn').addEventListener('click', function() {
        showLoading();
        setTimeout(() => {
            renderTable();
            updateStats();
            hideLoading();
            showNotification('تم تحديث البيانات', 'success');
        }, 800);
    });

    document.getElementById('bulkActionsBtn').addEventListener('click', function() {
        showNotification('فتح نافذة الإجراءات الجماعية', 'info');
    });

    document.getElementById('notificationIcon').addEventListener('click', function() {
        showNotification('لديك 5 تنبيهات جديدة', 'info');
    });

    const newsletterBtn = document.querySelector('.newsletter-btn');
    if (newsletterBtn) {
        newsletterBtn.addEventListener('click', function() {
            const emailInput = document.querySelector('.newsletter-input');
            if (emailInput && emailInput.value) {
                showNotification('تم الاشتراك في النشرة البريدية بنجاح', 'success');
                emailInput.value = '';
            } else {
                showNotification('يرجى إدخال بريد إلكتروني', 'error');
            }
        });
    }

    document.querySelectorAll('.social-links a').forEach(link => {
        link.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
        });
        
        link.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });

    renderTable();
    updateStats();
}

function performSearch() {
    const username = document.getElementById('usernameSearch').value.toLowerCase();
    const email = document.getElementById('emailSearch').value.toLowerCase();
    const type = document.getElementById('typeSearch').value;
    const status = document.getElementById('statusSearch').value;
    
    filteredUsers = usersData.filter(user => {
        let matches = true;
        
        if (username && !user.username.toLowerCase().includes(username)) {
            matches = false;
        }
        
        if (email && !user.email.toLowerCase().includes(email)) {
            matches = false;
        }
        
        if (type && user.type !== type) {
            matches = false;
        }
        
        if (status && user.status !== status) {
            matches = false;
        }
        
        return matches;
    });
    
    currentPage = 1;
    renderTable();
    showNotification(`تم العثور على ${filteredUsers.length} مستخدم`, 'success');
}

function renderTable() {
    const tableBody = document.getElementById('usersTable');
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const currentItems = filteredUsers.slice(startIndex, endIndex);
    
    tableBody.innerHTML = '';
    
    currentItems.forEach(user => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>
                <div style="display: flex; align-items: center; gap: 10px;">
                    <div style="width: 36px; height: 36px; border-radius: 50%; background: ${getUserColor(user.type)}; 
                         display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">
                        ${user.username.charAt(0).toUpperCase()}
                    </div>
                    <div>
                        <strong>${user.username}</strong>
                        <div style="font-size: 12px; color: var(--gray-color);">تم الإنشاء: ${user.createdAt}</div>
                    </div>
                </div>
            </td>
            <td>
                <div class="user-status">
                    <span class="status-dot ${user.status === 'active' ? 'status-active' : 'status-inactive'}"></span>
                    <span class="status-text">${user.status === 'active' ? 'مفعّل' : 'معطل'}</span>
                </div>
            </td>
            <td>${user.lastLogin}</td>
            <td><span class="user-type ${getBadgeClass(user.type)}">${getTypeText(user.type)}</span></td>
            <td><a href="mailto:${user.email}" style="color: var(--primary-color); text-decoration: none;">${user.email}</a></td>
            <td>${user.displayName}</td>
            <td>
                <div class="action-buttons">
                    <button class="btn-icon btn-edit" title="تعديل" onclick="editUser(${user.id})">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn-icon btn-reset" title="إعادة تعيين كلمة المرور" onclick="resetPassword(${user.id})">
                        <i class="fas fa-key"></i>
                    </button>
                    <button class="btn-icon btn-delete" title="حذف" onclick="deleteUser(${user.id})">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </td>
        `;
        tableBody.appendChild(row);
    });
    
    setupPagination();
}

function setupPagination() {
    const pagination = document.getElementById('pagination');
    const totalPages = Math.ceil(filteredUsers.length / itemsPerPage);
    
    pagination.innerHTML = '';
    
    if (totalPages <= 1) return;
    
    if (currentPage > 1) {
        const prevBtn = document.createElement('button');
        prevBtn.className = 'btn-icon btn-outline';
        prevBtn.innerHTML = '<i class="fas fa-chevron-right"></i>';
        prevBtn.addEventListener('click', () => {
            currentPage--;
            renderTable();
        });
        pagination.appendChild(prevBtn);
    }
    
    for (let i = 1; i <= totalPages; i++) {
        const pageBtn = document.createElement('button');
        pageBtn.className = `btn-icon ${i === currentPage ? 'btn-primary' : 'btn-outline'}`;
        pageBtn.textContent = i;
        pageBtn.addEventListener('click', () => {
            currentPage = i;
            renderTable();
        });
        pagination.appendChild(pageBtn);
    }
    
    if (currentPage < totalPages) {
        const nextBtn = document.createElement('button');
        nextBtn.className = 'btn-icon btn-outline';
        nextBtn.innerHTML = '<i class="fas fa-chevron-left"></i>';
        nextBtn.addEventListener('click', () => {
            currentPage++;
            renderTable();
        });
        pagination.appendChild(nextBtn);
    }
}

function updateStats() {
    const total = usersData.length;
    const active = usersData.filter(u => u.status === 'active').length;
    const admin = usersData.filter(u => u.type === 'admin').length;
    const owners = usersData.filter(u => u.type === 'rest_owner').length;
    
    document.getElementById('totalUsers').textContent = total;
    document.getElementById('activeUsers').textContent = active;
    document.getElementById('adminUsers').textContent = admin;
    document.getElementById('ownerUsers').textContent = owners;
}

function getTypeText(type) {
    const types = {
        'admin': 'مدير نظام',
        'rest_owner': 'صاحب مطعم',
        'emp': 'موظف',
        'user': 'مستخدم عادي'
    };
    return types[type] || type;
}

function getBadgeClass(type) {
    const classes = {
        'admin': 'badge-admin',
        'rest_owner': 'badge-owner',
        'emp': 'badge-emp',
        'user': 'badge-user'
    };
    return classes[type] || 'badge-user';
}

function getUserColor(type) {
    const colors = {
        'admin': '#dc3545',
        'rest_owner': '#ffc107',
        'emp': '#17a2b8',
        'user': '#6c757d'
    };
    return colors[type] || '#2c5aa0';
}

function resetModalForm() {
    document.getElementById('modalUsername').value = '';
    document.getElementById('modalEmail').value = '';
    document.getElementById('modalPassword').value = '';
    document.getElementById('modalType').value = 'user';
    document.getElementById('modalDisplayName').value = '';
}

function editUser(id) {
    const user = usersData.find(u => u.id === id);
    if (user) {
        editingUserId = id;
        document.getElementById('modalTitle').textContent = 'تعديل المستخدم';
        document.getElementById('modalUsername').value = user.username;
        document.getElementById('modalEmail').value = user.email;
        document.getElementById('modalType').value = user.type;
        document.getElementById('modalDisplayName').value = user.displayName;
        document.getElementById('modalPassword').required = false;
        document.getElementById('userModal').style.display = 'flex';
    }
}

function resetPassword(id) {
    const user = usersData.find(u => u.id === id);
    if (user && confirm(`هل تريد إعادة تعيين كلمة مرور المستخدم "${user.username}"؟`)) {
        showNotification(`تم إرسال رابط إعادة تعيين كلمة المرور إلى ${user.email}`, 'success');
    }
}

function deleteUser(id) {
    const user = usersData.find(u => u.id === id);
    if (user && confirm(`هل أنت متأكد من حذف المستخدم "${user.username}"؟`)) {
        const index = usersData.findIndex(u => u.id === id);
        if (index !== -1) {
            usersData.splice(index, 1);
            filteredUsers = [...usersData];
            renderTable();
            updateStats();
            showNotification(`تم حذف المستخدم "${user.username}" بنجاح`, 'success');
        }
    }
}

function showNotification(message, type = 'info') {
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => notification.remove());
    
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
        ${message}
    `;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

function showLoading() {
    document.getElementById('loading').style.display = 'block';
}

function hideLoading() {
    document.getElementById('loading').style.display = 'none';
}