const restaurantsData = [
    {
        id: 1,
        name: "Fire-Fly",
        owner: "أحمد محمد",
        deliveryPhone: "0791103716",
        smsId: "78788",
        delivery: true,
        active: true,
        created: "2017-07-14",
        orders: 1248
    },
    {
        id: 2,
        name: "Subway",
        owner: "سارة خالد",
        deliveryPhone: "0791103717",
        smsId: "0",
        delivery: true,
        active: true,
        created: "2017-07-14",
        orders: 985
    },
    {
        id: 3,
        name: "Wazzap Dog",
        owner: "محمد علي",
        deliveryPhone: "0791103714",
        smsId: "15422",
        delivery: true,
        active: true,
        created: "2017-07-14",
        orders: 742
    },
    {
        id: 4,
        name: "Markat",
        owner: "يوسف أحمد",
        deliveryPhone: "00000",
        smsId: "0",
        delivery: false,
        active: false,
        created: "2024-11-03",
        orders: 58
    },
    {
        id: 5,
        name: "Tandoori Master",
        owner: "فاطمة يوسف",
        deliveryPhone: "0791604764",
        smsId: "78788",
        delivery: true,
        active: true,
        created: "2025-02-18",
        orders: 425
    },
    {
        id: 6,
        name: "Pizza Hut",
        owner: "خالد سعيد",
        deliveryPhone: "0791234567",
        smsId: "45678",
        delivery: true,
        active: true,
        created: "2023-05-10",
        orders: 1254
    },
    {
        id: 7,
        name: "Burger King",
        owner: "نور محمد",
        deliveryPhone: "0797654321",
        smsId: "32145",
        delivery: true,
        active: true,
        created: "2023-08-22",
        orders: 896
    },
    {
        id: 8,
        name: "KFC",
        owner: "علي حسن",
        deliveryPhone: "0795554444",
        smsId: "98765",
        delivery: true,
        active: false,
        created: "2024-01-15",
        orders: 325
    }
];

let currentPage = 1;
const itemsPerPage = 5;
let filteredRestaurants = [...restaurantsData];

document.addEventListener('DOMContentLoaded', function() {
    initApp();
});

function initApp() {
    document.getElementById('navbarToggle').addEventListener('click', function() {
        const navbarNav = document.getElementById('navbarNav');
        navbarNav.classList.toggle('show');
        this.innerHTML = navbarNav.classList.contains('show') 
            ? '<i class="fas fa-times"></i>' 
            : '<i class="fas fa-bars"></i>';
    });

    document.addEventListener('click', function(event) {
        const navbarNav = document.getElementById('navbarNav');
        const navbarToggle = document.getElementById('navbarToggle');
        
        if (!navbarNav.contains(event.target) && !navbarToggle.contains(event.target)) {
            navbarNav.classList.remove('show');
            navbarToggle.innerHTML = '<i class="fas fa-bars"></i>';
        }
    });

    const logoUpload = document.getElementById('logoUpload');
    const logoInput = document.getElementById('logoInput');
    
    logoUpload.addEventListener('click', function() {
        logoInput.click();
    });
    
    logoInput.addEventListener('change', function(e) {
        if (e.target.files[0]) {
            const reader = new FileReader();
            reader.onload = function(event) {
                logoUpload.innerHTML = `
                    <img src="${event.target.result}" alt="شعار المطعم">
                    <p>تم رفع الشعار بنجاح</p>
                `;
            };
            reader.readAsDataURL(e.target.files[0]);
        }
    });

    document.getElementById('addRestaurantBtn').addEventListener('click', function() {
        const restaurantName = document.getElementById('restaurantName').value;
        const ownerName = document.getElementById('ownerName').value;
        const deliveryPhone = document.getElementById('deliveryPhone').value;
        
        if (restaurantName && ownerName && deliveryPhone) {
            showLoading();
            
            const newRestaurant = {
                id: restaurantsData.length + 1,
                name: restaurantName,
                owner: ownerName,
                deliveryPhone: deliveryPhone,
                smsId: document.getElementById('smsId').value || "0",
                delivery: document.getElementById('deliveryService').checked,
                active: document.getElementById('activeStatus').checked,
                created: new Date().toISOString().split('T')[0],
                orders: 0
            };
            
            setTimeout(() => {
                restaurantsData.unshift(newRestaurant);
                filteredRestaurants = [...restaurantsData];
                currentPage = 1;
                renderTable();
                updateStats();
                hideLoading();
                
                showNotification(`تم إضافة المطعم "${restaurantName}" بنجاح`, 'success');
                
                document.querySelectorAll('.form-control').forEach(input => {
                    input.value = '';
                });
                document.getElementById('activeStatus').checked = true;
                document.getElementById('deliveryService').checked = true;
            }, 1500);
        } else {
            showNotification('يرجى ملء الحقول المطلوبة', 'error');
        }
    });

    document.getElementById('exportBtn').addEventListener('click', function() {
        showLoading();
        setTimeout(() => {
            hideLoading();
            showNotification('تم تصدير البيانات بنجاح', 'success');
        }, 1000);
    });

    document.getElementById('filterBtn').addEventListener('click', function() {
        showNotification('فتح نافذة التصفية', 'info');
    });

    document.getElementById('printBtn').addEventListener('click', function() {
        window.print();
    });

    document.getElementById('refreshBtn').addEventListener('click', function() {
        showLoading();
        setTimeout(() => {
            renderTable();
            updateStats();
            hideLoading();
            showNotification('تم تحديث البيانات', 'success');
        }, 800);
    });

    document.getElementById('searchBtn').addEventListener('click', function() {
        showNotification('فتح نافذة البحث المتقدم', 'info');
    });

    document.getElementById('notificationIcon').addEventListener('click', function() {
        showNotification('لديك 3 تنبيهات جديدة', 'info');
    });

    document.querySelector('.newsletter-btn').addEventListener('click', function() {
        const emailInput = document.querySelector('.newsletter-input');
        if (emailInput.value) {
            showNotification('تم الاشتراك في النشرة البريدية بنجاح', 'success');
            emailInput.value = '';
        } else {
            showNotification('يرجى إدخال بريد إلكتروني', 'error');
        }
    });

    document.querySelectorAll('.social-links a').forEach(link => {
        link.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
        });
        
        link.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });

    renderTable();
    updateStats();
    setupPagination();
}

function renderTable() {
    const tableBody = document.getElementById('restaurantsTable');
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const currentItems = filteredRestaurants.slice(startIndex, endIndex);
    
    tableBody.innerHTML = '';
    
    currentItems.forEach(restaurant => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td class="action-buttons">
                <button class="btn-icon btn-edit" title="تعديل" onclick="editRestaurant(${restaurant.id})">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn-icon btn-view" title="عرض التفاصيل" onclick="viewRestaurant(${restaurant.id})">
                    <i class="fas fa-eye"></i>
                </button>
            </td>
            <td>
                <div class="status-toggle ${restaurant.active ? 'active' : ''}" 
                     onclick="toggleStatus(${restaurant.id})"></div>
            </td>
            <td>
                <strong>${restaurant.name}</strong><br>
                <small style="color: var(--gray-color);">مالك: ${restaurant.owner}</small>
            </td>
            <td>${restaurant.deliveryPhone}</td>
            <td>
                <span class="restaurant-badge ${restaurant.smsId === '0' ? 'badge-inactive' : 'badge-sms'}">
                    ${restaurant.smsId}
                </span>
            </td>
            <td>
                <span class="restaurant-badge ${restaurant.delivery ? 'badge-delivery' : 'badge-inactive'}">
                    ${restaurant.delivery ? '✓ متاح' : '✗ غير متاح'}
                </span>
            </td>
            <td>${restaurant.created}</td>
            <td>
                <button class="btn-icon btn-delete" title="حذف" onclick="deleteRestaurant(${restaurant.id})">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        tableBody.appendChild(row);
    });
    
    setupPagination();
}

function setupPagination() {
    const pagination = document.getElementById('pagination');
    const totalPages = Math.ceil(filteredRestaurants.length / itemsPerPage);
    
    pagination.innerHTML = '';
    
    if (currentPage > 1) {
        const prevBtn = document.createElement('button');
        prevBtn.className = 'btn-icon btn-outline';
        prevBtn.innerHTML = '<i class="fas fa-chevron-right"></i>';
        prevBtn.addEventListener('click', () => {
            currentPage--;
            renderTable();
        });
        pagination.appendChild(prevBtn);
    }
    
    for (let i = 1; i <= totalPages; i++) {
        const pageBtn = document.createElement('button');
        pageBtn.className = `btn-icon ${i === currentPage ? 'btn-primary' : 'btn-outline'}`;
        pageBtn.textContent = i;
        pageBtn.addEventListener('click', () => {
            currentPage = i;
            renderTable();
        });
        pagination.appendChild(pageBtn);
    }
    
    if (currentPage < totalPages) {
        const nextBtn = document.createElement('button');
        nextBtn.className = 'btn-icon btn-outline';
        nextBtn.innerHTML = '<i class="fas fa-chevron-left"></i>';
        nextBtn.addEventListener('click', () => {
            currentPage++;
            renderTable();
        });
        pagination.appendChild(nextBtn);
    }
}

function updateStats() {
    const total = restaurantsData.length;
    const active = restaurantsData.filter(r => r.active).length;
    const delivery = restaurantsData.filter(r => r.delivery).length;
    const avgOrders = Math.round(restaurantsData.reduce((sum, r) => sum + r.orders, 0) / restaurantsData.length);
    
    document.getElementById('totalRestaurants').textContent = total;
    document.getElementById('activeRestaurants').textContent = active;
    document.getElementById('deliveryRestaurants').textContent = delivery;
    document.getElementById('avgOrders').textContent = `${avgOrders}/يوم`;
}

function toggleStatus(id) {
    const restaurant = restaurantsData.find(r => r.id === id);
    if (restaurant) {
        restaurant.active = !restaurant.active;
        showNotification(`تم تغيير حالة "${restaurant.name}" إلى ${restaurant.active ? 'نشط' : 'غير نشط'}`, 'success');
        renderTable();
        updateStats();
    }
}

function editRestaurant(id) {
    const restaurant = restaurantsData.find(r => r.id === id);
    if (restaurant) {
        document.getElementById('restaurantName').value = restaurant.name;
        document.getElementById('ownerName').value = restaurant.owner;
        document.getElementById('deliveryPhone').value = restaurant.deliveryPhone;
        document.getElementById('smsId').value = restaurant.smsId;
        document.getElementById('activeStatus').checked = restaurant.active;
        document.getElementById('deliveryService').checked = restaurant.delivery;
        
        showNotification(`جاري تعديل "${restaurant.name}"`, 'info');
        
        document.querySelector('.sidebar-form').scrollIntoView({ behavior: 'smooth' });
    }
}

function viewRestaurant(id) {
    const restaurant = restaurantsData.find(r => r.id === id);
    if (restaurant) {
        showNotification(`عرض تفاصيل "${restaurant.name}"`, 'info');
    }
}

function deleteRestaurant(id) {
    const restaurant = restaurantsData.find(r => r.id === id);
    if (restaurant) {
        if (confirm(`هل أنت متأكد من حذف المطعم "${restaurant.name}"؟`)) {
            const index = restaurantsData.findIndex(r => r.id === id);
            if (index !== -1) {
                restaurantsData.splice(index, 1);
                filteredRestaurants = [...restaurantsData];
                renderTable();
                updateStats();
                showNotification(`تم حذف المطعم "${restaurant.name}" بنجاح`, 'success');
            }
        }
    }
}

function showNotification(message, type = 'info') {
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => notification.remove());
    
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
        ${message}
    `;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

function showLoading() {
    document.getElementById('loading').style.display = 'block';
}

function hideLoading() {
    document.getElementById('loading').style.display = 'none';
}