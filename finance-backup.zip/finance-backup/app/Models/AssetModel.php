<?php

namespace App\Models;

use CodeIgniter\Model;

class AssetModel extends Model
{
    protected $table = 'assets';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'name', 'type', 'serial', 'purchase_date', 'book_value',
        'market_value', 'depreciation_rate', 'status', 'description', 'image_url'
    ];
    protected $useTimestamps = true;

    public function getAssets()
    {
        return $this->orderBy('purchase_date', 'DESC')->findAll();
    }

    public function getStats()
    {
        $builder = $this->builder();

        $result = $builder->selectSum('book_value', 'total_book')
                          ->selectSum('market_value', 'total_market')
                          ->selectCount('id', 'active_count')
                          ->where('status', 'active')
                          ->get()
                          ->getRowArray();

        $totalDepreciation = 0;
        $assets = $this->where('status', 'active')->findAll();
        foreach ($assets as $asset) {
            $totalDepreciation += ($asset['book_value'] * ($asset['depreciation_rate'] / 100));
        }

        return [
            'total_book_value'    => $result['total_book'] ?? 0,
            'total_market_value'  => $result['total_market'] ?? 0,
            'active_count'        => $result['active_count'] ?? 0,
            'total_depreciation'  => $totalDepreciation
        ];
    }
}