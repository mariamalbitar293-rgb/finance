<?php

namespace App\Models;

use CodeIgniter\Model;

class SalaryModel extends Model
{
    protected $table = 'salaries';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'employee_name', 'position', 'basic_salary', 'bonuses', 
        'deductions', 'net_salary', 'payment_date', 'status', 'notes'
    ];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    
    public function getSalaries($month = null, $employee = null)
    {
        $builder = $this->builder();

        if ($month) {
            $builder->like('payment_date', $month . '%');
        }

        if ($employee && $employee !== 'all') {
            $builder->where('employee_name', $employee);
        }

        $builder->orderBy('payment_date', 'DESC');

        return $builder->get()->getResultArray();
    }

    
    public function getStats($month = null)
    {
        $builder = $this->builder();

        if ($month) {
            $builder->like('payment_date', $month . '%');
        }

        $result = $builder->selectSum('basic_salary', 'total_basic')
                          ->selectSum('bonuses', 'total_bonuses')
                          ->selectSum('deductions', 'total_deductions')
                          ->selectSum('net_salary', 'total_net')
                          ->selectCount('id', 'total_employees')
                          ->selectAvg('net_salary', 'avg_salary')
                          ->get()
                          ->getRowArray();

        return [
            'total_employees'   => $result['total_employees'] ?? 0,
            'total_basic'       => $result['total_basic'] ?? 0,
            'total_bonuses'     => $result['total_bonuses'] ?? 0,
            'total_deductions'  => $result['total_deductions'] ?? 0,
            'total_net'         => $result['total_net'] ?? 0,
            'avg_salary'        => $result['avg_salary'] ? round($result['avg_salary'], 2) : 0
        ];
    }
}