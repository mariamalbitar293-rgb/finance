<div class="modal-overlay" id="addAssetModal" style="display: none;">
    <div class="modal-container">
        <div class="modal-header">
            <h3 id="modalTitle"><i class="fas fa-server"></i> إضافة أصل جديد</h3>
            <button class="close-modal" onclick="closeModal('addAssetModal')"><i class="fas fa-times"></i></button>
        </div>
        <div class="modal-body">
            <form id="assetForm" enctype="multipart/form-data">
                <input type="hidden" id="assetId" name="assetId">

                <div class="form-row">
                    <div class="form-group">
                        <label for="assetName">اسم الأصل *</label>
                        <input type="text" id="assetName" name="name" required>
                    </div>
                    <div class="form-group">
                        <label for="assetType">نوع الأصل *</label>
                        <select id="assetType" name="type" required>
                            <option value="servers">سيرفرات</option>
                            <option value="equipment">معدات</option>
                            <option value="property">عقارات</option>
                            <option value="vehicles">مركبات</option>
                            <option value="other">أخرى</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="assetSerial">رقم تسلسلي *</label>
                        <input type="text" id="assetSerial" name="serial" required>
                    </div>
                    <div class="form-group">
                        <label for="purchaseDate">تاريخ الشراء *</label>
                        <input type="date" id="purchaseDate" name="purchase_date" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="bookValue">القيمة الدفترية *</label>
                        <input type="number" id="bookValue" name="book_value" min="1" required>
                    </div>
                    <div class="form-group">
                        <label for="marketValue">القيمة السوقية *</label>
                        <input type="number" id="marketValue" name="market_value" min="1" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="depreciationRate">معدل الإهلاك السنوي (%)</label>
                        <input type="number" id="depreciationRate" name="depreciation_rate" min="0" max="100" step="0.1" value="10">
                    </div>
                    <div class="form-group">
                        <label for="assetStatus">الحالة</label>
                        <select id="assetStatus" name="status">
                            <option value="active">نشط</option>
                            <option value="inactive">غير نشط</option>
                            <option value="maintenance">تحت الصيانة</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="assetDescription">الوصف</label>
                    <textarea id="assetDescription" name="description" rows="3"></textarea>
                </div>
                <div class="form-group">
                    <label for="image">صورة الأصل (اختياري)</label>
                    <input type="file" id="image" name="image" accept="image/*">
                    <small>اختر صورة جديدة لتغيير الصورة الحالية</small>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('addAssetModal')">إلغاء</button>
            <button class="btn btn-primary" id="saveAssetBtn">حفظ الأصل</button>
        </div>
    </div>
</div>