<?php

namespace App\Controllers;

use App\Models\CommitmentModel;
use CodeIgniter\API\ResponseTrait;

class CommitmentApi extends \CodeIgniter\RESTful\ResourceController
{
    use ResponseTrait;

    protected $modelName = 'App\Models\CommitmentModel';
    protected $format = 'json';

    
    public function index()
    {
        $commitments = $this->model->getCommitments();
        return $this->respond($commitments);
    }

    
    public function stats()
    {
        $stats = $this->model->getStats();
        return $this->respond($stats);
    }

    
    public function create()
    {
        $data = $this->request->getJSON(true);

        if (empty($data['name']) || empty($data['amount']) || empty($data['payment_day']) || empty($data['start_date'])) {
            return $this->fail('الحقول المطلوبة ناقصة', 400);
        }

        if (!$this->model->insert($data)) {
            return $this->fail($this->model->errors(), 400);
        }

        return $this->respondCreated(['status' => 'success', 'message' => 'تم إضافة الالتزام بنجاح']);
    }

    
    public function update($id = null)
    {
        $data = $this->request->getJSON(true);

        if (!$this->model->update($id, $data)) {
            return $this->fail($this->model->errors(), 400);
        }

        return $this->respond(['status' => 'success', 'message' => 'تم تحديث الالتزام بنجاح']);
    }

    
    public function delete($id = null)
    {
        if (!$this->model->delete($id)) {
            return $this->fail('فشل الحذف', 400);
        }

        return $this->respondDeleted(['status' => 'success', 'message' => 'تم حذف الالتزام بنجاح']);
    }
}