<?php
namespace App\Controllers;

class YearlyTest extends BaseController
{
    public function index()
    {
        echo "<html><body style='font-family: Arial; padding: 20px; direction: rtl;'>";
        echo "<h1>📊 اختبار التقارير السنوية المبسط</h1>";
        
        
        $model = new \App\Models\YearlyReportModel();
        
        
        $currentYear = date('Y');
        
        
        $data = $model->getYearlyData($currentYear);
        
        echo "<h2>بيانات السنة الحالية ($currentYear)</h2>";
        
        if (isset($data['source'])) {
            $color = $data['source'] === 'database' ? 'green' : 'orange';
            echo "<p><strong>مصدر البيانات:</strong> <span style='color:$color;'>" . $data['source'] . "</span></p>";
        }
        
        echo "<table border='1' cellpadding='10' style='border-collapse: collapse; width: 100%; margin: 20px 0;'>";
        echo "<tr style='background: #2c3e50; color: white;'>";
        echo "<th>السنة</th><th>الإيرادات</th><th>المصروفات</th><th>صافي الأرباح</th><th>متوسط الشهري</th>";
        echo "</tr>";
        
        echo "<tr>";
        echo "<td align='center'><strong>{$data['year']}</strong></td>";
        echo "<td align='center'>" . number_format($data['revenue']) . " دينار</td>";
        echo "<td align='center'>" . number_format($data['expenses']) . " دينار</td>";
        echo "<td align='center'>" . number_format($data['profit']) . " دينار</td>";
        echo "<td align='center'>" . number_format(round($data['revenue'] / 12)) . " دينار</td>";
        echo "</tr>";
        echo "</table>";
        
        
        echo "<h2>الميزانية السنوية ({$data['year']})</h2>";
        
        if (isset($data['budget_data']) && is_array($data['budget_data'])) {
            $budgetItems = [
                'salaries'     => ['label' => 'الرواتب',             'planned' => 8000],
                'operational'  => ['label' => 'المصروفات التشغيلية', 'planned' => 4500],
                'marketing'    => ['label' => 'التسويق والإعلان',     'planned' => 3000],
                'assets'       => ['label' => 'الموجودات والمعدات',   'planned' => 2500],
                'other'        => ['label' => 'مصاريف أخرى',         'planned' => 1500],
            ];
            
            echo "<table border='1' cellpadding='10' style='border-collapse: collapse; width: 100%;'>";
            echo "<tr style='background: #2c3e50; color: white;'>";
            echo "<th>البند</th><th>الميزانية المخطط لها</th><th>المصروف الفعلي</th><th>الانحراف</th><th>النسبة</th>";
            echo "</tr>";
            
            foreach ($budgetItems as $key => $item) {
                $actual = $data['budget_data'][$key] ?? 0;
                $deviation = $actual - $item['planned'];
                $percentage = $item['planned'] > 0 ? round(($actual / $item['planned']) * 100, 1) : 0;
                $deviationClass = $deviation > 0 ? 'overdue' : ($deviation < 0 ? 'paid' : '');
                
                echo "<tr>";
                echo "<td>{$item['label']}</td>";
                echo "<td>" . number_format($item['planned']) . " دينار</td>";
                echo "<td>" . number_format($actual) . " دينار</td>";
                echo "<td class='$deviationClass'>" . ($deviation > 0 ? '+' : '') . number_format($deviation) . " دينار</td>";
                echo "<td>$percentage%</td>";
                echo "</tr>";
            }
            
            echo "</table>";
            
            
            echo "<style>
                .paid { color: green; }
                .overdue { color: red; }
                table { margin: 20px 0; }
                th { text-align: center; }
                td { text-align: center; }
            </style>";
            
        } else {
            echo "<p style='color: red;'>❌ بيانات الميزانية غير متاحة</p>";
            echo "<pre>";
            print_r($data);
            echo "</pre>";
        }
        
        
        echo "<div style='margin-top: 30px; padding: 20px; background: #f8f9fa; border-radius: 5px;'>";
        echo "<a href='" . site_url('dashboard/yearlyReports') . "' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>";
        echo "الذهاب إلى صفحة التقارير السنوية الرئيسية";
        echo "</a>";
        echo " &nbsp; ";
        echo "<a href='" . site_url('debug/yearly') . "' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>";
        echo "فحص قاعدة البيانات";
        echo "</a>";
        echo "</div>";
        
        echo "</body></html>";
    }
}