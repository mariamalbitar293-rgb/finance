<?php

namespace App\Controllers;

use App\Models\ClientModel;
use CodeIgniter\API\ResponseTrait;

class ClientApi extends \CodeIgniter\Controller
{
    use ResponseTrait;

    protected $model;

    public function __construct()
    {
        $this->model = new ClientModel();
    }

    public function index()
    {
        $clients = $this->model->orderBy('date', 'DESC')->findAll();
        return $this->respond($clients);
    }

    public function stats()
    {
        $stats = $this->model->getStats();
        return $this->respond($stats);
    }

    public function create()
    {
        $data = $this->request->getJSON(true);
        if (empty($data)) $data = $this->request->getPost();

        if (empty($data['name']) || empty($data['principal'])) {
            return $this->fail('الاسم والمبلغ الأساسي مطلوبان', 400);
        }

        $paid = $data['paid'] ?? 0;
        $principal = $data['principal'];
        $data['status'] = ($paid >= $principal && $paid > 0) ? 'paid' : ($paid > 0 ? 'partial' : 'pending');

        if (!$this->model->insert($data)) {
            return $this->fail($this->model->errors(), 400);
        }

        return $this->respondCreated(['status' => 'success', 'message' => 'تم إضافة العميل بنجاح']);
    }

    public function update($id = null)
{
    if (!$id) {
        return $this->fail('معرف العميل مطلوب', 400);
    }

    $data = $this->request->getJSON(true);
    if (empty($data)) {
        $data = $this->request->getPost();
    }

    if (empty($data)) {
        return $this->fail('لا توجد بيانات للتحديث', 400);
    }

    
    $paid = $data['paid'] ?? 0;
    $principal = $data['principal'] ?? 0;
    $data['status'] = ($paid >= $principal && $paid > 0) ? 'paid' : ($paid > 0 ? 'partial' : 'pending');

    if (!$this->model->update($id, $data)) {
        return $this->fail($this->model->errors(), 400);
    }

    return $this->respond(['status' => 'success', 'message' => 'تم تحديث العميل بنجاح']);
}

    public function delete($id = null)
    {
        if (!$this->model->delete($id)) {
            return $this->fail('فشل الحذف أو العميل غير موجود', 400);
        }

        return $this->respondDeleted(['status' => 'success', 'message' => 'تم حذف العميل بنجاح']);
    }
}