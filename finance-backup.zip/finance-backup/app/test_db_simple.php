<?php
// test_db_simple.php
echo "<html><head><title>اختبار قاعدة البيانات</title><meta charset='UTF-8'></head><body>";
echo "<h1 style='text-align:center;'>اختبار قاعدة البيانات</h1>";

try {
    // تحميل CodeIgniter يدوياً
    require_once __DIR__ . '/../app/Config/Paths.php';
    $paths = new Config\Paths();
    
    require_once $paths->systemDirectory . '/Boot.php';
    require_once $paths->appDirectory . '/Config/Database.php';
    
    $config = new Config\Database();
    $db = \Config\Database::connect();
    
    if ($db->connID) {
        echo "<div style='background:#d4edda; color:#155724; padding:20px; margin:20px; border-radius:5px;'>";
        echo "<h2>✅ نجاح الاتصال بقاعدة البيانات!</h2>";
        echo "<p>قاعدة البيانات: <strong>" . $db->getDatabase() . "</strong></p>";
        
        // عرض الجداول
        $tables = $db->listTables();
        echo "<p>عدد الجداول: <strong>" . count($tables) . "</strong></p>";
        echo "<ul>";
        foreach ($tables as $table) {
            echo "<li>$table</li>";
        }
        echo "</ul>";
        
        // اختبار جدول العملاء
        if (in_array('clients', $tables)) {
            $query = $db->query('SELECT COUNT(*) as total FROM clients');
            $result = $query->getRow();
            echo "<p>عدد العملاء: <strong>" . $result->total . "</strong></p>";
        }
        
        echo "</div>";
    } else {
        echo "<div style='background:#f8d7da; color:#721c24; padding:20px; margin:20px; border-radius:5px;'>";
        echo "<h2>❌ فشل الاتصال بقاعدة البيانات</h2>";
        echo "</div>";
    }
    
} catch (Exception $e) {
    echo "<div style='background:#f8d7da; color:#721c24; padding:20px; margin:20px; border-radius:5px;'>";
    echo "<h2>❌ حدث خطأ</h2>";
    echo "<p>" . $e->getMessage() . "</p>";
    echo "</div>";
}

echo "</body></html>";
// test_db_simple.php
echo "<html><head><title>اختبار قاعدة البيانات</title><meta charset='UTF-8'></head><body>";
echo "<h1 style='text-align:center;'>اختبار قاعدة البيانات</h1>";

try {
    // تحميل CodeIgniter يدوياً
    require_once __DIR__ . '/../app/Config/Paths.php';
    $paths = new Config\Paths();
    
    require_once $paths->systemDirectory . '/Boot.php';
    require_once $paths->appDirectory . '/Config/Database.php';
    
    $config = new Config\Database();
    $db = \Config\Database::connect();
    
    if ($db->connID) {
        echo "<div style='background:#d4edda; color:#155724; padding:20px; margin:20px; border-radius:5px;'>";
        echo "<h2>✅ نجاح الاتصال بقاعدة البيانات!</h2>";
        echo "<p>قاعدة البيانات: <strong>" . $db->getDatabase() . "</strong></p>";
        
        // عرض الجداول
        $tables = $db->listTables();
        echo "<p>عدد الجداول: <strong>" . count($tables) . "</strong></p>";
        echo "<ul>";
        foreach ($tables as $table) {
            echo "<li>$table</li>";
        }
        echo "</ul>";
        
        // اختبار جدول العملاء
        if (in_array('clients', $tables)) {
            $query = $db->query('SELECT COUNT(*) as total FROM clients');
            $result = $query->getRow();
            echo "<p>عدد العملاء: <strong>" . $result->total . "</strong></p>";
        }
        
        echo "</div>";
    } else {
        echo "<div style='background:#f8d7da; color:#721c24; padding:20px; margin:20px; border-radius:5px;'>";
        echo "<h2>❌ فشل الاتصال بقاعدة البيانات</h2>";
        echo "</div>";
    }
    
} catch (Exception $e) {
    echo "<div style='background:#f8d7da; color:#721c24; padding:20px; margin:20px; border-radius:5px;'>";
    echo "<h2>❌ حدث خطأ</h2>";
    echo "<p>" . $e->getMessage() . "</p>";
    echo "</div>";
}

echo "</body></html>";