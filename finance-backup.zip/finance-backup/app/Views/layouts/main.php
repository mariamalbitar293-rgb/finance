<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>نظام إدارة الحسابات المالية - <?= $this->renderSection('title') ?? 'لوحة التحكم' ?></title>
    
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <link rel="stylesheet" href="/css/main.css">
    <link rel="stylesheet" href="/css/sidebar.css">
    <link rel="stylesheet" href="/css/dashboard.css">
    <link rel="stylesheet" href="/css/responsive.css">
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
    
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <div class="logo-img">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div class="logo-text">
                    <h1>نظام المالية</h1>
                    <span>لوحة التحكم المتكاملة</span>
                </div>
            </div>
        </div>
        
        <div class="sidebar-menu">
            
            <a href="<?= site_url('dashboard/clients') ?>" class="menu-item <?= current_url(true)->getSegment(2) == 'clients' ? 'active' : '' ?>">
                <i class="fas fa-users"></i>
                <span>حسابات العملاء</span>
                
            </a>
            <a href="<?= site_url('dashboard/yearlyReports') ?>" class="menu-item <?= current_url(true)->getSegment(2) == 'yearlyReports' ? 'active' : '' ?>">
                <i class="fas fa-chart-bar"></i>
                <span>التقارير السنوية</span>
            </a>
            <a href="<?= site_url('dashboard/salaries') ?>" class="menu-item <?= current_url(true)->getSegment(2) == 'salaries' ? 'active' : '' ?>">
                <i class="fas fa-file-invoice-dollar"></i>
                <span>تقارير الرواتب</span>
                
            </a>
            <a href="<?= site_url('dashboard/commitments') ?>" class="menu-item <?= current_url(true)->getSegment(2) == 'commitments' ? 'active' : '' ?>">
                <i class="fas fa-hand-holding-usd"></i>
                <span>الالتزامات الشهرية</span>
                
            </a>
            <a href="<?= site_url('dashboard/assets') ?>" class="menu-item <?= current_url(true)->getSegment(2) == 'assets' ? 'active' : '' ?>">
                <i class="fas fa-server"></i>
                <span>الأصول الثابتة</span>
                
            </a>
            
        </div>
        
        <div class="sidebar-footer">
            <div class="user-profile">
                <div class="user-avatar">
                    <i class="fas fa-user"></i>
                </div>
                <div class="user-info">
                    <h4>مدير النظام</h4>
                    <span>Admin@finance.com</span>
                </div>
            </div>
        </div>
        
        <button class="toggle-sidebar" id="toggleSidebarBtn">
            <i class="fas fa-chevron-left"></i>
        </button>
    </div>

    <div class="main-content" id="mainContent">
    
        <header class="header">
            <div class="header-left">
                <div class="page-title">
                    <h2><?= $this->renderSection('title') ?? 'لوحة التحكم' ?></h2>
                </div>
            </div>
            
            <div class="header-right">
                <div class="date-display">
                    <i class="far fa-calendar-alt"></i>
                    <span id="current-date"><?= date('Y-m-d') ?></span>
                </div>
                
                <div class="notifications">
                    <i class="fas fa-bell"></i>
                    <div class="notification-badge">3</div>
                </div>
                
                <div class="small-avatar">
                    <i class="fas fa-user"></i>
                </div>
            </div>
        </header>
        
        <div id="page-content">
            <?= $this->renderSection('content') ?>
        </div>
    </div>

    <button class="add-btn-large tooltip" id="floatingAddBtn" data-tooltip="إضافة عميل جديد">
        <i class="fas fa-plus"></i>
    </button>

    <div class="notification" id="successNotification">
        <i class="fas fa-check-circle"></i>
        <span id="notificationMessage">تمت العملية بنجاح!</span>
    </div>


    <div class="modal-overlay" id="addClientModal" style="display: none;">
        <div class="modal-container">
            <div class="modal-header">
                <h3><i class="fas fa-user-plus"></i> إضافة عميل جديد</h3>
                <button class="close-modal" onclick="closeModal('addClientModal')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div class="modal-body">
                <form id="addClientForm">
                    <input type="hidden" id="clientId" value="">
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="clientName"><i class="fas fa-user"></i> اسم العميل *</label>
                            <input type="text" id="clientName" placeholder="أدخل اسم العميل" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="clientPhone"><i class="fas fa-phone"></i> رقم الهاتف</label>
                            <input type="tel" id="clientPhone" placeholder="أدخل رقم الهاتف">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="principalAmount"><i class="fas fa-money-bill-wave"></i> المبلغ الأساسي *</label>
                            <input type="number" id="principalAmount" placeholder="أدخل المبلغ الأساسي" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="paidAmount"><i class="fas fa-hand-holding-usd"></i> المبلغ المدفوع</label>
                            <input type="number" id="paidAmount" placeholder="أدخل المبلغ المدفوع">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="clientDate"><i class="fas fa-calendar"></i> تاريخ الإضافة</label>
                            <input type="date" id="clientDate" value="<?= date('Y-m-d') ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="clientStatus"><i class="fas fa-tag"></i> الحالة</label>
                            <select id="clientStatus">
                                <option value="partial">مسدد جزئياً</option>
                                <option value="paid">مسدد بالكامل</option>
                                <option value="pending">غير مسدد</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="clientNotes"><i class="fas fa-sticky-note"></i> ملاحظات</label>
                        <textarea id="clientNotes" rows="3" placeholder="أدخل ملاحظات عن العميل..."></textarea>
                    </div>
                    
                    <div class="payment-progress">
                        <label>نسبة السداد:</label>
                        <div class="progress-bar-container">
                            <div class="progress-bar" id="paymentProgress"></div>
                        </div>
                        <span class="percentage" id="paymentPercentage">0%</span>
                    </div>
                </form>
            </div>
            
            <div class="modal-footer">
                <button class="btn btn-secondary" id="cancelAddClientBtn" onclick="closeModal('addClientModal')">
                    <i class="fas fa-times"></i> إلغاء
                </button>
                <button class="btn btn-primary" id="saveClientBtn">
                    <i class="fas fa-save"></i> حفظ العميل
                </button>
                <button class="btn btn-success" id="saveAndAddAnotherBtn">
                    <i class="fas fa-save"></i> حفظ وإضافة آخر
                </button>
            </div>
        </div>
    </div>

    
    <div class="modal-overlay" id="editClientModal" style="display: none;">
        
    </div>

    
    <script>
        const baseUrl = '<?= site_url() ?>';
        const csrfToken = '<?= csrf_hash() ?>';
        const currentPage = '<?= service('uri')->getSegment(2) ?? 'index' ?>';
    </script>

<script src="/js/main.js"></script>
<script src="/js/notifications.js"></script>

    <?= $this->renderSection('scripts') ?>
</body>
</html>