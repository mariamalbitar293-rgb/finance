<?= $this->extend('layouts/main') ?>

<?= $this->section('title') ?>
الالتزامات والديون الشهرية
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="section-header">
    <h2><i class="fas fa-hand-holding-usd"></i> الالتزامات والديون الشهرية</h2>
    <div class="controls">
        <button class="btn btn-primary" id="addCommitmentBtn">
            <i class="fas fa-plus"></i> إضافة التزام جديد
        </button>
        <button class="btn btn-secondary" id="printCommitmentBtn">
            <i class="fas fa-print"></i> طباعة
        </button>
        <button class="btn btn-success" id="exportCommitmentBtn">
            <i class="fas fa-file-export"></i> تصدير
        </button>
    </div>
</div>


<div class="stats-cards">
    <div class="stat-card card-1">
        <div class="stat-info">
            <h3>إجمالي الالتزامات الشهرية</h3>
            <div class="value"><?= number_format($stats['total_monthly']) ?> <span style="font-size: 1rem;">دينار</span></div>
        </div>
        <div class="stat-icon"><i class="fas fa-calendar-alt"></i></div>
    </div>

    <div class="stat-card card-2">
        <div class="stat-info">
            <h3>الديون المتبقية</h3>
            <div class="value"><?= number_format($stats['total_debts']) ?> <span style="font-size: 1rem;">دينار</span></div>
        </div>
        <div class="stat-icon"><i class="fas fa-file-invoice-dollar"></i></div>
    </div>

    <div class="stat-card card-3">
        <div class="stat-info">
            <h3>إجمالي الخصومات</h3>
            <div class="value"><?= number_format($stats['total_deductions']) ?> <span style="font-size: 1rem;">دينار</span></div>
        </div>
        <div class="stat-icon"><i class="fas fa-minus-circle"></i></div>
    </div>

    <div class="stat-card card-4">
        <div class="stat-info">
            <h3>عدد الالتزامات النشطة</h3>
            <div class="value"><?= $stats['active_count'] ?></div>
        </div>
        <div class="stat-icon"><i class="fas fa-list-ul"></i></div>
    </div>
</div>


<div class="table-container">
    <div class="table-header">
        <h3 style="margin: 0;"><i class="fas fa-list"></i> قائمة الالتزامات</h3>
    </div>
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>اسم الالتزام</th>
                    <th>النوع</th>
                    <th>المبلغ</th>
                    <th>يوم الدفع</th>
                    <th>المستلم</th>
                    <th>المتبقي (للديون)</th>
                    <th>الحالة</th>
                    <th>الإجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($commitments)): ?>
                    <tr>
                        <td colspan="8" style="text-align:center; padding:60px; color:#999;">
                            لا توجد التزامات مسجلة حاليًا<br><br>
                            <button class="btn btn-primary" id="addFirstCommitment">
                                <i class="fas fa-plus"></i> إضافة التزام جديد
                            </button>
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($commitments as $c): 
                        $remaining = ($c['type'] === 'debt') ? ($c['amount'] - ($c['paid_amount'] ?? 0)) : '';
                        $typeName = $c['type'] === 'monthly' ? 'شهري' : ($c['type'] === 'debt' ? 'دين' : 'خصم');
                        $statusClass = $c['status'] === 'active' ? 'paid' : 'pending';
                        $statusText = $c['status'] === 'active' ? 'نشط' : 'غير نشط';
                    ?>
                        <tr>
                            <td><strong><?= esc($c['name']) ?></strong><br><small><?= esc($c['recipient'] ?? '') ?></small></td>
                            <td><?= $typeName ?></td>
                            <td><?= number_format($c['amount']) ?> دينار</td>
                            <td>يوم <?= $c['payment_day'] ?></td>
                            <td><?= esc($c['recipient'] ?? '-') ?></td>
                            <td><?= $remaining ? number_format($remaining) . ' دينار' : '-' ?></td>
                            <td><span class="status <?= $statusClass ?>"><?= $statusText ?></span></td>
                            <td>
                                <button class="btn-action btn-edit" onclick="editCommitment(<?= $c['id'] ?>)" title="تعديل"><i class="fas fa-edit"></i></button>
                                <button class="btn-action btn-delete" onclick="deleteCommitment(<?= $c['id'] ?>)" title="حذف"><i class="fas fa-trash"></i></button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>


<div class="modal-overlay" id="addCommitmentModal" style="display: none;">
    <div class="modal-container">
        <div class="modal-header">
            <h3 id="modalTitle"><i class="fas fa-hand-holding-usd"></i> إضافة التزام جديد</h3>
            <button class="close-modal" onclick="closeModal('addCommitmentModal')">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="modal-body">
            <form id="addCommitmentForm">
                <input type="hidden" id="commitmentId">
                <div class="form-row">
                    <div class="form-group">
                        <label for="commitmentName">اسم الالتزام *</label>
                        <input type="text" id="commitmentName" required>
                    </div>
                    <div class="form-group">
                        <label for="commitmentType">نوع الالتزام *</label>
                        <select id="commitmentType" required>
                            <option value="monthly">شهري</option>
                            <option value="debt">دين</option>
                            <option value="deduction">خصم</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="commitmentAmount">المبلغ (دينار) *</label>
                        <input type="number" id="commitmentAmount" min="0.01" step="0.01" required>
                    </div>
                    <div class="form-group">
                        <label for="paymentDay">يوم الدفع *</label>
                        <input type="number" id="paymentDay" min="1" max="31" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="startDate">تاريخ البدء *</label>
                        <input type="date" id="startDate" required>
                    </div>
                    <div class="form-group" id="endDateGroup" style="display:none;">
                        <label for="endDate">تاريخ الانتهاء</label>
                        <input type="date" id="endDate">
                    </div>
                </div>
                <div class="form-row" id="debtFields" style="display:none;">
                    <div class="form-group">
                        <label for="paidAmount">المبلغ المدفوع حتى الآن</label>
                        <input type="number" id="paidAmount" min="0" step="0.01" value="0">
                    </div>
                    <div class="form-group">
                        <label for="monthlyPayment">الدفعة الشهرية</label>
                        <input type="number" id="monthlyPayment" min="0.01" step="0.01">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="recipient">المستلم / الجهة</label>
                        <input type="text" id="recipient">
                    </div>
                    <div class="form-group">
                        <label for="status">الحالة</label>
                        <select id="status">
                            <option value="active">نشط</option>
                            <option value="inactive">غير نشط</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="commitmentNotes">ملاحظات</label>
                    <textarea id="commitmentNotes" rows="3"></textarea>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('addCommitmentModal')">إلغاء</button>
            <button class="btn btn-primary" id="saveCommitmentBtn">حفظ الالتزام</button>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    
    document.getElementById('commitmentType')?.addEventListener('change', function() {
        const type = this.value;
        document.getElementById('endDateGroup').style.display = type === 'debt' ? 'block' : 'none';
        document.getElementById('debtFields').style.display = type === 'debt' ? 'flex' : 'none';
    });

    
    document.getElementById('addCommitmentBtn')?.addEventListener('click', function() {
        document.getElementById('modalTitle').textContent = 'إضافة التزام جديد';
        document.getElementById('addCommitmentForm').reset();
        document.getElementById('commitmentId').value = '';
        document.getElementById('startDate').valueAsDate = new Date();
        document.getElementById('commitmentType').dispatchEvent(new Event('change'));
        openModal('addCommitmentModal');
    });

    
    document.getElementById('saveCommitmentBtn')?.addEventListener('click', function() {
        alert('تم حفظ الالتزام بنجاح! (سيتم تفعيل الحفظ في قاعدة البيانات)');
        closeModal('addCommitmentModal');
    });

    
    document.getElementById('printCommitmentBtn')?.addEventListener('click', () => window.print());
    document.getElementById('exportCommitmentBtn')?.addEventListener('click', () => alert('سيتم تطوير التصدير قريبًا'));
});


function openModal(id) {
    document.getElementById(id).style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

function closeModal(id) {
    document.getElementById(id).style.display = 'none';
    document.body.style.overflow = 'auto';
}
</script>

<?= $this->endSection() ?>