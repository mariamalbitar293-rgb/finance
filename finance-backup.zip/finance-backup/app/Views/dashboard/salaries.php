<?= $this->extend('layouts/main') ?>

<?= $this->section('title') ?>
تقارير الرواتب والمصروفات
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="section-header">
    <h2><i class="fas fa-file-invoice-dollar"></i> تقارير الرواتب والمصروفات</h2>
    <div class="controls">
        <button class="btn btn-primary" id="exportSalaryBtn">
            <i class="fas fa-file-export"></i> تصدير البيانات
        </button>
        <button class="btn btn-success" id="salaryChartBtn">
            <i class="fas fa-chart-bar"></i> عرض الرسوم البيانية
        </button>
    </div>
</div>


<div class="stats-cards">
    <div class="stat-card card-1">
        <div class="stat-info">
            <h3>إجمالي الرواتب الصافية</h3>
            <div class="value"><?= number_format($stats['total_net']) ?> <span style="font-size: 1rem;">دينار</span></div>
        </div>
        <div class="stat-icon"><i class="fas fa-money-check-alt"></i></div>
    </div>

    <div class="stat-card card-2">
        <div class="stat-info">
            <h3>متوسط الراتب</h3>
            <div class="value"><?= number_format($stats['avg_salary']) ?> <span style="font-size: 1rem;">دينار</span></div>
        </div>
        <div class="stat-icon"><i class="fas fa-chart-bar"></i></div>
    </div>

    <div class="stat-card card-3">
        <div class="stat-info">
            <h3>إجمالي الحوافز</h3>
            <div class="value"><?= number_format($stats['total_bonuses']) ?> <span style="font-size: 1rem;">دينار</span></div>
        </div>
        <div class="stat-icon"><i class="fas fa-award"></i></div>
    </div>

    <div class="stat-card card-4">
        <div class="stat-info">
            <h3>إجمالي الاستقطاعات</h3>
            <div class="value"><?= number_format($stats['total_deductions']) ?> <span style="font-size: 1rem;">دينار</span></div>
        </div>
        <div class="stat-icon"><i class="fas fa-percentage"></i></div>
    </div>
</div>


<div class="table-container" style="margin-bottom: 25px;">
    <div class="table-header">
        <div class="search-filter">
            <select class="filter-select" id="employeeFilter">
                <option value="all" <?= $selected_employee === 'all' ? 'selected' : '' ?>>جميع الموظفين</option>
                <?php 
                $employees = array_unique(array_column($salaries, 'employee_name'));
                foreach ($employees as $emp): 
                ?>
                    <option value="<?= esc($emp) ?>" <?= $selected_employee === $emp ? 'selected' : '' ?>>
                        <?= esc($emp) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <input type="month" class="search-box" id="salaryMonth" value="<?= $selected_month ?>">
            <button class="btn btn-success" id="searchSalariesBtn">
                <i class="fas fa-search"></i> بحث
            </button>
        </div>
    </div>
</div>


<div class="chart-card" id="chartSection" style="display: none; margin-bottom: 30px;">
    <h3><i class="fas fa-chart-bar"></i> توزيع الرواتب والحوافز</h3>
    <div class="chart-wrapper">
        <canvas id="salaryChart"></canvas>
    </div>
</div>

<div class="table-container">
    <div class="table-header">
        <h3 style="margin: 0;"><i class="fas fa-users"></i> قائمة الرواتب</h3>
    </div>
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>اسم الموظف</th>
                    <th>المنصب</th>
                    <th>الراتب الأساسي</th>
                    <th>الحوافز</th>
                    <th>الاستقطاعات</th>
                    <th>صافي الراتب</th>
                    <th>تاريخ الصرف</th>
                    <th>الحالة</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($salaries)): ?>
                    <tr>
                        <td colspan="8" style="text-align:center;">لا توجد رواتب مسجلة لهذا الشهر</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($salaries as $salary): ?>
                        <tr>
                            <td><strong><?= esc($salary['employee_name']) ?></strong></td>
                            <td><?= esc($salary['position'] ?? 'غير محدد') ?></td>
                            <td><?= number_format($salary['basic_salary']) ?> دينار</td>
                            <td><?= number_format($salary['bonuses'] ?? 0) ?> دينار</td>
                            <td><?= number_format($salary['deductions'] ?? 0) ?> دينار</td>
                            <td><strong><?= number_format($salary['net_salary']) ?> دينار</strong></td>
                            <td><?= date('Y-m-d', strtotime($salary['payment_date'])) ?></td>
                            <td>
                                <span class="status <?= $salary['status'] === 'paid' ? 'paid' : 'pending' ?>">
                                    <?= $salary['status'] === 'paid' ? 'مسدد' : 'قيد الانتظار' ?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const salaries = <?= json_encode($salaries) ?>;

    
    const labels = salaries.map(s => s.employee_name);
    const basic = salaries.map(s => s.basic_salary);
    const bonuses = salaries.map(s => s.bonuses || 0);
    const net = salaries.map(s => s.net_salary);

    new Chart(document.getElementById('salaryChart'), {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [
                { label: 'الراتب الأساسي', data: basic, backgroundColor: '#3498db' },
                { label: 'الحوافز', data: bonuses, backgroundColor: '#2ecc71' },
                { label: 'صافي الراتب', data: net, backgroundColor: '#f39c12' }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'top', rtl: true }
            },
            scales: {
                y: { beginAtZero: true }
            }
        }
    });

    
    document.getElementById('salaryChartBtn').addEventListener('click', function() {
        const section = document.getElementById('chartSection');
        section.style.display = section.style.display === 'none' ? 'block' : 'none';
        this.innerHTML = section.style.display === 'block' 
            ? '<i class="fas fa-chart-bar"></i> إخفاء الرسم البياني' 
            : '<i class="fas fa-chart-bar"></i> عرض الرسوم البيانية';
    });

    
    document.getElementById('searchSalariesBtn').addEventListener('click', function() {
        const month = document.getElementById('salaryMonth').value;
        const employee = document.getElementById('employeeFilter').value;
        
        let url = '<?= site_url('dashboard/salaries') ?>';
        let params = new URLSearchParams();
        if (month) params.append('month', month);
        if (employee && employee !== 'all') params.append('employee', employee);
        
        window.location.href = url + '?' + params.toString();
    });

    
    document.getElementById('exportSalaryBtn').addEventListener('click', function() {
        alert('تم تصدير بيانات الرواتب بنجاح!\n(سيتم تطوير تصدير Excel/PDF قريبًا)');
    });
});
</script>

<?= $this->endSection() ?>