<?= $this->extend('layouts/main') ?>

<?= $this->section('title') ?>
التقارير السنوية والموازنات
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="section-header">
    <h2><i class="fas fa-chart-bar"></i> التقارير السنوية والموازنات</h2>
    <div class="controls">
        <button class="btn btn-primary" id="exportYearlyBtn">
            <i class="fas fa-download"></i> تصدير التقرير
        </button>
        <button class="btn btn-success" id="toggleChartsBtn">
            <i class="fas fa-chart-pie"></i> عرض الرسوم البيانية
        </button>
        <button class="btn btn-info" id="compareYearsBtn">
            <i class="fas fa-balance-scale"></i> مقارنة السنوات
        </button>
    </div>
</div>


<div class="table-container" style="margin-bottom: 25px;">
    <div class="table-header">
        <div class="search-filter">
            <?php 
            $selectedYear = $selected_year ?? date('Y');
            foreach ($available_years as $yearData): 
                $year = $yearData['year'];
                $isActive = ($year == $selectedYear) ? 'active' : '';
            ?>
                <a href="?year=<?= $year ?>" class="btn btn-<?= $isActive ? 'primary' : 'secondary' ?> year-btn">
                    <?= $year ?>
                </a>
            <?php endforeach; ?>
            
            
            <button class="btn btn-outline-primary" id="loadAllYearsBtn">
                <i class="fas fa-database"></i> تحميل جميع البيانات
            </button>
        </div>
    </div>
</div>


<div class="stats-cards">
    <div class="stat-card card-1">
        <div class="stat-info">
            <h3>إجمالي الإيرادات السنوية (<?= $selected_year ?>)</h3>
            <div class="value"><?= number_format($revenue) ?> <span style="font-size: 1rem;">دينار</span></div>
            <div id="revenueComparison" style="font-size: 0.8rem; color: #27ae60; margin-top: 5px;">
                جاري حساب المقارنة...
            </div>
        </div>
        <div class="stat-icon"><i class="fas fa-chart-line"></i></div>
    </div>

    <div class="stat-card card-2">
        <div class="stat-info">
            <h3>إجمالي المصروفات (<?= $selected_year ?>)</h3>
            <div class="value"><?= number_format($expenses) ?> <span style="font-size: 1rem;">دينار</span></div>
            <div id="expensesComparison" style="font-size: 0.8rem; color: #e74c3c; margin-top: 5px;">
                جاري حساب المقارنة...
            </div>
        </div>
        <div class="stat-icon"><i class="fas fa-receipt"></i></div>
    </div>

    <div class="stat-card card-3">
        <div class="stat-info">
            <h3>صافي الأرباح (<?= $selected_year ?>)</h3>
            <div class="value"><?= number_format($profit) ?> <span style="font-size: 1rem;">دينار</span></div>
            <div id="profitComparison" style="font-size: 0.8rem; color: #f39c12; margin-top: 5px;">
                جاري حساب المقارنة...
            </div>
        </div>
        <div class="stat-icon"><i class="fas fa-hand-holding-usd"></i></div>
    </div>

    <div class="stat-card card-4">
        <div class="stat-info">
            <h3>متوسط المبيعات الشهرية (<?= $selected_year ?>)</h3>
            <div class="value"><?= number_format($monthly_avg) ?> <span style="font-size: 1rem;">دينار</span></div>
            <div id="monthlyComparison" style="font-size: 0.8rem; color: #3498db; margin-top: 5px;">
                جاري حساب المقارنة...
            </div>
        </div>
        <div class="stat-icon"><i class="fas fa-shopping-cart"></i></div>
    </div>
</div>


<div id="yearsComparisonSection" style="display: none; margin-top: 30px;">
    <div class="table-container">
        <div class="table-header">
            <h3><i class="fas fa-balance-scale"></i> مقارنة بين السنوات</h3>
        </div>
        <table id="yearsComparisonTable">
            <thead>
                <tr>
                    <th>السنة</th>
                    <th>الإيرادات</th>
                    <th>المصروفات</th>
                    <th>صافي الأرباح</th>
                    <th>متوسط الشهري</th>
                    <th>التغيير عن السنة السابقة</th>
                </tr>
            </thead>
            <tbody id="yearsComparisonBody">
                
            </tbody>
        </table>
    </div>
</div>


<div id="chartsSection" style="display: none;">
    <div class="charts-container">
        <div class="chart-card">
            <h3><i class="fas fa-chart-pie"></i> توزيع الميزانية السنوية (<?= $selected_year ?>)</h3>
            <div class="chart-wrapper">
                <canvas id="budgetChart"></canvas>
            </div>
        </div>
        <div class="chart-card">
            <h3><i class="fas fa-chart-line"></i> الإيرادات والمصروفات خلال العام (<?= $selected_year ?>)</h3>
            <div class="chart-wrapper">
                <canvas id="revenueExpenseChart"></canvas>
            </div>
        </div>
    </div>
</div>


<div class="table-container">
    <div class="table-header">
        <h3 style="margin: 0; color: var(--dark-color);"><i class="fas fa-balance-scale"></i> الميزانية السنوية (<?= $selected_year ?>)</h3>
    </div>
    <table>
        <thead>
            <tr>
                <th>البند</th>
                <th>الميزانية المخطط لها</th>
                <th>المصروف الفعلي</th>
                <th>الانحراف</th>
                <th>النسبة</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($budget_table as $item): ?>
                <tr>
                    <td><?= esc($item['label']) ?></td>
                    <td><?= number_format($item['planned']) ?> دينار</td>
                    <td><?= number_format($item['actual']) ?> دينار</td>
                    <td class="status <?= esc($item['class']) ?>"><?= esc($item['deviation_text']) ?> دينار</td>
                    <td><?= $item['percentage'] ?>%</td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?= $this->section('scripts') ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const baseURL = '<?= base_url() ?>';
    const currentYear = <?= $selected_year ?>;

    let budgetChart = null;
    let revenueChart = null;

    
    function renderCharts(budgetValues, monthlyRevenue, monthlyExpenses) {
        if (budgetChart) budgetChart.destroy();
        if (revenueChart) revenueChart.destroy();

        
        budgetChart = new Chart(document.getElementById('budgetChart'), {
            type: 'doughnut',
            data: {
                labels: ['الرواتب', 'التشغيلية', 'التسويق', 'الأصول', 'أخرى'],
                datasets: [{
                    data: budgetValues,
                    backgroundColor: ['#3498db', '#2ecc71', '#e74c3c', '#f39c12', '#9b59b6'],
                    borderWidth: 3,
                    borderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'bottom', rtl: true } },
                cutout: '60%'
            }
        });

        
        revenueChart = new Chart(document.getElementById('revenueExpenseChart'), {
            type: 'line',
            data: {
                labels: ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'],
                datasets: [
                    {
                        label: 'الإيرادات',
                        data: Array(12).fill(Math.round(monthlyRevenue)),
                        borderColor: '#2ecc71',
                        backgroundColor: 'rgba(46,204,113,0.15)',
                        fill: true,
                        tension: 0.4
                    },
                    {
                        label: 'المصروفات',
                        data: Array(12).fill(Math.round(monthlyExpenses)),
                        borderColor: '#e74c3c',
                        backgroundColor: 'rgba(231,76,60,0.15)',
                        fill: true,
                        tension: 0.4
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'top', rtl: true } },
                scales: { y: { beginAtZero: true } }
            }
        });
    }

    
    renderCharts(<?= json_encode($budget_values) ?>, <?= $monthly_avg ?>, <?= round($expenses / 12) ?>);

    
    async function loadYearData(year) {
        try {
            const response = await fetch(`${baseURL}/api/yearly/${year}`);
            if (!response.ok) throw new Error('فشل جلب البيانات');

            const data = await response.json();

            const tableBody = document.querySelector('.table-container:last-of-type table tbody');
            tableBody.innerHTML = '';
            data.budget_table.forEach(item => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${item.label}</td>
                    <td>${item.planned.toLocaleString('ar-SA')} دينار</td>
                    <td>${item.actual.toLocaleString('ar-SA')} دينار</td>
                    <td class="status ${item.class}">${item.deviation_text} دينار</td>
                    <td>${item.percentage}%</td>
                `;
                tableBody.appendChild(row);
            });

            
            document.querySelectorAll('.year-title, .table-header h3').forEach(el => {
                if (el.textContent.includes('(')) {
                    el.innerHTML = el.innerHTML.replace(/\(\d{4}\)/, `(${year})`);
                }
            });

            
            renderCharts(data.budget_values, data.monthly_avg, Math.round(data.expenses / 12));

        } catch (error) {
            console.error(error);
            alert('حدث خطأ في تحميل بيانات السنة ' + year);
        }
    }

    
    document.querySelectorAll('.year-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const year = this.textContent.trim();

            document.querySelectorAll('.year-btn').forEach(b => {
                b.classList.remove('btn-primary');
                b.classList.add('btn-secondary');
            });
            this.classList.remove('btn-secondary');
            this.classList.add('btn-primary');

            loadYearData(year);
        });
    });

    
    document.getElementById('toggleChartsBtn').addEventListener('click', function() {
        const section = document.getElementById('chartsSection');
        const isHidden = section.style.display === 'none' || section.style.display === '';
        section.style.display = isHidden ? 'block' : 'none';
        this.innerHTML = isHidden 
            ? '<i class="fas fa-eye-slash"></i> إخفاء الرسوم البيانية'
            : '<i class="fas fa-chart-pie"></i> عرض الرسوم البيانية';

        if (isHidden) {
            setTimeout(() => renderCharts(<?= json_encode($budget_values) ?>, <?= $monthly_avg ?>, <?= round($expenses / 12) ?>), 100);
        }
    });

    
    async function loadAllYears() {
        try {
            const years = <?= json_encode(array_column($available_years, 'year')) ?>;
            const promises = years.map(year => fetch(`${baseURL}/api/yearly/${year}`).then(res => res.ok ? res.json() : null));
            const results = await Promise.all(promises);
            const validResults = results.filter(r => r !== null);

            updateComparisons(validResults);
            populateComparisonTable(validResults);

        } catch (error) {
            console.error('خطأ في تحميل البيانات:', error);
            alert('حدث خطأ أثناء تحميل البيانات');
        }
    }

    
    function calculatePercentageChange(current, previous) {
        if (previous === 0) return { percentage: 100, value: current };
        const percentage = ((current - previous) / previous) * 100;
        return { percentage: Math.round(percentage * 10) / 10, value: Math.round(current - previous) };
    }

    function updateComparisonElement(elementId, change, label) {
        const element = document.getElementById(elementId);
        if (!element) return;
        if (change.percentage > 0) {
            element.innerHTML = `↑ ${Math.abs(change.percentage)}% عن ${label} العام الماضي (+${new Intl.NumberFormat('ar-SA').format(change.value)})`;
            element.style.color = '#27ae60';
        } else if (change.percentage < 0) {
            element.innerHTML = `↓ ${Math.abs(change.percentage)}% عن ${label} العام الماضي (${new Intl.NumberFormat('ar-SA').format(Math.abs(change.value))})`;
            element.style.color = '#e74c3c';
        } else {
            element.innerHTML = `مستقر عن ${label} العام الماضي`;
            element.style.color = '#7f8c8d';
        }
    }

    function populateComparisonTable(yearsData) {
        const tableBody = document.getElementById('yearsComparisonBody');
        tableBody.innerHTML = '';
        yearsData.sort((a, b) => b.year - a.year);
        yearsData.forEach((yearData, index) => {
            const prevYearData = yearsData[index + 1];
            let changeText = '-';
            let changeClass = '';
            if (prevYearData) {
                const change = calculatePercentageChange(yearData.revenue, prevYearData.revenue);
                if (change.percentage !== 0) {
                    changeText = `${change.percentage > 0 ? '↑' : '↓'} ${Math.abs(change.percentage)}%`;
                    changeClass = change.percentage > 0 ? 'text-success' : 'text-danger';
                }
            }
            const row = `
                <tr>
                    <td><strong>${yearData.year}</strong></td>
                    <td>${new Intl.NumberFormat('ar-SA').format(yearData.revenue)} دينار</td>
                    <td>${new Intl.NumberFormat('ar-SA').format(yearData.expenses)} دينار</td>
                    <td>${new Intl.NumberFormat('ar-SA').format(yearData.profit)} دينار</td>
                    <td>${new Intl.NumberFormat('ar-SA').format(Math.round(yearData.revenue / 12))} دينار</td>
                    <td class="${changeClass}">${changeText}</td>
                </tr>
            `;
            tableBody.innerHTML += row;
        });
    }

    function updateComparisons(yearsData) {
        yearsData.sort((a, b) => b.year - a.year);
        const currentData = yearsData.find(y => y.year == currentYear);
        if (!currentData) return;
        const previousData = yearsData.find(y => y.year == currentYear - 1);
        if (previousData) {
            const revenueChange = calculatePercentageChange(currentData.revenue, previousData.revenue);
            const expensesChange = calculatePercentageChange(currentData.expenses, previousData.expenses);
            const profitChange = calculatePercentageChange(currentData.profit, previousData.profit);
            const monthlyChange = calculatePercentageChange(Math.round(currentData.revenue / 12), Math.round(previousData.revenue / 12));

            updateComparisonElement('revenueComparison', revenueChange, 'الإيرادات');
            updateComparisonElement('expensesComparison', expensesChange, 'المصروفات');
            updateComparisonElement('profitComparison', profitChange, 'الأرباح');
            updateComparisonElement('monthlyComparison', monthlyChange, 'المتوسط الشهري');
        }
    }

    
    document.getElementById('compareYearsBtn').addEventListener('click', function() {
        const section = document.getElementById('yearsComparisonSection');
        const isVisible = section.style.display === 'block';
        section.style.display = isVisible ? 'none' : 'block';
        this.innerHTML = isVisible ? '<i class="fas fa-balance-scale"></i> مقارنة السنوات' : '<i class="fas fa-times"></i> إغلاق المقارنة';
        if (!isVisible) loadAllYears();
    });

    document.getElementById('loadAllYearsBtn').addEventListener('click', loadAllYears);

    document.getElementById('exportYearlyBtn').addEventListener('click', async () => {
        try {
            const response = await fetch(`${baseURL}/api/yearly/export/${currentYear}`);
            const data = await response.json();
            if (response.ok) {
                const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `التقرير_السنوي_${currentYear}.json`;
                a.click();
                URL.revokeObjectURL(url);
            } else {
                alert('حدث خطأ أثناء تصدير التقرير');
            }
        } catch (error) {
            alert('حدث خطأ في الاتصال');
        }
    });

    
    loadAllYears();
});
</script>
<?= $this->endSection() ?>