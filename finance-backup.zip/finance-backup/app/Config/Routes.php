<?php

namespace Config;

use CodeIgniter\Router\RouteCollection;

$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();

// ===== Routes الرئيسية =====
$routes->get('/', 'Main::index');

// ===== Dashboard Routes =====
$routes->group('dashboard', function(RouteCollection $routes) {
    $routes->get('/', 'Dashboard::index');
    $routes->get('clients', 'Dashboard::clients');
    $routes->get('yearlyReports', 'Dashboard::yearlyReports');
    $routes->get('salaries', 'Dashboard::salaries');
    $routes->get('commitments', 'Dashboard::commitments');
    $routes->get('assets', 'Dashboard::assets');
});


// ===== API Routes =====
$routes->group('api', function(RouteCollection $routes) {
    // Clients API
    $routes->get('clients', 'ClientApi::index');
    $routes->post('clients', 'ClientApi::create');
    $routes->put('clients/(:num)', 'ClientApi::update/$1');
    $routes->delete('clients/(:num)', 'ClientApi::delete/$1');
    $routes->get('clients/stats', 'ClientApi::stats');

    // Commitments API
    $routes->get('commitments', 'CommitmentApi::index');
    $routes->get('commitments/stats', 'CommitmentApi::stats');
    $routes->post('commitments', 'CommitmentApi::create');
    $routes->put('commitments/(:num)', 'CommitmentApi::update/$1');
    $routes->delete('commitments/(:num)', 'CommitmentApi::delete/$1');

    
    $routes->get('assets', 'AssetApi::index');
    $routes->get('assets/stats', 'AssetApi::stats');
    $routes->post('assets', 'AssetApi::create');
    $routes->match(['put', 'post'], 'assets/(:num)', 'AssetApi::update/$1');  // ملاحظة: POST مع id للتحديث (أو استخدم PUT)
    $routes->delete('assets/(:num)', 'AssetApi::delete/$1');

    
    
    $routes->get('yearly', 'YearlyReportApi::index');
    $routes->get('yearly/(:num)', 'YearlyReportApi::show/$1');
    $routes->get('yearly-test', 'YearlyTest::index');
    $routes->get('yearlyReports', 'Dashboard::yearlyReports');
});