<?php
echo "<h1> اختبار نهائي</h1>";
echo "PHP Version: " . phpversion() . "<br>";
echo "Time: " . date("Y-m-d H:i:s") . "<br>";
echo "Config Files: " . count(glob("app/Config/*.php")) . "<br>";
echo "<h2><a href='/'> اضغط هنا للصفحة الرئيسية</a></h2>";
