<?php
echo "<h1>اختبار سريع</h1>";

// جرب تحميل الثوابت
try {
    require_once __DIR__ . "/../app/Config/Constants.php";
    echo " تم تحميل Constants.php<br>";
    
    echo "EXIT_ERROR: " . (defined("EXIT_ERROR") ? EXIT_ERROR : "غير معرف") . "<br>";
    
    if (defined("COMPOSER_PATH") && file_exists(constant("COMPOSER_PATH"))) {
        require_once constant("COMPOSER_PATH");
        echo " تم تحميل Composer<br>";
        
        // جرب تحميل CodeIgniter
        try {
            require_once __DIR__ . "/../app/Config/Paths.php";
            $paths = new Config\Paths();
            echo " تم تحميل Paths<br>";
            
            echo "<h2 style='color:green;'> كل شيء جاهز!</h2>";
            echo "<a href='/' style='font-size:20px;'> اضغط هنا للصفحة الرئيسية</a>";
            
        } catch (Exception $e) {
            echo " خطأ في Paths: " . $e->getMessage();
        }
    }
} catch (Exception $e) {
    echo " خطأ: " . $e->getMessage();
}
