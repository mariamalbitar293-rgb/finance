function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
}


document.addEventListener('DOMContentLoaded', function() {
    
    const dateElement = document.getElementById('current-date');
    if (dateElement) {
        const now = new Date();
        dateElement.textContent = now.toLocaleDateString('ar-EG');
    }

    
    setupEventListeners();

    setupTableFilters();
});


function setupEventListeners() {
    
    const toggleBtn = document.getElementById('toggleSidebarBtn');
    if (toggleBtn) {
        toggleBtn.addEventListener('click', toggleSidebar);
    }

    
    const floatingBtn = document.getElementById('floatingAddBtn');
    if (floatingBtn) {
        floatingBtn.addEventListener('click', openAddClientModal);
    }

    
    const addBtn = document.getElementById('addClientBtn');
    if (addBtn) {
        addBtn.addEventListener('click', openAddClientModal);
    }

    
    setupModalButtons();


    document.querySelectorAll('.modal-overlay').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                closeModal(this.id);
            }
        });
    });

    
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            document.querySelectorAll('.modal-overlay').forEach(modal => {
                closeModal(modal.id);
            });
        }
    });

    
    const refreshBtn = document.getElementById('refreshClientsBtn');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', () => {
            location.reload();
        });
    }
}


function toggleSidebar() {
    document.body.classList.toggle('sidebar-collapsed');
}


function setupTableFilters() {
    const searchInput = document.getElementById('clientSearch');
    const statusFilter = document.getElementById('statusFilter');
    const tableRows = document.querySelectorAll('#clientsTableBody tr');

    function filterTable() {
        const searchTerm = searchInput?.value.toLowerCase() || '';
        const status = statusFilter?.value || 'all';

        tableRows.forEach(row => {
            if (row.cells.length < 7) return;

            const name = row.cells[0].textContent.toLowerCase();
            const notes = row.cells[4].textContent.toLowerCase();
            const paidText = row.cells[2].textContent.replace(/[^0-9]/g, '');
            const principalText = row.cells[1].textContent.replace(/[^0-9]/g, '');
            const paid = parseFloat(paidText) || 0;
            const principal = parseFloat(principalText) || 0;

            let clientStatus = 'pending';
            if (paid === principal && paid > 0) clientStatus = 'paid';
            else if (paid > 0 && paid < principal) clientStatus = 'partial';

            const matchesSearch = name.includes(searchTerm) || notes.includes(searchTerm);
            const matchesStatus = status === 'all' || clientStatus === status;

            row.style.display = matchesSearch && matchesStatus ? '' : 'none';
        });
    }

    searchInput?.addEventListener('input', filterTable);
    statusFilter?.addEventListener('change', filterTable);
}


function setupModalButtons() {
    const cancelBtn = document.getElementById('cancelAddClientBtn');
    if (cancelBtn) {
        cancelBtn.addEventListener('click', () => closeModal('addClientModal'));
    }

    
    const principalInput = document.getElementById('principalAmount');
    const paidInput = document.getElementById('paidAmount');
    if (principalInput) principalInput.addEventListener('input', updatePaymentProgress);
    if (paidInput) paidInput.addEventListener('input', updatePaymentProgress);
}


function openAddClientModal() {
    const form = document.getElementById('addClientForm');
    if (form) form.reset();

    const dateInput = document.getElementById('clientDate');
    if (dateInput) dateInput.valueAsDate = new Date();

    const clientId = document.getElementById('clientId');
    if (clientId) clientId.value = '';

    const saveAnotherBtn = document.getElementById('saveAndAddAnotherBtn');
    if (saveAnotherBtn) saveAnotherBtn.style.display = 'inline-flex';

    updatePaymentProgress();
    openModal('addClientModal');

    document.getElementById('clientName')?.focus();
}

function updatePaymentProgress() {
    const principal = parseFloat(document.getElementById('principalAmount')?.value) || 0;
    const paid = parseFloat(document.getElementById('paidAmount')?.value) || 0;
    const progressBar = document.getElementById('paymentProgress');
    const percentageText = document.getElementById('paymentPercentage');

    if (!progressBar || !percentageText) return;

    if (principal > 0) {
        const percentage = Math.min(100, (paid / principal) * 100);
        progressBar.style.width = percentage + '%';
        percentageText.textContent = percentage.toFixed(1) + '%';
    } else {
        progressBar.style.width = '0%';
        percentageText.textContent = '0%';
    }
}