let clientsData = [];


async function loadClients() {
    try {
        const [clientsRes, statsRes] = await Promise.all([
            fetch(baseURL + '/api/clients'),
            fetch(baseURL + '/api/clients/stats')
        ]);

        clientsData = await clientsRes.json();
        const stats = await statsRes.json();

        renderClientsTable();
        updateStats(stats);
    } catch (err) {
        alert('فشل تحميل البيانات');
        console.error(err);
    }
}

function updateStats(stats) {
    document.getElementById('totalClients').textContent = stats.total_clients;
    document.getElementById('totalPrincipal').textContent = Number(stats.total_principal).toLocaleString();
    document.getElementById('totalPaid').textContent = Number(stats.total_paid).toLocaleString();
    document.getElementById('totalRemaining').textContent = Number(stats.total_remaining).toLocaleString();
}

function renderClientsTable() {
    const tbody = document.getElementById('clientsTableBody');
    tbody.innerHTML = '';

    if (clientsData.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7">لا يوجد عملاء</td></tr>';
        return;
    }

    clientsData.forEach(client => {
        const remaining = client.principal - client.paid;
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${client.name}</td>
            <td>${Number(client.principal).toLocaleString()} دينار</td>
            <td>${Number(client.paid).toLocaleString()} دينار</td>
            <td>${Number(remaining).toLocaleString()} دينار</td>
            <td>${client.notes || 'لا توجد'}</td>
            <td>${client.date}</td>
            <td>
                <button class="btn-action btn-edit" onclick="editClient(${client.id})">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn-action btn-delete" onclick="deleteClient(${client.id})">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
}


async function saveNewClient(addAnother = false) {
    const id = document.getElementById('clientId').value;
    const name = document.getElementById('clientName').value.trim();
    const phone = document.getElementById('clientPhone').value.trim();
    const principal = parseFloat(document.getElementById('principalAmount').value);
    const paid = parseFloat(document.getElementById('paidAmount').value) || 0;
    const date = document.getElementById('clientDate').value;
    const notes = document.getElementById('clientNotes').value.trim();

    if (!name || isNaN(principal)) {
        alert('الرجاء إدخال الاسم والمبلغ الأساسي');
        return;
    }

    if (paid > principal) {
        alert('المدفوع لا يمكن أن يكون أكبر من الأساسي');
        return;
    }

    const data = { name, phone, principal, paid, date, notes: notes || null };

    try {
        let response;
        if (id) {
            
            response = await fetch(baseURL + `/api/clients/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
        } else {
            
            response = await fetch(baseURL + '/api/clients', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
        }

        const result = await response.json();

        if (response.ok) {
            alert(id ? 'تم التحديث بنجاح' : 'تم الإضافة بنجاح');
            loadClients();

            if (!addAnother && !id) {
                closeModal('addClientModal');
            } else if (addAnother) {
                document.getElementById('addClientForm').reset();
                document.getElementById('clientDate').valueAsDate = new Date();
                document.getElementById('clientName').focus();
                document.getElementById('clientId').value = '';
                updatePaymentProgress();
            }
        } else {
            alert('خطأ: ' + JSON.stringify(result));
        }
    } catch (err) {
        alert('فشل الاتصال بالسيرفر');
        console.error(err);
    }
}


function editClient(id) {
    const client = clientsData.find(c => c.id == id);
    if (!client) return;

    document.getElementById('clientId').value = client.id;
    document.getElementById('clientName').value = client.name;
    document.getElementById('clientPhone').value = client.phone || '';
    document.getElementById('principalAmount').value = client.principal;
    document.getElementById('paidAmount').value = client.paid;
    document.getElementById('clientDate').value = client.date;
    document.getElementById('clientNotes').value = client.notes || '';

    document.getElementById('saveAndAddAnotherBtn').style.display = 'none';
    updatePaymentProgress();
    openModal('addClientModal');
}

async function deleteClient(id) {
    if (!confirm('هل أنت متأكد من حذف هذا العميل؟')) return;

    try {
        const response = await fetch(baseURL + `/api/clients/${id}`, { method: 'DELETE' });
        if (response.ok) {
            alert('تم الحذف بنجاح');
            loadClients();
        } else {
            alert('فشل الحذف');
        }
    } catch (err) {
        alert('فشل الاتصال');
    }
}


document.getElementById('saveClientBtn')?.addEventListener('click', () => saveNewClient(false));
document.getElementById('saveAndAddAnotherBtn')?.addEventListener('click', () => saveNewClient(true));


document.addEventListener('DOMContentLoaded', () => {
    
    const currentPath = window.location.pathname;

    
    if (currentPath.includes('/dashboard/clients') || currentPath.endsWith('/clients')) {
        window.baseURL = '<?= base_url() ?>';
        loadClients();
        setupTableFilters();
    }
});