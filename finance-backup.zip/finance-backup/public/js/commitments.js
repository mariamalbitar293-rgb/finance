let commitmentsData = [
    {
        id: 1,
        name: "إيجار المحل التجاري",
        type: "monthly",
        amount: 2000,
        paymentDay: 5,
        startDate: "2024-01-01",
        endDate: "",
        recipient: "شركة الأموال للتجارة",
        status: "active",
        notes: "إيجار شهري للمحل الرئيسي",
        paidThisMonth: true
    },
    {
        id: 2,
        name: "رواتب الموظفين",
        type: "monthly",
        amount: 2400,
        paymentDay: 10,
        startDate: "2024-01-01",
        endDate: "",
        recipient: "موظفو الشركة",
        status: "active",
        notes: "رواتب شهرية لـ 5 موظفين",
        paidThisMonth: true
    },
    {
        id: 3,
        name: "فواتير المياه والكهرباء",
        type: "monthly",
        amount: 300,
        paymentDay: 15,
        startDate: "2024-01-01",
        endDate: "",
        recipient: "شركة الكهرباء الوطنية",
        status: "active",
        notes: "فاتورة شهرية للخدمات",
        paidThisMonth: true
    },
    {
        id: 4,
        name: "فواتير الإنترنت والهاتف",
        type: "monthly",
        amount: 200,
        paymentDay: 20,
        startDate: "2024-01-01",
        endDate: "",
        recipient: "شركة اتصالات الوطن",
        status: "active",
        notes: "اشتراك شهري للإنترنت والهاتف",
        paidThisMonth: false
    },
    {
        id: 5,
        name: "ديون بنكية - قرض تجاري",
        type: "debt",
        amount: 10000,
        paymentDay: 25,
        startDate: "2024-06-01",
        endDate: "2026-12-01",
        recipient: "البنك التجاري الوطني",
        status: "active",
        notes: "قرض تجاري لمدة 30 شهرًا",
        paidAmount: 4000,
        monthlyPayment: 500
    },
    {
        id: 6,
        name: "تسهيلات تجارية - مورد المواد",
        type: "debt",
        amount: 2500,
        paymentDay: 30,
        startDate: "2025-01-01",
        endDate: "2025-12-01",
        recipient: "شركة مواد البناء المتحدة",
        status: "active",
        notes: "تسهيلات تجارية لمدة 12 شهرًا",
        paidAmount: 1500,
        monthlyPayment: 200
    },
    {
        id: 7,
        name: "خصم ضريبي شهري",
        type: "deduction",
        amount: 100,
        paymentDay: 31,
        startDate: "2025-01-01",
        endDate: "",
        recipient: "دائرة ضريبة الدخل",
        status: "active",
        notes: "خصم ضريبة دخل شهرية",
        paidThisMonth: false
    }
];


function initCommitmentsManagement() {
    renderCommitmentsTable();
    setupCommitmentsEventListeners();
    updateCommitmentStats();
    checkDueCommitments();
    
    
    const today = new Date().toISOString().split('T')[0];
    const startDateInput = document.getElementById('startDate');
    if (startDateInput && !startDateInput.value) {
        startDateInput.value = today;
    }
}


function renderCommitmentsTable(commitments = commitmentsData) {
    const tableBody = document.querySelector('#commitmentsTableBody, table tbody');
    if (!tableBody) return;
    
    tableBody.innerHTML = '';
    
    if (commitments.length === 0) {
        tableBody.innerHTML = `
            <tr>
                <td colspan="8" class="text-center">
                    <div style="padding: 40px;">
                        <i class="fas fa-hand-holding-usd" style="font-size: 48px; color: #ddd; margin-bottom: 20px;"></i>
                        <p style="color: #999;">لا يوجد التزامات حالياً</p>
                        <button class="btn btn-primary" onclick="openModal('addCommitmentModal')">
                            <i class="fas fa-plus"></i> إضافة التزام جديد
                        </button>
                    </div>
                </td>
            </tr>
        `;
        return;
    }
    
    commitments.forEach(commitment => {
        const row = document.createElement('tr');
        
        
        let remainingAmount = '';
        if (commitment.type === 'debt' && commitment.paidAmount !== undefined) {
            const remaining = commitment.amount - (commitment.paidAmount || 0);
            remainingAmount = formatCurrency(remaining);
        }
        
        
        let paymentStatus = '';
        if (commitment.paidThisMonth !== undefined) {
            paymentStatus = commitment.paidThisMonth ? 
                '<span class="status paid">تم الدفع</span>' : 
                '<span class="status pending">قيد الانتظار</span>';
        }
        
        
        let typeText = getCommitmentTypeName(commitment.type);
        
        row.innerHTML = `
            <td>
                <div class="commitment-info">
                    <strong>${commitment.name}</strong>
                    ${commitment.recipient ? `<br><small class="text-muted">${commitment.recipient}</small>` : ''}
                </div>
            </td>
            <td>${typeText}</td>
            <td>${formatCurrency(commitment.amount)}</td>
            <td>
                <span class="badge badge-primary">يوم ${commitment.paymentDay}</span>
            </td>
            <td>
                <small>${formatDate(commitment.startDate)}</small>
                ${commitment.endDate ? `<br><small class="text-muted">ينتهي: ${formatDate(commitment.endDate)}</small>` : ''}
            </td>
            <td>${remainingAmount || '-'}</td>
            <td>${paymentStatus || getStatusText(commitment.status)}</td>
            <td>
                <div class="action-buttons">
                    <button class="btn-action btn-edit" onclick="editCommitment(${commitment.id})" title="تعديل">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn-action btn-delete" onclick="deleteCommitment(${commitment.id})" title="حذف">
                        <i class="fas fa-trash"></i>
                    </button>
                    ${commitment.paidThisMonth === false ? `
                        <button class="btn-action btn-success" onclick="markAsPaid(${commitment.id})" title="تحديد كمدفوع">
                            <i class="fas fa-check"></i>
                        </button>
                    ` : ''}
                </div>
            </td>
        `;
        
        tableBody.appendChild(row);
    });
}


function updateCommitmentStats() {
    const totalMonthly = commitmentsData
        .filter(c => c.type === 'monthly' && c.status === 'active')
        .reduce((sum, c) => sum + c.amount, 0);
        
    const totalDebts = commitmentsData
        .filter(c => c.type === 'debt' && c.status === 'active')
        .reduce((sum, c) => sum + (c.amount - (c.paidAmount || 0)), 0);
        
    const totalDeductions = commitmentsData
        .filter(c => c.type === 'deduction' && c.status === 'active')
        .reduce((sum, c) => sum + c.amount, 0);
        
    const activeCount = commitmentsData.filter(c => c.status === 'active').length;
    
    
    const totalMonthlyElement = document.getElementById('totalMonthlyCommitments');
    const totalDebtsElement = document.getElementById('totalDebts');
    const totalDeductedElement = document.getElementById('totalDeducted');
    const activeCommitmentsElement = document.getElementById('activeCommitments');
    const commitmentBadgeElement = document.getElementById('commitmentBadge');
    
    if (totalMonthlyElement) {
        totalMonthlyElement.innerHTML = `${formatCurrency(totalMonthly, 'دينار')}`;
    }
    
    if (totalDebtsElement) {
        totalDebtsElement.innerHTML = `${formatCurrency(totalDebts, 'دينار')}`;
    }
    
    if (totalDeductedElement) {
        totalDeductedElement.innerHTML = `${formatCurrency(totalDeductions, 'دينار')}`;
    }
    
    if (activeCommitmentsElement) {
        activeCommitmentsElement.innerHTML = activeCount;
    }
    
    if (commitmentBadgeElement) {
        commitmentBadgeElement.textContent = activeCount;
    }
}


function setupCommitmentsEventListeners() {
    
    const addCommitmentBtn = document.getElementById('addCommitmentBtn');
    if (addCommitmentBtn) {
        addCommitmentBtn.addEventListener('click', () => openAddCommitmentModal());
    }
    
    
    const commitmentSearch = document.getElementById('commitmentSearch');
    if (commitmentSearch) {
        commitmentSearch.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const filteredCommitments = commitmentsData.filter(commitment => 
                commitment.name.toLowerCase().includes(searchTerm) || 
                (commitment.recipient && commitment.recipient.toLowerCase().includes(searchTerm)) ||
                commitment.notes.toLowerCase().includes(searchTerm)
            );
            renderCommitmentsTable(filteredCommitments);
        });
    }
    
    
    const commitmentTypeFilter = document.getElementById('commitmentTypeFilter');
    if (commitmentTypeFilter) {
        commitmentTypeFilter.addEventListener('change', function() {
            const type = this.value;
            let filteredCommitments = [];
            
            if (type === 'all') {
                filteredCommitments = commitmentsData;
            } else {
                filteredCommitments = commitmentsData.filter(c => c.type === type);
            }
            
            renderCommitmentsTable(filteredCommitments);
        });
    }
    
    
    const saveCommitmentBtn = document.getElementById('saveCommitmentBtn');
    if (saveCommitmentBtn) {
        saveCommitmentBtn.addEventListener('click', saveNewCommitment);
    }
    
    
    const closeCommitmentModalBtn = document.getElementById('closeCommitmentModalBtn');
    const cancelAddCommitmentBtn = document.getElementById('cancelAddCommitmentBtn');
    
    if (closeCommitmentModalBtn) {
        closeCommitmentModalBtn.addEventListener('click', () => closeAddCommitmentModal());
    }
    
    if (cancelAddCommitmentBtn) {
        cancelAddCommitmentBtn.addEventListener('click', () => closeAddCommitmentModal());
    }
    
    const exportCommitmentBtn = document.getElementById('exportCommitmentBtn');
    if (exportCommitmentBtn) {
        exportCommitmentBtn.addEventListener('click', exportCommitmentsData);
    }
    
    
    const printCommitmentBtn = document.getElementById('printCommitmentBtn');
    if (printCommitmentBtn) {
        printCommitmentBtn.addEventListener('click', () => {
            window.print();
            showNotification('جارٍ تحضير تقرير الالتزامات للطباعة...');
        });
    }
    
    
    const commitmentTypeSelect = document.getElementById('commitmentType');
    if (commitmentTypeSelect) {
        commitmentTypeSelect.addEventListener('change', updateCommitmentFormFields);
    }
    
    
    const addCommitmentModal = document.getElementById('addCommitmentModal');
    if (addCommitmentModal) {
        addCommitmentModal.addEventListener('click', function(e) {
            if (e.target === this) {
                closeAddCommitmentModal();
            }
        });
    }
    
    
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && addCommitmentModal && addCommitmentModal.style.display === 'flex') {
            closeAddCommitmentModal();
        }
    });
}


function openAddCommitmentModal() {
    
    const form = document.getElementById('addCommitmentForm');
    if (form) form.reset();
    
    
    const commitmentIdInput = document.getElementById('commitmentId');
    if (commitmentIdInput) commitmentIdInput.value = '';
    
    
    const today = new Date().toISOString().split('T')[0];
    const startDateInput = document.getElementById('startDate');
    if (startDateInput) startDateInput.value = today;
    
    
    const statusSelect = document.getElementById('status');
    if (statusSelect) statusSelect.value = 'active';
    
    
    updateCommitmentFormFields();
    

    const saveCommitmentBtn = document.getElementById('saveCommitmentBtn');
    if (saveCommitmentBtn) {
        saveCommitmentBtn.innerHTML = '<i class="fas fa-save"></i> حفظ الالتزام';
        saveCommitmentBtn.onclick = saveNewCommitment;
    }
    
    
    const saveAndAddAnotherBtn = document.getElementById('saveAndAddAnotherBtn');
    if (saveAndAddAnotherBtn) {
        saveAndAddAnotherBtn.style.display = 'inline-flex';
    }
    
    
    openModal('addCommitmentModal');
    
    
    const commitmentNameInput = document.getElementById('commitmentName');
    if (commitmentNameInput) {
        setTimeout(() => {
            commitmentNameInput.focus();
        }, 300);
    }
    
    showNotification('فتح نموذج إضافة التزام جديد');
}


function closeAddCommitmentModal() {
    closeModal('addCommitmentModal');
    const form = document.getElementById('addCommitmentForm');
    if (form) form.reset();
    
    
    const today = new Date().toISOString().split('T')[0];
    const startDateInput = document.getElementById('startDate');
    if (startDateInput) startDateInput.value = today;
    
    
    const commitmentIdInput = document.getElementById('commitmentId');
    if (commitmentIdInput) commitmentIdInput.value = '';
}


function updateCommitmentFormFields() {
    const type = document.getElementById('commitmentType')?.value;
    const endDateGroup = document.querySelector('#endDateGroup, [data-group="endDate"]');
    const paidAmountGroup = document.querySelector('#paidAmountGroup, [data-group="paidAmount"]');
    const monthlyPaymentGroup = document.querySelector('#monthlyPaymentGroup, [data-group="monthlyPayment"]');
    
    if (endDateGroup) {
        if (type === 'debt') {
            endDateGroup.style.display = 'flex';
        } else {
            endDateGroup.style.display = 'none';
        }
    }
    
    if (paidAmountGroup && monthlyPaymentGroup) {
        if (type === 'debt') {
            paidAmountGroup.style.display = 'flex';
            monthlyPaymentGroup.style.display = 'flex';
        } else {
            paidAmountGroup.style.display = 'none';
            monthlyPaymentGroup.style.display = 'none';
        }
    }
}

function saveNewCommitment() {
    const name = document.getElementById('commitmentName')?.value.trim();
    const type = document.getElementById('commitmentType')?.value;
    const amount = parseFloat(document.getElementById('commitmentAmount')?.value);
    const paymentDay = parseInt(document.getElementById('paymentDay')?.value);
    const startDate = document.getElementById('startDate')?.value;
    const endDate = document.getElementById('endDate')?.value;
    const recipient = document.getElementById('recipient')?.value.trim();
    const status = document.getElementById('status')?.value;
    const notes = document.getElementById('commitmentNotes')?.value.trim() || 'لا توجد تفاصيل';
    const paidAmount = parseFloat(document.getElementById('paidAmount')?.value) || 0;
    const monthlyPayment = parseFloat(document.getElementById('monthlyPayment')?.value) || 0;
    
    
    if (!name || !amount || isNaN(amount) || !paymentDay || isNaN(paymentDay) || !startDate) {
        showNotification('الرجاء ملء جميع الحقول المطلوبة بشكل صحيح', 'error');
        return;
    }
    
    if (paymentDay < 1 || paymentDay > 31) {
        showNotification('يوم الدفع يجب أن يكون بين 1 و 31', 'error');
        return;
    }
    
    if (amount <= 0) {
        showNotification('المبلغ يجب أن يكون أكبر من صفر', 'error');
        return;
    }
    
    if (type === 'debt' && paidAmount > amount) {
        showNotification('المبلغ المدفوع لا يمكن أن يكون أكبر من المبلغ الإجمالي', 'error');
        return;
    }
    
    
    const commitmentIdInput = document.getElementById('commitmentId');
    const commitmentId = commitmentIdInput ? parseInt(commitmentIdInput.value) : null;
    
    if (commitmentId) {
        
        updateCommitment(commitmentId, { 
            name, type, amount, paymentDay, startDate, endDate, 
            recipient, status, notes, paidAmount, monthlyPayment 
        });
        closeAddCommitmentModal();
    } else {
        
        const newCommitment = {
            id: commitmentsData.length > 0 ? Math.max(...commitmentsData.map(c => c.id)) + 1 : 1,
            name: name,
            type: type,
            amount: amount,
            paymentDay: paymentDay,
            startDate: startDate,
            endDate: endDate || '',
            recipient: recipient || '',
            status: status || 'active',
            notes: notes,
            paidThisMonth: false
        };
        
        
        if (type === 'debt') {
            newCommitment.paidAmount = paidAmount;
            newCommitment.monthlyPayment = monthlyPayment || Math.round(amount / 12);
        }
        
        commitmentsData.unshift(newCommitment);
        renderCommitmentsTable();
        updateCommitmentStats();
        showNotification(`تم إضافة الالتزام ${name} بنجاح`);
        closeAddCommitmentModal();
    }
}


function editCommitment(id) {
    const commitment = commitmentsData.find(c => c.id === id);
    if (!commitment) {
        showNotification('لم يتم العثور على الالتزام', 'error');
        return;
    }
    
    
    document.getElementById('commitmentId').value = commitment.id;
    document.getElementById('commitmentName').value = commitment.name;
    document.getElementById('commitmentType').value = commitment.type;
    document.getElementById('commitmentAmount').value = commitment.amount;
    document.getElementById('paymentDay').value = commitment.paymentDay;
    document.getElementById('startDate').value = commitment.startDate;
    document.getElementById('endDate').value = commitment.endDate || '';
    document.getElementById('recipient').value = commitment.recipient || '';
    document.getElementById('status').value = commitment.status;
    document.getElementById('commitmentNotes').value = commitment.notes || '';
    
    if (commitment.type === 'debt') {
        document.getElementById('paidAmount').value = commitment.paidAmount || 0;
        document.getElementById('monthlyPayment').value = commitment.monthlyPayment || 0;
    }
    
    
    updateCommitmentFormFields();
    
    
    const saveAndAddAnotherBtn = document.getElementById('saveAndAddAnotherBtn');
    if (saveAndAddAnotherBtn) {
        saveAndAddAnotherBtn.style.display = 'none';
    }
    
    const saveCommitmentBtn = document.getElementById('saveCommitmentBtn');
    if (saveCommitmentBtn) {
        saveCommitmentBtn.innerHTML = '<i class="fas fa-save"></i> تحديث البيانات';
    }
    
    
    openModal('addCommitmentModal');
    showNotification('فتح نموذج تعديل بيانات الالتزام');
}


function updateCommitment(id, data) {
    const commitmentIndex = commitmentsData.findIndex(c => c.id === id);
    if (commitmentIndex !== -1) {
        const updatedCommitment = {
            id: id,
            name: data.name,
            type: data.type,
            amount: data.amount,
            paymentDay: data.paymentDay,
            startDate: data.startDate,
            endDate: data.endDate || '',
            recipient: data.recipient,
            status: data.status,
            notes: data.notes || 'لا توجد تفاصيل',
            paidThisMonth: commitmentsData[commitmentIndex].paidThisMonth
        };
        
        if (data.type === 'debt') {
            updatedCommitment.paidAmount = data.paidAmount || 0;
            updatedCommitment.monthlyPayment = data.monthlyPayment || Math.round(data.amount / 12);
        }
        
        commitmentsData[commitmentIndex] = updatedCommitment;
        renderCommitmentsTable();
        updateCommitmentStats();
        showNotification(`تم تحديث بيانات الالتزام ${data.name} بنجاح`);
    }
}


function deleteCommitment(id) {
    if (!confirm('هل أنت متأكد من حذف هذا الالتزام؟')) {
        return;
    }
    
    const commitmentIndex = commitmentsData.findIndex(c => c.id === id);
    if (commitmentIndex !== -1) {
        const commitmentName = commitmentsData[commitmentIndex].name;
        commitmentsData.splice(commitmentIndex, 1);
        renderCommitmentsTable();
        updateCommitmentStats();
        showNotification(`تم حذف الالتزام ${commitmentName} بنجاح`);
    }
}


function markAsPaid(id) {
    const commitment = commitmentsData.find(c => c.id === id);
    if (commitment) {
        commitment.paidThisMonth = true;
        renderCommitmentsTable();
        showNotification(`تم وضع علامة دفع لـ ${commitment.name}`);
    }
}


function markAsUnpaid(id) {
    const commitment = commitmentsData.find(c => c.id === id);
    if (commitment) {
        commitment.paidThisMonth = false;
        renderCommitmentsTable();
        showNotification(`تم إلغاء علامة دفع لـ ${commitment.name}`);
    }
}


function getDueThisMonth() {
    const today = new Date();
    const currentDay = today.getDate();
    
    return commitmentsData.filter(commitment => {
        
        if (commitment.status !== 'active') return false;
        
        
        if (commitment.paidThisMonth) return false;
        
        const startDate = new Date(commitment.startDate);
        if (startDate > today) return false;
        
        
        if (commitment.endDate) {
            const endDate = new Date(commitment.endDate);
            if (endDate < today) return false;
        }
        
        
        const daysUntilPayment = commitment.paymentDay - currentDay;
        return daysUntilPayment >= 0 && daysUntilPayment <= 3;
    });
}


function checkDueCommitments() {
    const dueCommitments = getDueThisMonth();
    
    if (dueCommitments.length > 0) {
        const totalAmount = dueCommitments.reduce((sum, c) => sum + c.amount, 0);
        
        setTimeout(() => {
            showNotification(
                `لديك ${dueCommitments.length} التزامات مستحقة خلال 3 أيام: ${formatCurrency(totalAmount)}`,
                'warning'
            );
        }, 2000);
    }
}

function exportCommitmentsData() {
    const dataStr = JSON.stringify(commitmentsData, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `commitments-data-${new Date().toISOString().split('T')[0]}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    document.body.appendChild(linkElement);
    linkElement.click();
    document.body.removeChild(linkElement);
    
    showNotification('تم تصدير بيانات الالتزامات بنجاح');
}


function getCommitmentTypeName(type) {
    const types = {
        'monthly': 'شهري',
        'yearly': 'سنوي',
        'debt': 'دين',
        'loan': 'قرض',
        'deduction': 'خصم'
    };
    return types[type] || type;
}

function getStatusText(status) {
    const statuses = {
        'active': '<span class="badge badge-success">نشط</span>',
        'pending': '<span class="badge badge-warning">معلق</span>',
        'completed': '<span class="badge badge-primary">مكتمل</span>',
        'cancelled': '<span class="badge badge-danger">ملغي</span>'
    };
    return statuses[status] || status;
}

function formatCurrency(amount, currency = 'دينار') {
    const num = parseFloat(amount) || 0;
    return `${num.toLocaleString('ar-EG')} ${currency}`;
}

function formatDate(date) {
    if (!date) return '';
    return new Date(date).toLocaleDateString('ar-EG');
}


function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
}

function showNotification(message, type = 'success') {
    const notification = document.getElementById('successNotification');
    const messageElement = document.getElementById('notificationMessage');
    
    if (!notification || !messageElement) return;
    
    messageElement.textContent = message;
    notification.className = 'notification';
    
    if (type === 'error') {
        notification.classList.add('error');
    } else if (type === 'warning') {
        notification.classList.add('warning');
    }
    
    notification.classList.add('show');
    
    setTimeout(() => {
        notification.classList.remove('show');
    }, 3000);
}


document.addEventListener('DOMContentLoaded', function() {
    
    if (document.querySelector('.commitment-card, #commitmentsTableBody, #addCommitmentBtn')) {
        initCommitmentsManagement();
    }
    
    
    setupGeneralEventListeners();
});


function setupGeneralEventListeners() {
    
    const dateElement = document.getElementById('current-date');
    if (dateElement) {
        const now = new Date();
        dateElement.textContent = now.toLocaleDateString('ar-EG', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
    }
    
    
    const toggleSidebarBtn = document.getElementById('toggleSidebarBtn');
    if (toggleSidebarBtn) {
        toggleSidebarBtn.addEventListener('click', toggleSidebar);
    }
    
    
    const floatingAddBtn = document.getElementById('floatingAddBtn');
    if (floatingAddBtn) {
        floatingAddBtn.addEventListener('click', function() {
            
            const path = window.location.pathname;
            if (path.includes('commitments')) {
                openAddCommitmentModal();
            } else if (path.includes('clients')) {
                openAddClientModal();
            }
        });
    }
}

function toggleSidebar() {
    if (window.innerWidth > 992) {
        document.body.classList.toggle('sidebar-collapsed');
    } else {
        document.body.classList.toggle('sidebar-open');
    }
}


function openAddClientModal() {
    const modal = document.getElementById('addClientModal');
    if (modal) {
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }
}

function closeAddClientModal() {
    const modal = document.getElementById('addClientModal');
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
}