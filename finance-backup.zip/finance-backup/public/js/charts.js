let budgetChart = null;
let revenueExpenseChart = null;
let salaryChart = null;


function initCharts() {
    
    const budgetCtx = document.getElementById('budgetChart');
    if (budgetCtx) {
        if (budgetChart instanceof Chart) budgetChart.destroy();
        budgetChart = new Chart(budgetCtx, {
            type: 'doughnut',
            data: {
                labels: ['الرواتب', 'المصروفات التشغيلية', 'التسويق والإعلان', 'الموجودات والمعدات', 'مصاريف أخرى'],
                datasets: [{
                    data: [7800, 4750, 2850, 2300, 1500],
                    backgroundColor: ['#3498db', '#2ecc71', '#e74c3c', '#f39c12', '#9b59b6'],
                    borderWidth: 2,
                    borderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: 'bottom', rtl: true }
                }
            }
        });
    }

    
    const revenueCtx = document.getElementById('revenueExpenseChart');
    if (revenueCtx) {
        if (revenueExpenseChart instanceof Chart) revenueExpenseChart.destroy();
        revenueExpenseChart = new Chart(revenueCtx, {
            type: 'line',
            data: {
                labels: ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'],
                datasets: [
                    {
                        label: 'الإيرادات',
                        data: [2500, 2800, 3000, 3200, 2900, 3100, 3400, 3600, 3300, 3500, 3700, 3800],
                        borderColor: '#2ecc71',
                        backgroundColor: 'rgba(46,204,113,0.1)',
                        fill: true
                    },
                    {
                        label: 'المصروفات',
                        data: [1400, 1500, 1600, 1700, 1550, 1650, 1800, 1900, 1750, 1850, 1950, 2000],
                        borderColor: '#e74c3c',
                        backgroundColor: 'rgba(231,76,60,0.1)',
                        fill: true
                    }
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: 'top', rtl: true }
                }
            }
        });
    }

    
    const salaryCtx = document.getElementById('salaryChart');
    if (salaryCtx) {
        if (salaryChart instanceof Chart) salaryChart.destroy();
        salaryChart = new Chart(salaryCtx, {
            type: 'bar',
            data: {
                labels: ['أحمد محمد', 'سارة خالد', 'محمد علي', 'فاطمة حسين', 'خالد وليد'],
                datasets: [
                    { label: 'الراتب الأساسي', data: [1200, 1500, 900, 800, 700], backgroundColor: '#3498db' },
                    { label: 'الحوافز', data: [150, 200, 100, 80, 50], backgroundColor: '#2ecc71' },
                    { label: 'صافي الراتب', data: [1300, 1625, 970, 855, 730], backgroundColor: '#f39c12' }
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: 'top', rtl: true }
                }
            }
        });
    }
}


function updateChartsWithData(data) {
    if (!data || !data.budget_data) return;

    const budgetValues = [
        data.budget_data.salaries || 7800,
        data.budget_data.operational || 4750,
        data.budget_data.marketing || 2850,
        data.budget_data.assets || 2300,
        data.budget_data.other || 1500
    ];

    if (budgetChart instanceof Chart) {
        budgetChart.data.datasets[0].data = budgetValues;
        budgetChart.update();
    }

    const monthlyRevenue = Math.round((data.revenue || 34500) / 12);
    const monthlyExpenses = Math.round((data.expenses || 18200) / 12);

    if (revenueExpenseChart instanceof Chart) {
        revenueExpenseChart.data.datasets[0].data = Array(12).fill(monthlyRevenue);
        revenueExpenseChart.data.datasets[1].data = Array(12).fill(monthlyExpenses);
        revenueExpenseChart.update();
    }
}

function destroyCharts() {
    if (budgetChart instanceof Chart) {
        budgetChart.destroy();
        budgetChart = null;
    }
    if (revenueExpenseChart instanceof Chart) {
        revenueExpenseChart.destroy();
        revenueExpenseChart = null;
    }
    if (salaryChart instanceof Chart) {
        salaryChart.destroy();
        salaryChart = null;
    }
}


document.addEventListener('DOMContentLoaded', initCharts);