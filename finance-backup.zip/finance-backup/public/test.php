<?php
echo "<h1 style='color: green;'>SUCCESS! PHP is working</h1>";
echo "<p>Server Time: " . date('Y-m-d H:i:s') . "</p>";
echo "<p>PHP Version: " . PHP_VERSION . "</p>";
echo "<p>Root Directory: " . dirname(__DIR__) . "</p>";

// Check critical files
$files = [
    "/vendor/autoload.php",
    "/vendor/codeigniter4/framework/system/Boot.php",
    "/app/Config/Paths.php",
    "/public/index.php"
];

echo "<h2>File Status:</h2>";
echo "<ul>";
foreach ($files as $file) {
    $fullPath = dirname(__DIR__) . $file;
    $exists = file_exists($fullPath);
    $color = $exists ? "green" : "red";
    $icon = $exists ? "?" : "?";
    echo "<li style='color: $color;'>$icon $file</li>";
}
echo "</ul>";

// Check BOM in Paths.php
$pathsFile = dirname(__DIR__) . "/app/Config/Paths.php";
if (file_exists($pathsFile)) {
    $bytes = file_get_contents($pathsFile, false, null, 0, 3);
    $hasBOM = ($bytes === "\xEF\xBB\xBF");
    echo "<p>Paths.php BOM: " . ($hasBOM ? "<span style='color: red;'>YES (BAD)</span>" : "<span style='color: green;'>NO (GOOD)</span>") . "</p>";
}
