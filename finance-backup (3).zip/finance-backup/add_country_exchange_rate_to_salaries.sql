USE `financial_system`;

ALTER TABLE `salaries` 
ADD COLUMN IF NOT EXISTS `country` varchar(100) DEFAULT NULL AFTER `position`;

ALTER TABLE `salaries` 
ADD COLUMN IF NOT EXISTS `exchange_rate` decimal(10,4) DEFAULT NULL AFTER `country`;

SELECT '✓ تم إضافة أعمدة country و exchange_rate بنجاح!' AS 'النتيجة';
