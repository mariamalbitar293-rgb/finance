<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, user-scalable=yes">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <title>نظام إدارة الحسابات المالية - <?= $this->renderSection('title') ?? 'لوحة التحكم' ?></title>
    
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <?php 
    
    try {
        $cssBase = base_url('css/');
        
        $cssBase = rtrim($cssBase, '/') . '/';
    } catch (Exception $e) {
        $cssBase = '/css/';
    }
    if (strpos($cssBase, '/') !== 0 && strpos($cssBase, 'http') !== 0) {
        $cssBase = '/' . ltrim($cssBase, '/');
    }
    ?>
    <link rel="stylesheet" href="<?= $cssBase ?>main.css?v=<?= time() ?>">
    <link rel="stylesheet" href="<?= $cssBase ?>sidebar.css?v=<?= time() ?>">
    <link rel="stylesheet" href="<?= $cssBase ?>style.css?v=<?= time() ?>">
    <link rel="stylesheet" href="<?= $cssBase ?>dashboard.css?v=<?= time() ?>">
    <link rel="stylesheet" href="<?= $cssBase ?>responsive.css?v=<?= time() ?>">
</head>
<body>
    
    <button class="menu-toggle" id="menuToggle" onclick="toggleSidebar()" aria-label="فتح القائمة">
        <i class="fas fa-bars"></i>
    </button>
    
    <div class="sidebar-overlay" id="sidebarOverlay" onclick="closeSidebar()"></div>
    
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <div class="logo-img">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div class="logo-text">
                    <h1>نظام المالية</h1>
                    <span>لوحة التحكم المتكاملة</span>
                </div>
            </div>
        </div>
        
        <div class="sidebar-menu">
            
            <a href="<?= site_url('dashboard/clients') ?>" class="menu-item <?= current_url(true)->getSegment(2) == 'clients' ? 'active' : '' ?>">
                <i class="fas fa-users"></i>
                <span>حسابات العملاء</span>
                
            </a>
            <?php if (session()->get('role') === 'admin'): ?>
            <a href="<?= site_url('dashboard/yearlyReports') ?>" class="menu-item <?= current_url(true)->getSegment(2) == 'yearlyReports' ? 'active' : '' ?>">
                <i class="fas fa-chart-bar"></i>
                <span>التقارير السنوية</span>
            </a>
            <?php endif; ?>
            <a href="<?= site_url('dashboard/salaries') ?>" class="menu-item <?= current_url(true)->getSegment(2) == 'salaries' ? 'active' : '' ?>">
                <i class="fas fa-file-invoice-dollar"></i>
                <span>تقارير الرواتب</span>
                
            </a>
            <a href="<?= site_url('dashboard/commitments') ?>" class="menu-item <?= current_url(true)->getSegment(2) == 'commitments' ? 'active' : '' ?>">
                <i class="fas fa-hand-holding-usd"></i>
                <span>الالتزامات الشهرية</span>
                
            </a>
            <a href="<?= site_url('dashboard/assets') ?>" class="menu-item <?= current_url(true)->getSegment(2) == 'assets' ? 'active' : '' ?>">
                <i class="fas fa-server"></i>
                <span>الأصول الثابتة</span>
                
            </a>
            <?php if (session()->get('role') === 'admin'): ?>
            <a href="<?= site_url('dashboard/monthlyReports') ?>" class="menu-item <?= current_url(true)->getSegment(2) == 'monthlyReports' ? 'active' : '' ?>">
                <i class="fas fa-chart-pie"></i>
                <span>التقارير الشهرية</span>
            </a>
            <?php endif; ?>
            
        </div>
        
        <div class="sidebar-footer">
            <div class="user-profile">
                <div class="user-avatar">
                    <?php 
                    $photoUrl = session()->get('photo_url');
                    if ($photoUrl && file_exists(ROOTPATH . 'public/' . $photoUrl)): 
                    ?>
                        <img src="<?= base_url($photoUrl) ?>" alt="صورة المستخدم" style="width: 100%; height: 100%; object-fit: cover; border-radius: 50%;">
                    <?php else: ?>
                        <i class="fas fa-user"></i>
                    <?php endif; ?>
                </div>
                <div class="user-info">
                    <h4><?= session()->get('full_name') ?: 'مدير النظام' ?></h4>
                    <span><?= session()->get('email') ?: 'Admin@finance.com' ?></span>
                </div>
            </div>
            <a href="<?= site_url('auth/logout') ?>" class="logout-btn" style="display: block; margin-top: 10px; padding: 10px; text-align: center; color: #e74c3c; text-decoration: none; border-top: 1px solid rgba(255,255,255,0.1);">
                <i class="fas fa-sign-out-alt"></i> تسجيل الخروج
            </a>
        </div>
        
        <button class="toggle-sidebar" id="toggleSidebarBtn">
            <i class="fas fa-chevron-left"></i>
        </button>
    </div>

    <div class="main-content" id="mainContent">
    
        <header class="header">
            <div class="header-left">
                <div class="page-title">
                    <h2><?= $this->renderSection('title') ?? 'لوحة التحكم' ?></h2>
                </div>
            </div>
            
            <div class="header-right">
                <div class="date-display">
                    <i class="far fa-calendar-alt"></i>
                    <span id="current-date"><?= date('Y-m-d') ?></span>
                </div>
                
                <div class="notifications">
                    <i class="fas fa-bell"></i>
                    <div class="notification-badge">3</div>
                </div>
                
                <div class="small-avatar">
                    <?php 
                    $photoUrl = session()->get('photo_url');
                    if ($photoUrl && file_exists(ROOTPATH . 'public/' . $photoUrl)): 
                    ?>
                        <img src="<?= base_url($photoUrl) ?>" alt="صورة المستخدم" style="width: 100%; height: 100%; object-fit: cover; border-radius: 50%;">
                    <?php else: ?>
                        <i class="fas fa-user"></i>
                    <?php endif; ?>
                </div>
            </div>
        </header>
        
        <div id="page-content">
            <?= $this->renderSection('content') ?>
        </div>
    </div>

    <button class="add-btn-large tooltip" id="floatingAddBtn" data-tooltip="إضافة عميل جديد">
        <i class="fas fa-plus"></i>
    </button>

    <div class="notification" id="successNotification">
        <i class="fas fa-check-circle"></i>
        <span id="notificationMessage">تمت العملية بنجاح!</span>
    </div>


    <div class="modal-overlay" id="addClientModal" style="display: none;">
        <div class="modal-container">
            <div class="modal-header">
                <h3><i class="fas fa-user-plus"></i> إضافة عميل جديد</h3>
                <button class="close-modal" onclick="closeModal('addClientModal')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div class="modal-body">
                <form id="addClientForm">
                    <input type="hidden" id="clientId" value="">
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="clientName"><i class="fas fa-user"></i> اسم العميل *</label>
                            <input type="text" id="clientName" placeholder="أدخل اسم العميل" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="clientPhone"><i class="fas fa-phone"></i> رقم الهاتف</label>
                            <input type="tel" id="clientPhone" placeholder="أدخل رقم الهاتف">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="principalAmount"><i class="fas fa-money-bill-wave"></i> المبلغ الأساسي *</label>
                            <input type="number" id="principalAmount" placeholder="أدخل المبلغ الأساسي" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="paidAmount"><i class="fas fa-hand-holding-usd"></i> المبلغ المدفوع</label>
                            <input type="number" id="paidAmount" placeholder="أدخل المبلغ المدفوع">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="clientStatus"><i class="fas fa-tag"></i> الحالة</label>
                            <select id="clientStatus">
                                <option value="partial">مسدد جزئياً</option>
                                <option value="paid">مسدد بالكامل</option>
                                <option value="pending">غير مسدد</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="monthlyPayment"><i class="fas fa-calendar-alt"></i> الدفعة الشهرية (دينار)</label>
                            <input type="number" id="monthlyPayment" placeholder="مثال: 100" min="0" step="0.01">
                        </div>
                        <div class="form-group">
                            <label for="installmentDuration"><i class="fas fa-clock"></i> مدة التقسيط (شهر)</label>
                            <input type="number" id="installmentDuration" placeholder="مثال: 6" min="1">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-bolt"></i> خيارات سريعة للتقسيط</label>
                        <div style="display: flex; gap: 10px; flex-wrap: wrap; margin-top: 10px;">
                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="setClientInstallmentPeriod(1)" style="flex: 1; min-width: 120px;">
                                <i class="fas fa-calendar-day"></i> شهر واحد
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="setClientInstallmentPeriod(3)" style="flex: 1; min-width: 120px;">
                                <i class="fas fa-calendar-alt"></i> 3 أشهر
                            </button>
                        </div>
                        <small style="color: #7f8c8d; margin-top: 5px; display: block;">
                            <i class="fas fa-info-circle"></i> سيتم حساب الدفعة الشهرية تلقائياً بناءً على المبلغ المتبقي
                        </small>
                    </div>
                    
                    <div class="form-group">
                        <label for="clientNotes"><i class="fas fa-sticky-note"></i> ملاحظات</label>
                        <textarea id="clientNotes" rows="3" placeholder="أدخل ملاحظات عن العميل..."></textarea>
                    </div>
                    
                    <div class="payment-progress">
                        <label>نسبة السداد:</label>
                        <div class="progress-bar-container">
                            <div class="progress-bar" id="paymentProgress"></div>
                        </div>
                        <span class="percentage" id="paymentPercentage">0%</span>
                    </div>
                    <div id="loanInfo" style="margin-top: 15px; padding: 15px; background: #f8f9fa; border-radius: 8px; display: none;">
                        <h4 style="margin-bottom: 10px; color: #333;"><i class="fas fa-info-circle"></i> معلومات القرض</h4>
                        <div id="remainingAmount" style="margin: 5px 0; color: #e74c3c; font-weight: bold;"></div>
                        <div id="monthsRemaining" style="margin: 5px 0; color: #3498db;"></div>
                        <div id="endDate" style="margin: 5px 0; color: #27ae60;"></div>
                    </div>
                </form>
            </div>
            
            <div class="modal-footer">
                <button class="btn btn-secondary" id="cancelAddClientBtn" onclick="closeModal('addClientModal')">
                    <i class="fas fa-times"></i> إلغاء
                </button>
                <button class="btn btn-primary" id="saveClientBtn">
                    <i class="fas fa-save"></i> حفظ العميل
                </button>
                <button class="btn btn-success" id="saveAndAddAnotherBtn">
                    <i class="fas fa-save"></i> حفظ وإضافة آخر
                </button>
            </div>
        </div>
    </div>

    
    <div class="modal-overlay" id="editClientModal" style="display: none;">
        
    </div>

    
    <script>
        const baseUrl = '<?= site_url() ?>';
        const csrfToken = '<?= csrf_hash() ?>';
        const currentPage = '<?= service('uri')->getSegment(2) ?? 'index' ?>';
    </script>

<script src="<?= base_url('js/main.js') ?>"></script>
<script src="<?= base_url('js/notifications.js') ?>"></script>

    <?= $this->renderSection('scripts') ?>
</body>
</html>