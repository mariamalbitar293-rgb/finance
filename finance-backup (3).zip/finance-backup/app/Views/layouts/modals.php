<div class="modal-overlay" id="addClientModal">
    
</div>

<div class="modal-overlay" id="addCommitmentModal">
    
</div>

<div class="modal-overlay" id="addAssetModal">
    
</div>

<div class="modal-overlay" id="addSalaryModal">
    
</div>
<script>

document.getElementById('closeModalBtn')?.addEventListener('click', () => closeModal('addClientModal'));
document.getElementById('cancelAddClientBtn')?.addEventListener('click', () => closeModal('addClientModal'));

document.getElementById('closeCommitmentModalBtn')?.addEventListener('click', () => closeModal('addCommitmentModal'));
document.getElementById('cancelAddCommitmentBtn')?.addEventListener('click', () => closeModal('addCommitmentModal'));

document.getElementById('closeAssetModalBtn')?.addEventListener('click', () => closeModal('addAssetModal'));
document.getElementById('cancelAddAssetBtn')?.addEventListener('click', () => closeModal('addAssetModal'));

document.getElementById('closeSalaryModalBtn')?.addEventListener('click', () => closeModal('addSalaryModal'));
document.getElementById('cancelAddSalaryBtn')?.addEventListener('click', () => closeModal('addSalaryModal'));


function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}


function openModal(modalId) {
    document.getElementById(modalId).style.display = 'flex';
}


function updatePaymentProgress() {
    const principal = parseFloat(document.getElementById('principalAmount')?.value) || 0;
    const paid = parseFloat(document.getElementById('paidAmount')?.value) || 0;
    
    if (principal > 0) {
        const percentage = Math.min(100, (paid / principal) * 100);
        const progressBar = document.getElementById('paymentProgress');
        const percentageText = document.getElementById('paymentPercentage');
        
        if (progressBar && percentageText) {
            progressBar.style.width = percentage + '%';
            percentageText.textContent = percentage.toFixed(1) + '%';
            
            if (percentage === 100) {
                progressBar.style.background = 'linear-gradient(90deg, var(--success-color), #27ae60)';
                percentageText.style.color = 'var(--success-color)';
            } else if (percentage > 0) {
                progressBar.style.background = 'linear-gradient(90deg, var(--warning-color), #e67e22)';
                percentageText.style.color = 'var(--warning-color)';
            } else {
                progressBar.style.background = 'linear-gradient(90deg, var(--primary-color), var(--secondary-color))';
                percentageText.style.color = 'var(--primary-color)';
            }
        }
    }
}


document.addEventListener('DOMContentLoaded', function() {
    
    if (document.getElementById('principalAmount') && document.getElementById('paidAmount')) {
        document.getElementById('principalAmount').addEventListener('input', updatePaymentProgress);
        document.getElementById('paidAmount').addEventListener('input', updatePaymentProgress);
        updatePaymentProgress();
    }
});
</script>