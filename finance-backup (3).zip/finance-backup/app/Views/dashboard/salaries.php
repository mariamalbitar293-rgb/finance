<?= $this->extend('layouts/main') ?>

<?= $this->section('title') ?>
تقارير الرواتب والمصروفات
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<?php $canViewFinancial = session()->get('role') === 'admin'; ?>

<div class="section-header">
    <h2><i class="fas fa-file-invoice-dollar"></i> تقارير الرواتب والمصروفات</h2>
    <div class="controls">
        <?php if ($canViewFinancial): ?>
        <button class="btn btn-success" id="addSalaryBtn">
            <i class="fas fa-user-plus"></i> إضافة راتب
        </button>
        <button class="btn btn-primary" id="exportSalaryBtn">
            <i class="fas fa-file-export"></i> تصدير البيانات
        </button>
        <?php endif; ?>
        <button class="btn btn-info" id="salaryChartBtn">
            <i class="fas fa-chart-bar"></i> عرض الرسوم البيانية
        </button>
    </div>
</div>


<div class="stats-cards">
    <div class="stat-card card-1">
        <div class="stat-info">
            <h3>إجمالي الرواتب الصافية</h3>
            <div class="value"><?= number_format($stats['total_net']) ?> <span style="font-size: 1rem;">دينار</span></div>
        </div>
        <div class="stat-icon"><i class="fas fa-money-check-alt"></i></div>
    </div>

    <div class="stat-card card-2">
        <div class="stat-info">
            <h3>متوسط الراتب</h3>
            <div class="value"><?= number_format($stats['avg_salary']) ?> <span style="font-size: 1rem;">دينار</span></div>
        </div>
        <div class="stat-icon"><i class="fas fa-chart-bar"></i></div>
    </div>

    <div class="stat-card card-3">
        <div class="stat-info">
            <h3>إجمالي الحوافز</h3>
            <div class="value"><?= number_format($stats['total_bonuses']) ?> <span style="font-size: 1rem;">دينار</span></div>
        </div>
        <div class="stat-icon"><i class="fas fa-award"></i></div>
    </div>

    <div class="stat-card card-4">
        <div class="stat-info">
            <h3>إجمالي الاستقطاعات</h3>
            <div class="value"><?= number_format($stats['total_deductions']) ?> <span style="font-size: 1rem;">دينار</span></div>
        </div>
        <div class="stat-icon"><i class="fas fa-percentage"></i></div>
    </div>
</div>


<div class="table-container" style="margin-bottom: 25px;">
    <div class="table-header">
        <div class="search-filter">
            <select class="filter-select" id="employeeFilter">
                <option value="all" <?= $selected_employee === 'all' ? 'selected' : '' ?>>جميع الموظفين</option>
                <?php 
                $employees = array_unique(array_column($salaries, 'employee_name'));
                foreach ($employees as $emp): 
                ?>
                    <option value="<?= esc($emp) ?>" <?= $selected_employee === $emp ? 'selected' : '' ?>>
                        <?= esc($emp) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <input type="month" class="search-box" id="salaryMonth" value="<?= $selected_month ?>">
            <button class="btn btn-success" id="searchSalariesBtn">
                <i class="fas fa-search"></i> بحث
            </button>
        </div>
    </div>
</div>


<div class="chart-card" id="chartSection" style="display: none; margin-bottom: 30px;">
    <h3><i class="fas fa-chart-bar"></i> توزيع الرواتب والحوافز</h3>
    <div class="chart-wrapper">
        <canvas id="salaryChart"></canvas>
    </div>
</div>

<div class="table-container">
    <div class="table-header">
        <h3 style="margin: 0;"><i class="fas fa-users"></i> قائمة الرواتب</h3>
    </div>
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>الصورة</th>
                    <th>اسم الموظف</th>
                    <th>المنصب</th>
                    <th>الدولة</th>
                    <?php if ($canViewFinancial): ?>
                    <th>الراتب الأساسي</th>
                    <th>الحوافز</th>
                    <th>الاستقطاعات</th>
                    <th>صافي الراتب</th>
                    <?php endif; ?>
                    <th>تاريخ الصرف</th>
                    <th>الحالة</th>
                    <?php if ($canViewFinancial): ?>
                    <th>الإجراءات</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($salaries)): ?>
                    <tr>
                        <td colspan="<?= $canViewFinancial ? '11' : '6' ?>" style="text-align:center;">لا توجد رواتب مسجلة لهذا الشهر</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($salaries as $salary): 
                        $country = isset($salary['country']) ? trim($salary['country']) : '';
                        $exchangeRate = isset($salary['exchange_rate']) ? floatval($salary['exchange_rate']) : null;
                        $netSalary = isset($salary['net_salary']) ? floatval($salary['net_salary']) : 0;
                        $salaryInEGP = null;
                        if ($country === 'مصر' && $exchangeRate && $exchangeRate > 0 && $netSalary > 0) {
                            $salaryInEGP = $netSalary / $exchangeRate;
                        }
                    ?>
                        <tr>
                            <td>
                                <?php 
                                $photoUrl = $salary['photo_url'] ?? null;
                                if ($photoUrl && file_exists(ROOTPATH . 'public/' . $photoUrl)): 
                                ?>
                                    <img src="<?= base_url($photoUrl) ?>" alt="<?= esc($salary['employee_name']) ?>" 
                                         style="width: 50px; height: 50px; border-radius: 50%; object-fit: cover; border: 2px solid #ddd;">
                                <?php else: ?>
                                    <div style="width: 50px; height: 50px; border-radius: 50%; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">
                                        <?= mb_substr($salary['employee_name'], 0, 1) ?>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td><strong><?= esc($salary['employee_name']) ?></strong></td>
                            <td><?= (!empty($salary['position']) && trim($salary['position']) !== '') ? esc($salary['position']) : '<span style="color: #95a5a6;">غير محدد</span>' ?></td>
                            <td>
                                <?php 
                                $countryValue = isset($salary['country']) ? trim($salary['country']) : '';
                                if (!empty($countryValue) && $countryValue !== ''): 
                                ?>
                                    <span style="display: flex; align-items: center; gap: 5px;">
                                        <i class="fas fa-globe" style="color: #3498db;"></i>
                                        <?= esc($countryValue) ?>
                                    </span>
                                    <?php if ($countryValue === 'مصر' && $salaryInEGP): ?>
                                        <br><small style="color: #27ae60; font-size: 0.85rem;">
                                            <i class="fas fa-exchange-alt"></i> 
                                            <?= number_format($salaryInEGP, 2) ?> جنيه مصري
                                        </small>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span style="color: #95a5a6;">غير محدد</span>
                                <?php endif; ?>
                            </td>
                            <?php if ($canViewFinancial): ?>
                            <td><?= number_format($salary['basic_salary'], 2) ?> دينار</td>
                            <td><?= number_format($salary['bonuses'] ?? 0, 2) ?> دينار</td>
                            <td><?= number_format($salary['deductions'] ?? 0, 2) ?> دينار</td>
                            <td>
                                <strong><?= number_format($netSalary, 2) ?> دينار</strong>
                                <?php if ($country === 'مصر' && $salaryInEGP): ?>
                                    <br><small style="color: #27ae60; font-weight: normal;">
                                        (<?= number_format($salaryInEGP, 2) ?> جنيه مصري)
                                    </small>
                                <?php endif; ?>
                            </td>
                            <?php endif; ?>
                            <td><?= date('Y-m-d', strtotime($salary['payment_date'])) ?></td>
                            <td>
                                <span class="status <?= $salary['status'] === 'paid' ? 'paid' : ($salary['status'] === 'overdue' ? 'overdue' : 'pending') ?>">
                                    <?= $salary['status'] === 'paid' ? 'مسدد' : ($salary['status'] === 'overdue' ? 'متأخر' : 'قيد الانتظار') ?>
                                </span>
                            </td>
                            <?php if ($canViewFinancial): ?>
                            <td>
                                <button class="btn-icon" onclick="editSalary(<?= $salary['id'] ?>)" title="تعديل">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="btn-icon" onclick="deleteSalary(<?= $salary['id'] ?>)" title="حذف" style="color: #e74c3c;">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php if ($canViewFinancial): ?>

<div class="modal-overlay" id="addSalaryModal" style="display: none;">
    <div class="modal-container">
        <div class="modal-header">
            <h3><i class="fas fa-user-plus"></i> <span id="salaryModalTitle">إضافة راتب جديد</span></h3>
            <button class="close-modal" onclick="closeSalaryModal()">
                <i class="fas fa-times"></i>
            </button>
        </div>
        
        <div class="modal-body">
            <form id="addSalaryForm">
                <input type="hidden" id="salaryId" value="">
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="employeeName"><i class="fas fa-user"></i> اسم الموظف *</label>
                        <input type="text" id="employeeName" placeholder="أدخل اسم الموظف" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="employeePosition"><i class="fas fa-briefcase"></i> المنصب</label>
                        <input type="text" id="employeePosition" placeholder="أدخل المنصب">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="employeeCountry"><i class="fas fa-globe"></i> الدولة</label>
                        <select id="employeeCountry" class="form-select" onchange="handleCountryChange()">
                            <option value="">اختر الدولة</option>
                            <option value="مصر">مصر</option>
                            <option value="الأردن">الأردن</option>
                        </select>
                    </div>
                    
                    <div class="form-group" id="exchangeRateGroup" style="display: none;">
                        <label for="exchangeRate"><i class="fas fa-exchange-alt"></i> سعر الصرف (دينار/جنيه مصري)</label>
                        <input type="number" id="exchangeRate" step="0.01" min="0" placeholder="مثال: 0.021" oninput="calculateSalaryInEGP()">
                        <small style="color: #7f8c8d; display: block; margin-top: 5px;">
                            <i class="fas fa-info-circle"></i> سيتم حساب الراتب بالجنيه المصري تلقائياً
                        </small>
                    </div>
                </div>
                
                <div class="form-group" id="salaryInEGPGroup" style="display: none; padding: 15px; background: #e8f5e9; border-radius: 8px; margin-bottom: 15px;">
                    <label style="font-weight: bold; color: #27ae60;">
                        <i class="fas fa-money-bill-wave"></i> الراتب بالجنيه المصري:
                    </label>
                    <div id="salaryInEGP" style="font-size: 1.2rem; color: #27ae60; font-weight: bold; margin-top: 5px;">
                        0.00 جنيه مصري
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="basicSalary"><i class="fas fa-money-bill-wave"></i> الراتب الأساسي *</label>
                        <input type="number" id="basicSalary" step="0.01" min="0" placeholder="0.00" required oninput="calculateNetSalary()">
                    </div>
                    
                    <div class="form-group">
                        <label for="bonuses"><i class="fas fa-gift"></i> الحوافز</label>
                        <input type="number" id="bonuses" step="0.01" min="0" placeholder="0.00" value="0" oninput="calculateNetSalary()">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="deductions"><i class="fas fa-minus-circle"></i> الاستقطاعات</label>
                        <input type="number" id="deductions" step="0.01" min="0" placeholder="0.00" value="0" oninput="calculateNetSalary()">
                    </div>
                    
                    <div class="form-group">
                        <label for="netSalary"><i class="fas fa-calculator"></i> صافي الراتب</label>
                        <input type="number" id="netSalary" step="0.01" readonly style="background: #f5f5f5; font-weight: bold;">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="paymentDate"><i class="fas fa-calendar"></i> تاريخ الصرف *</label>
                        <input type="date" id="paymentDate" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="salaryStatus"><i class="fas fa-check-circle"></i> الحالة</label>
                        <select id="salaryStatus" class="form-select">
                            <option value="pending">قيد الانتظار</option>
                            <option value="paid">مسدد</option>
                            <option value="overdue">متأخر</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="salaryNotes"><i class="fas fa-sticky-note"></i> ملاحظات</label>
                    <textarea id="salaryNotes" rows="3" placeholder="أدخل أي ملاحظات إضافية"></textarea>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeSalaryModal()">إلغاء</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> حفظ
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
const baseURL = '<?= base_url() ?>';

function calculateNetSalary() {
    const basic = parseFloat(document.getElementById('basicSalary')?.value) || 0;
    const bonuses = parseFloat(document.getElementById('bonuses')?.value) || 0;
    const deductions = parseFloat(document.getElementById('deductions')?.value) || 0;
    const net = basic + bonuses - deductions;
    const netInput = document.getElementById('netSalary');
    if (netInput) {
        netInput.value = net.toFixed(2);
    }
    calculateSalaryInEGP();
}

function handleCountryChange() {
    const country = document.getElementById('employeeCountry')?.value;
    const exchangeRateGroup = document.getElementById('exchangeRateGroup');
    const salaryInEGPGroup = document.getElementById('salaryInEGPGroup');
    
    if (country === 'مصر') {
        if (exchangeRateGroup) exchangeRateGroup.style.display = 'block';
        if (salaryInEGPGroup) salaryInEGPGroup.style.display = 'block';
        calculateSalaryInEGP();
    } else {
        if (exchangeRateGroup) exchangeRateGroup.style.display = 'none';
        if (salaryInEGPGroup) salaryInEGPGroup.style.display = 'none';
        document.getElementById('exchangeRate').value = '';
    }
}

function calculateSalaryInEGP() {
    const country = document.getElementById('employeeCountry')?.value;
    const salaryInEGPGroup = document.getElementById('salaryInEGPGroup');
    const salaryInEGP = document.getElementById('salaryInEGP');
    
    if (country !== 'مصر' || !salaryInEGPGroup || !salaryInEGP) {
        return;
    }
    
    const netSalary = parseFloat(document.getElementById('netSalary')?.value) || 0;
    const exchangeRate = parseFloat(document.getElementById('exchangeRate')?.value) || 0;
    
    if (exchangeRate > 0 && netSalary > 0) {
        const salaryEGP = netSalary / exchangeRate;
        salaryInEGP.textContent = salaryEGP.toLocaleString('ar-SA', {minimumFractionDigits: 2, maximumFractionDigits: 2}) + ' جنيه مصري';
    } else {
        salaryInEGP.textContent = '0.00 جنيه مصري';
    }
}

function openSalaryModal(editId = null) {
    console.log('=== فتح نموذج الراتب ===');
    console.log('editId:', editId);
    
    const modal = document.getElementById('addSalaryModal');
    const form = document.getElementById('addSalaryForm');
    const title = document.getElementById('salaryModalTitle');
    
    if (!modal || !form) {
        console.error('النموذج غير موجود!');
        alert('خطأ: النموذج غير موجود');
        return;
    }
    
    form.reset();
    document.getElementById('salaryId').value = editId || '';
    title.textContent = editId ? 'تعديل راتب' : 'إضافة راتب جديد';
    
    console.log('النموذج تم فتحه بنجاح');
    
    if (editId) {
        fetch(`${baseURL}/api/salaries/${editId}`)
            .then(res => res.json())
            .then(data => {
                document.getElementById('employeeName').value = data.employee_name || '';
                document.getElementById('employeePosition').value = data.position || '';
                document.getElementById('employeeCountry').value = data.country || '';
                document.getElementById('exchangeRate').value = data.exchange_rate || '';
                document.getElementById('basicSalary').value = data.basic_salary || '';
                document.getElementById('bonuses').value = data.bonuses || 0;
                document.getElementById('deductions').value = data.deductions || 0;
                document.getElementById('paymentDate').value = data.payment_date || '';
                document.getElementById('salaryStatus').value = data.status || 'pending';
                document.getElementById('salaryNotes').value = data.notes || '';
                handleCountryChange();
                calculateNetSalary();
            })
            .catch(err => {
                console.error('Error loading salary:', err);
                alert('فشل في تحميل بيانات الراتب');
            });
    } else {
        document.getElementById('paymentDate').valueAsDate = new Date();
        calculateNetSalary();
    }
    
    modal.style.display = 'flex';
    document.getElementById('employeeName').focus();
}

function closeSalaryModal() {
    document.getElementById('addSalaryModal').style.display = 'none';
    document.getElementById('addSalaryForm').reset();
}

function editSalary(id) {
    openSalaryModal(id);
}

async function deleteSalary(id) {
    if (!confirm('هل أنت متأكد من حذف هذا الراتب؟')) {
        return;
    }
    
    try {
        const response = await fetch(`${baseURL}/api/salaries/${id}`, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' }
        });
        
        if (response.ok) {
            alert('تم حذف الراتب بنجاح');
            location.reload();
        } else {
            const result = await response.json();
            alert('فشل الحذف: ' + (result.message || 'خطأ في الخادم'));
        }
    } catch (error) {
        console.error('Error deleting salary:', error);
        alert('فشل الاتصال بالخادم');
    }
}

document.addEventListener('DOMContentLoaded', function() {
    const salaries = <?= json_encode($salaries) ?>;

    
    const labels = salaries.map(s => s.employee_name);
    const basic = salaries.map(s => s.basic_salary);
    const bonuses = salaries.map(s => s.bonuses || 0);
    const net = salaries.map(s => s.net_salary);

    new Chart(document.getElementById('salaryChart'), {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [
                { label: 'الراتب الأساسي', data: basic, backgroundColor: '#3498db' },
                { label: 'الحوافز', data: bonuses, backgroundColor: '#2ecc71' },
                { label: 'صافي الراتب', data: net, backgroundColor: '#f39c12' }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'top', rtl: true }
            },
            scales: {
                y: { beginAtZero: true }
            }
        }
    });

    
    document.getElementById('salaryChartBtn').addEventListener('click', function() {
        const section = document.getElementById('chartSection');
        section.style.display = section.style.display === 'none' ? 'block' : 'none';
        this.innerHTML = section.style.display === 'block' 
            ? '<i class="fas fa-chart-bar"></i> إخفاء الرسم البياني' 
            : '<i class="fas fa-chart-bar"></i> عرض الرسوم البيانية';
    });

    
    document.getElementById('searchSalariesBtn').addEventListener('click', function() {
        const month = document.getElementById('salaryMonth').value;
        const employee = document.getElementById('employeeFilter').value;
        
        let url = '<?= site_url('dashboard/salaries') ?>';
        let params = new URLSearchParams();
        if (month) params.append('month', month);
        if (employee && employee !== 'all') params.append('employee', employee);
        
        window.location.href = url + '?' + params.toString();
    });

    
    document.getElementById('exportSalaryBtn').addEventListener('click', function() {
        alert('تم تصدير بيانات الرواتب بنجاح!\n(سيتم تطوير تصدير Excel/PDF قريبًا)');
    });
    
    document.getElementById('addSalaryBtn').addEventListener('click', function() {
        openSalaryModal();
    });
    
    document.getElementById('addSalaryForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const id = document.getElementById('salaryId').value;
        const positionValue = document.getElementById('employeePosition').value.trim();
        const countryValue = document.getElementById('employeeCountry').value;
        const exchangeRateValue = document.getElementById('exchangeRate').value;
        
        const data = {
            employee_name: document.getElementById('employeeName').value.trim(),
            position: positionValue || '',
            country: countryValue || '',
            exchange_rate: countryValue === 'مصر' && exchangeRateValue !== '' 
                ? (parseFloat(exchangeRateValue) || null) 
                : null,
            basic_salary: parseFloat(document.getElementById('basicSalary').value),
            bonuses: parseFloat(document.getElementById('bonuses').value) || 0,
            deductions: parseFloat(document.getElementById('deductions').value) || 0,
            payment_date: document.getElementById('paymentDate').value,
            status: document.getElementById('salaryStatus').value,
            notes: document.getElementById('salaryNotes').value.trim()
        };
        
        if (!data.employee_name || data.employee_name.trim() === '') {
            alert('اسم الموظف مطلوب');
            document.getElementById('employeeName').focus();
            return;
        }
        
        if (!data.basic_salary || parseFloat(data.basic_salary) <= 0) {
            alert('الراتب الأساسي مطلوب ويجب أن يكون أكبر من صفر');
            document.getElementById('basicSalary').focus();
            return;
        }
        
        if (!data.payment_date) {
            alert('تاريخ الصرف مطلوب');
            document.getElementById('paymentDate').focus();
            return;
        }
        
        const netSalary = parseFloat(document.getElementById('netSalary').value) || 0;
        if (netSalary !== (data.basic_salary + data.bonuses - data.deductions)) {
            data.net_salary = data.basic_salary + data.bonuses - data.deductions;
        }
        
        console.log('=== اختبار إرسال البيانات ===');
        console.log('البيانات المرسلة:', JSON.stringify(data, null, 2));
        console.log('position:', data.position, '| type:', typeof data.position);
        console.log('country:', data.country, '| type:', typeof data.country);
        console.log('exchange_rate:', data.exchange_rate, '| type:', typeof data.exchange_rate);
        
        try {
            const url = id ? `${baseURL}/api/salaries/${id}` : `${baseURL}/api/salaries`;
            const method = id ? 'PUT' : 'POST';
            
            console.log('URL:', url);
            console.log('Method:', method);
            
            const response = await fetch(url, {
                method: method,
                headers: { 
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify(data)
            });
            
            const result = await response.json();
            
            console.log('=== اختبار الاستجابة من الخادم ===');
            console.log('response.ok:', response.ok);
            console.log('response.status:', response.status);
            console.log('result:', JSON.stringify(result, null, 2));
            
            if (result.data) {
                console.log('البيانات المحفوظة:', JSON.stringify(result.data, null, 2));
                console.log('position في الاستجابة:', result.data.position, '| type:', typeof result.data.position);
                console.log('country في الاستجابة:', result.data.country, '| type:', typeof result.data.country);
            }
            
            if (result.debug) {
                console.log('=== معلومات التصحيح ===');
                console.log('received_position:', result.debug.received_position);
                console.log('received_country:', result.debug.received_country);
                console.log('salaryData_position:', result.debug.salaryData_position);
                console.log('salaryData_country:', result.debug.salaryData_country);
                console.log('saved_position:', result.debug.saved_position);
                console.log('saved_country:', result.debug.saved_country);
            }
            
            if (response.ok && (result.success === true || result.success === undefined)) {
                alert(result.message || (id ? 'تم تحديث الراتب بنجاح' : 'تم إضافة الراتب بنجاح'));
                closeSalaryModal();
                location.reload();
            } else {
                const errorMsg = result.message || result.errors || 'فشل الحفظ';
                alert('فشل الحفظ: ' + errorMsg);
                console.error('Error saving salary:', result);
            }
        } catch (error) {
            console.error('Error saving salary:', error);
            alert('فشل الاتصال بالخادم. يرجى المحاولة مرة أخرى.');
        }
    });
});
</script>

<?= $this->endSection() ?>