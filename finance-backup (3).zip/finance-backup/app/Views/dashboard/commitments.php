<?= $this->extend('layouts/main') ?>

<?= $this->section('title') ?>
🔄 الالتزامات والمدفوعات الشهرية
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<link rel="stylesheet" href="<?= base_url('css/commitments.css') ?>">

<div class="section-header">
    <h2>🔄 الالتزامات والمدفوعات الشهرية</h2>
    <div class="controls">
        <button class="btn btn-primary" id="addCommitmentBtn">
            <i class="fas fa-plus-circle"></i> إضافة التزام جديد
        </button>
        <button class="btn btn-secondary" onclick="window.print()">
            <i class="fas fa-print"></i> طباعة
        </button>
        <button class="btn btn-success" id="exportBtn">
            <i class="fas fa-file-excel"></i> تصدير Excel
        </button>
    </div>
</div>

<div class="search-sort-bar">
    <div class="search-box">
        <input type="text" id="searchInput" placeholder="🔍 ابحث عن التزام بالاسم أو المستلم...">
        <i class="fas fa-search"></i>
    </div>
    
    <select class="sort-select" id="sortSelect">
        <option value="name">الاسم (أ-ي)</option>
        <option value="amount_desc">المبلغ (من الأعلى)</option>
        <option value="amount_asc">المبلغ (من الأقل)</option>
        <option value="payment_day">يوم الدفع</option>
        <option value="status">الحالة</option>
    </select>
    
    <select class="sort-select" id="typeFilter">
        <option value="all">جميع الأنواع</option>
        <option value="monthly">التزامات شهرية</option>
        <option value="debt">ديون</option>
        <option value="deduction">خصومات</option>
    </select>
</div>

<div class="filter-tabs">
    <button class="filter-tab active" data-filter="all">
        <i class="fas fa-layer-group"></i> جميع الالتزامات
    </button>
    <button class="filter-tab" data-filter="active">
        <i class="fas fa-play-circle"></i> نشطة
    </button>
    <button class="filter-tab" data-filter="pending">
        <i class="fas fa-clock"></i> قيد الانتظار
    </button>
    <button class="filter-tab" data-filter="overdue">
        <i class="fas fa-exclamation-triangle"></i> متأخرة
    </button>
    <button class="filter-tab" data-filter="completed">
        <i class="fas fa-check-circle"></i> مكتملة
    </button>
</div>

<div class="stats-cards">
    <div class="stat-card card-1">
        <div class="stat-info">
            <h3>💰 إجمالي الالتزامات الشهرية</h3>
            <div class="value"><?= number_format($stats['total_monthly'] ?? 0) ?> <span>دينار</span></div>
            <div class="stat-change">
                <i class="fas fa-calendar-check"></i> هذا الشهر
            </div>
        </div>
        <div class="stat-icon"><i class="fas fa-calendar-check"></i></div>
    </div>

    <div class="stat-card card-2">
        <div class="stat-info">
            <h3>📋 الديون المتبقية</h3>
            <div class="value"><?= number_format($stats['total_debts'] ?? 0) ?> <span>دينار</span></div>
            <div class="stat-change">
                <i class="fas fa-percentage"></i> 
                <?php 
                    $debt_progress = 0;
                    if (isset($stats['total_debts_amount']) && $stats['total_debts_amount'] > 0 && isset($stats['total_paid_debts'])) {
                        $debt_progress = round(($stats['total_paid_debts'] / $stats['total_debts_amount']) * 100, 1);
                    }
                    echo $debt_progress . '% مكتمل';
                ?>
            </div>
        </div>
        <div class="stat-icon"><i class="fas fa-file-invoice-dollar"></i></div>
    </div>

    <div class="stat-card card-3">
        <div class="stat-info">
            <h3>💸 إجمالي الخصومات</h3>
            <div class="value"><?= number_format($stats['total_deductions'] ?? 0) ?> <span>دينار</span></div>
            <div class="stat-change">
                <i class="fas fa-minus-circle"></i> خصومات شهرية
            </div>
        </div>
        <div class="stat-icon"><i class="fas fa-hand-holding-usd"></i></div>
    </div>

    <div class="stat-card card-4">
        <div class="stat-info">
            <h3>📊 عدد الالتزامات النشطة</h3>
            <div class="value"><?= $stats['active_count'] ?? 0 ?></div>
            <div class="stat-change">
                <i class="fas fa-list-ul"></i> 
                <?php 
                    $total_count = count($commitments ?? []);
                    echo $total_count . ' إجمالي الالتزامات';
                ?>
            </div>
        </div>
        <div class="stat-icon"><i class="fas fa-chart-bar"></i></div>
    </div>
</div>

<div id="commitmentsList">
    <?php if (empty($commitments)): ?>
        <div class="empty-state">
            <div class="empty-icon">
                <i class="fas fa-file-invoice-dollar fa-4x"></i>
            </div>
            <h3>لا توجد التزامات مسجلة</h3>
            <p>ابدأ بإضافة أول التزام لك لإدارة مدفوعاتك الشهرية</p>
            <button class="btn btn-primary" id="addFirstCommitment">
                <i class="fas fa-plus-circle"></i> إضافة التزام جديد
            </button>
        </div>
    <?php else: ?>
        <?php foreach ($commitments as $c): 
            $remaining = $c['amount'] - ($c['paid_amount'] ?? 0);
            $progressPercent = 0;
            if ($c['amount'] > 0) {
                $paid_amount = $c['paid_amount'] ?? 0;
                $progressPercent = round(($paid_amount / $c['amount']) * 100);
            }
            
            $remainingMonths = 0;
            if (isset($c['monthly_payment']) && $c['monthly_payment'] > 0) {
                $remainingMonths = ceil($remaining / $c['monthly_payment']);
            }
            
            $icon = 'fa-calendar-alt';
            $typeText = 'شهري';
            if ($c['type'] === 'debt') {
                $icon = 'fa-file-invoice-dollar';
                $typeText = 'دين';
            } elseif ($c['type'] === 'deduction') {
                $icon = 'fa-minus-circle';
                $typeText = 'خصم';
            }
            
            $statusClass = 'status-pending';
            $statusText = 'قيد الانتظار';
            
            if ($c['status'] === 'completed' || $remaining <= 0) {
                $statusClass = 'status-completed';
                $statusText = 'مكتمل';
            } elseif ($c['status'] === 'overdue') {
                $statusClass = 'status-overdue';
                $statusText = 'متأخر';
            } elseif ($c['status'] === 'paid') {
                $statusClass = 'status-paid';
                $statusText = 'مدفوع';
            } elseif ($c['status'] === 'active') {
                $statusClass = 'status-active';
                $statusText = 'نشط';
            }
            
            $canPayAdvance = ($remaining > 0 && in_array($c['status'], ['active', 'pending']));
        ?>
            <div class="commitment-card card-<?= $c['type'] ?>" 
                 data-type="<?= $c['type'] ?>" 
                 data-status="<?= $c['status'] ?>"
                 data-name="<?= esc($c['name']) ?>"
                 data-recipient="<?= esc($c['recipient'] ?? '') ?>"
                 data-payment-day="<?= $c['payment_day'] ?>"
                 data-amount="<?= $c['amount'] ?>">
                
                <div class="card-header">
                    <div class="card-title">
                        <div class="card-icon icon-<?= $c['type'] ?>">
                            <?php if (!empty($c['image_url'])): ?>
                                <img src="<?= base_url($c['image_url']) ?>" alt="<?= esc($c['name']) ?>" style="width: 60px; height: 60px; border-radius: 50%; object-fit: cover; border: 2px solid #fff;">
                            <?php else: ?>
                                <i class="fas <?= $icon ?>"></i>
                            <?php endif; ?>
                        </div>
                        <div class="card-info">
                            <h3><?= esc($c['name']) ?></h3>
                            <div class="recipient">
                                <i class="fas fa-user"></i> <?= esc($c['recipient'] ?? 'غير محدد') ?>
                                <?php if (!empty($c['category'])): ?>
                                    <span style="margin: 0 10px; padding: 3px 10px; background: #e3f2fd; border-radius: 12px; font-size: 0.85rem; color: #1976d2;">
                                        <i class="fas fa-tag"></i> <?= esc($c['category']) ?>
                                    </span>
                                <?php endif; ?>
                                <span class="payment-status <?= $statusClass ?>">
                                    <i class="fas fa-circle"></i> <?= $statusText ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <?php if (!empty($c['image_url'])): ?>
                <div style="margin: 15px 0; text-align: center;">
                    <img src="<?= base_url($c['image_url']) ?>" alt="<?= esc($c['name']) ?>" style="max-width: 100%; max-height: 300px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                </div>
                <?php endif; ?>
                
                <div class="card-details">
                    <div class="detail-item">
                        <span class="detail-label">💵 المبلغ الإجمالي</span>
                        <span class="detail-value">
                            <span class="currency">دينار</span>
                            <?= number_format($c['amount']) ?>
                        </span>
                    </div>
                    
                    <?php if (!empty($c['annual_amount'])): ?>
                    <div class="detail-item">
                        <span class="detail-label">📅 المبلغ السنوي</span>
                        <span class="detail-value" style="color: #3498db;">
                            <span class="currency">دينار</span>
                            <?= number_format($c['annual_amount']) ?>
                        </span>
                    </div>
                    <?php endif; ?>
                    
                    <?php if (isset($c['received_amount']) && $c['received_amount'] > 0): ?>
                    <div class="detail-item">
                        <span class="detail-label">✅ المبلغ الواصل</span>
                        <span class="detail-value" style="color: #27ae60;">
                            <span class="currency">دينار</span>
                            <?= number_format($c['received_amount']) ?>
                        </span>
                    </div>
                    <?php endif; ?>
                    
                    <div class="detail-item">
                        <span class="detail-label">📅 يوم الدفع</span>
                        <span class="detail-value">
                            <i class="fas fa-calendar-day"></i> يوم <?= $c['payment_day'] ?>
                        </span>
                    </div>
                    
                    <div class="detail-item">
                        <span class="detail-label">💰 المدفوع</span>
                        <span class="detail-value" style="color: #27ae60;">
                            <span class="currency">دينار</span>
                            <?= number_format($c['paid_amount'] ?? 0) ?>
                        </span>
                    </div>
                    
                    <div class="detail-item">
                        <span class="detail-label">📊 المتبقي</span>
                        <span class="detail-value" style="color: #e74c3c;">
                            <span class="currency">دينار</span>
                            <?= number_format($remaining) ?>
                        </span>
                    </div>
                </div>
                
                <?php if ($c['amount'] > 0): ?>
                    <div class="debt-progress-container">
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: <?= $progressPercent ?>%"></div>
                        </div>
                        <div class="progress-info">
                            <span>تم السداد: <?= $progressPercent ?>%</span>
                            <?php if ($remainingMonths > 0): ?>
                                <span>متبقي: <?= $remainingMonths ?> شهر</span>
                            <?php elseif ($remaining <= 0): ?>
                                <span>مكتمل السداد</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <?php if (isset($c['monthly_payment']) && $c['monthly_payment'] > 0): ?>
                        <div class="detail-item" style="margin-top: 10px; background: #e8f4fd;">
                            <span class="detail-label">📝 الدفعة الشهرية</span>
                            <span class="detail-value">
                                <span class="currency">دينار</span>
                                <?= number_format($c['monthly_payment']) ?>
                                <small style="font-size: 0.9rem; color: #7f8c8d;">/شهر</small>
                            </span>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
                
                <?php if (isset($c['start_date'])): ?>
                    <div class="card-details" style="margin-top: 15px;">
                        <div class="detail-item">
                            <span class="detail-label">📅 تاريخ البدء</span>
                            <span class="detail-value">
                                <?= date('Y-m-d', strtotime($c['start_date'])) ?>
                            </span>
                        </div>
                        
                        <?php if (isset($c['end_date']) && $c['end_date']): ?>
                            <div class="detail-item">
                                <span class="detail-label">🏁 تاريخ الانتهاء</span>
                                <span class="detail-value">
                                    <?= date('Y-m-d', strtotime($c['end_date'])) ?>
                                </span>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                
                <div class="card-actions">
                    <?php if ($canPayAdvance): ?>
                        <button class="btn-action btn-pay" onclick="showAdvancePayment(<?= $c['id'] ?>, '<?= $c['type'] ?>')">
                            <i class="fas fa-money-check-alt"></i> دفعة مقدم
                        </button>
                    <?php endif; ?>
                    
                    <button class="btn-action btn-edit" onclick="editCommitment(<?= $c['id'] ?>)">
                        <i class="fas fa-edit"></i> تعديل
                    </button>
                    
                    <button class="btn-action btn-delete" onclick="deleteCommitment(<?= $c['id'] ?>)">
                        <i class="fas fa-trash-alt"></i> حذف
                    </button>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<div class="modal-overlay" id="commitmentModal" style="display: none;">
    <div class="modal-container">
        <div class="modal-header">
            <h3><i class="fas fa-hand-holding-usd"></i> <span id="modalTitle">إضافة التزام جديد</span></h3>
            <button class="close-modal" onclick="closeModal('commitmentModal')">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="modal-body">
            <form id="commitmentForm">
                <input type="hidden" id="commitmentId">
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="commitmentName"><i class="fas fa-tag"></i> اسم الالتزام *</label>
                        <input type="text" id="commitmentName" required placeholder="مثال: قسط السيارة">
                    </div>
                    <div class="form-group">
                        <label for="commitmentType"><i class="fas fa-list"></i> نوع الالتزام *</label>
                        <select id="commitmentType" required>
                            <option value="monthly">التزام شهري</option>
                            <option value="debt">دين/قرض</option>
                            <option value="deduction">خصم</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="commitmentCategory"><i class="fas fa-layer-group"></i> تصنيف الالتزام</label>
                        <select id="commitmentCategory">
                            <option value="">اختر التصنيف</option>
                            <option value="إنترنت">إنترنت</option>
                            <option value="كهرباء">كهرباء</option>
                            <option value="موظفين">موظفين</option>
                            <option value="إيجارات">إيجارات</option>
                            <option value="بنوك">بنوك</option>
                            <option value="أشخاص أخرى">أشخاص أخرى</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="recipient"><i class="fas fa-user-tie"></i> المستلم / الجهة</label>
                        <input type="text" id="recipient" placeholder="مثال: البنك الأهلي">
                    </div>
                    <div class="form-group">
                        <label for="paymentDay"><i class="fas fa-calendar-day"></i> يوم الدفع *</label>
                        <input type="number" id="paymentDay" min="1" max="31" required value="1">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="commitmentAmount"><i class="fas fa-money-bill-wave"></i> المبلغ الإجمالي (دينار) *</label>
                        <input type="number" id="commitmentAmount" min="0.01" step="0.01" required oninput="calculateMonthlyFromTotal()">
                    </div>
                    <div class="form-group">
                        <label for="annualAmount"><i class="fas fa-calendar-alt"></i> المبلغ السنوي (دينار)</label>
                        <input type="number" id="annualAmount" min="0" step="0.01" placeholder="مثال: 1200">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="receivedAmount"><i class="fas fa-hand-holding-usd"></i> المبلغ الواصل (دينار)</label>
                        <input type="number" id="receivedAmount" min="0" step="0.01" placeholder="المبلغ الذي وصل فعلياً" value="0">
                    </div>
                    <div class="form-group">
                        <label for="installmentMonths"><i class="fas fa-calendar-check"></i> عدد الأشهر للتقسيم</label>
                        <input type="number" id="installmentMonths" min="1" step="1" placeholder="مثال: 12" oninput="calculateMonthlyFromMonths()">
                        <small style="color: #7f8c8d; display: block; margin-top: 5px;">
                            <i class="fas fa-info-circle"></i> سيتم حساب الدفعة الشهرية تلقائياً
                        </small>
                    </div>
                </div>
                
                <div class="form-group" id="monthlyCalculationResult" style="display: none; padding: 15px; background: #e8f5e9; border-radius: 8px; margin-bottom: 15px;">
                    <label style="font-weight: bold; color: #27ae60;">
                        <i class="fas fa-calculator"></i> الدفعة الشهرية المحسوبة:
                    </label>
                    <div id="calculatedMonthlyAmount" style="font-size: 1.2rem; color: #27ae60; font-weight: bold; margin-top: 5px;">
                        0.00 دينار
                    </div>
                </div>
                
                <div id="advanceFields">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="paidAmount"><i class="fas fa-wallet"></i> المبلغ المدفوع مقدمًا (اختياري)</label>
                            <input type="number" id="paidAmount" min="0" step="0.01" value="0">
                        </div>
                        <div class="form-group">
                            <label for="monthlyPayment"><i class="fas fa-calculator"></i> الدفعة الشهرية (اختياري)</label>
                            <input type="number" id="monthlyPayment" min="0.01" step="0.01" placeholder="سيتم حسابها تلقائياً">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-clock"></i> خيارات الدفع المقدم (اختياري)</label>
                        <div style="display: flex; gap: 10px; flex-wrap: wrap; margin-top: 10px;">
                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="setAdvancePayment(0.25)">دفعة 25%</button>
                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="setAdvancePayment(0.5)">دفعة 50%</button>
                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="setAdvancePayment(0.75)">دفعة 75%</button>
                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="setAdvancePayment(1)">دفعة كاملة</button>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-clock"></i> مدة التقسيط (اختياري)</label>
                        <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="setInstallmentPeriod(3)">3 أشهر</button>
                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="setInstallmentPeriod(6)">6 أشهر</button>
                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="setInstallmentPeriod(12)">12 شهر</button>
                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="setInstallmentPeriod(24)">24 شهر</button>
                        </div>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="startDate"><i class="fas fa-play-circle"></i> تاريخ البدء *</label>
                        <input type="date" id="startDate" required>
                    </div>
                    <div class="form-group">
                        <label for="endDate"><i class="fas fa-stop-circle"></i> تاريخ الانتهاء (اختياري)</label>
                        <input type="date" id="endDate">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="loanStartDate"><i class="fas fa-calendar"></i> تاريخ بداية القرض</label>
                        <input type="date" id="loanStartDate">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="status"><i class="fas fa-circle"></i> الحالة</label>
                        <select id="status">
                            <option value="active">نشط</option>
                            <option value="pending">قيد الانتظار</option>
                            <option value="overdue">متأخر</option>
                            <option value="completed">مكتمل</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="notes"><i class="fas fa-sticky-note"></i> ملاحظات (اختياري)</label>
                    <textarea id="notes" rows="3" placeholder="أي ملاحظات إضافية..."></textarea>
                </div>
                
                <div class="form-group">
                    <label for="commitmentImage"><i class="fas fa-image"></i> صورة الالتزام (اختياري)</label>
                    <input type="file" id="commitmentImage" accept="image/*" onchange="previewCommitmentImage(this)">
                    <div id="imagePreview" style="margin-top: 10px; display: none;">
                        <img id="previewImg" src="" alt="معاينة الصورة" style="max-width: 200px; max-height: 200px; border-radius: 8px; border: 2px solid #ddd;">
                        <button type="button" onclick="removeCommitmentImage()" style="margin-top: 5px; padding: 5px 10px; background: #e74c3c; color: white; border: none; border-radius: 5px; cursor: pointer;">
                            <i class="fas fa-times"></i> إزالة الصورة
                        </button>
                    </div>
                    <small style="color: #7f8c8d; display: block; margin-top: 5px;">
                        <i class="fas fa-info-circle"></i> الحد الأقصى لحجم الصورة: 5 ميجابايت
                    </small>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('commitmentModal')">
                <i class="fas fa-times"></i> إلغاء
            </button>
            <button class="btn btn-primary" id="saveCommitmentBtn">
                <i class="fas fa-save"></i> حفظ الالتزام
            </button>
        </div>
    </div>
</div>

<div class="modal-overlay" id="advancePaymentModal" style="display: none;">
    <div class="modal-container">
        <div class="modal-header">
            <h3><i class="fas fa-money-check-alt"></i> الدفع المقدم</h3>
            <button class="close-modal" onclick="closeModal('advancePaymentModal')">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="modal-body">
            <div id="advancePaymentContent"></div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const today = new Date();
    document.getElementById('startDate').value = today.toISOString().split('T')[0];
    
    document.getElementById('addCommitmentBtn').addEventListener('click', openAddModal);
    document.getElementById('addFirstCommitment')?.addEventListener('click', openAddModal);
    
    document.getElementById('commitmentAmount').addEventListener('input', calculateMonthlyPayment);
    document.getElementById('paidAmount').addEventListener('input', calculateMonthlyPayment);
    
    document.querySelectorAll('.filter-tab').forEach(tab => {
        tab.addEventListener('click', function() {
            document.querySelectorAll('.filter-tab').forEach(t => {
                t.classList.remove('active');
            });
            this.classList.add('active');
            filterCommitments(this.dataset.filter);
        });
    });
    
    document.getElementById('typeFilter').addEventListener('change', function() {
        filterByType(this.value);
    });
    
    document.getElementById('searchInput').addEventListener('input', function() {
        const searchTerm = this.value.toLowerCase().trim();
        const commitments = document.querySelectorAll('.commitment-card');
        
        if (searchTerm === '') {
            commitments.forEach(card => card.style.display = 'block');
            return;
        }
        
        commitments.forEach(card => {
            const name = card.dataset.name.toLowerCase();
            const recipient = card.dataset.recipient.toLowerCase();
            
            if (name.includes(searchTerm) || recipient.includes(searchTerm)) {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
            }
        });
    });
    
    document.getElementById('sortSelect').addEventListener('change', function() {
        sortCommitments(this.value);
    });
    
    document.getElementById('exportBtn').addEventListener('click', async function() {
        try {
            const response = await fetch('<?= base_url('api/commitments/export') ?>');
            if (response.ok) {
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'التزامات_' + new Date().toISOString().split('T')[0] + '.xlsx';
                document.body.appendChild(a);
                a.click();
                a.remove();
                window.URL.revokeObjectURL(url);
            } else {
                showToast('حدث خطأ في التصدير', 'error');
            }
        } catch (error) {
            console.error('خطأ في التصدير:', error);
            showToast('حدث خطأ في الاتصال بالخادم', 'error');
        }
    });
    
    document.getElementById('saveCommitmentBtn').addEventListener('click', saveCommitment);
});

function openAddModal() {
    document.getElementById('modalTitle').textContent = 'إضافة التزام جديد';
    document.getElementById('commitmentForm').reset();
    
    document.getElementById('commitmentId').value = '';
    document.getElementById('commitmentName').value = '';
    document.getElementById('recipient').value = '';
    document.getElementById('commitmentAmount').value = '';
    document.getElementById('annualAmount').value = '';
    document.getElementById('receivedAmount').value = 0;
    document.getElementById('paymentDay').value = 1;
    document.getElementById('commitmentType').value = 'monthly';
    document.getElementById('commitmentCategory').value = '';
    document.getElementById('startDate').value = new Date().toISOString().split('T')[0];
    document.getElementById('endDate').value = '';
    document.getElementById('loanStartDate').value = '';
    document.getElementById('status').value = 'active';
    document.getElementById('notes').value = '';
    document.getElementById('paidAmount').value = 0;
    document.getElementById('monthlyPayment').value = '';
    document.getElementById('installmentMonths').value = '';
    document.getElementById('monthlyCalculationResult').style.display = 'none';
    document.getElementById('commitmentImage').value = '';
    document.getElementById('imagePreview').style.display = 'none';
    document.getElementById('previewImg').src = '';
    
    openModal('commitmentModal');
}

function calculateMonthlyPayment() {
    const amount = parseFloat(document.getElementById('commitmentAmount').value) || 0;
    const paid = parseFloat(document.getElementById('paidAmount').value) || 0;
    const remaining = amount - paid;
    
    const monthlyInput = document.getElementById('monthlyPayment');
    if (remaining > 0 && (!monthlyInput.value || parseFloat(monthlyInput.value) <= 0)) {
        const monthly = remaining / 12;
        monthlyInput.value = monthly.toFixed(2);
    }
}

function setAdvancePayment(percentage) {
    const amount = parseFloat(document.getElementById('commitmentAmount').value) || 0;
    const advanceAmount = amount * percentage;
    document.getElementById('paidAmount').value = advanceAmount.toFixed(2);
    calculateMonthlyPayment();
}

function setInstallmentPeriod(months) {
    const amount = parseFloat(document.getElementById('commitmentAmount').value) || 0;
    const paid = parseFloat(document.getElementById('paidAmount').value) || 0;
    const remaining = amount - paid;
    
    if (remaining > 0 && months > 0) {
        const monthlyPayment = remaining / months;
        document.getElementById('monthlyPayment').value = monthlyPayment.toFixed(2);
    }
}

function filterCommitments(filter) {
    const commitments = document.querySelectorAll('.commitment-card');
    
    commitments.forEach(card => {
        const status = card.dataset.status;
        let show = true;
        
        if (filter === 'active') show = status === 'active';
        else if (filter === 'pending') show = status === 'pending';
        else if (filter === 'overdue') show = status === 'overdue';
        else if (filter === 'completed') show = status === 'completed';
        
        card.style.display = show ? 'block' : 'none';
    });
}

function filterByType(type) {
    const commitments = document.querySelectorAll('.commitment-card');
    
    commitments.forEach(card => {
        if (type === 'all' || card.dataset.type === type) {
            card.style.display = 'block';
        } else {
            card.style.display = 'none';
        }
    });
}

function sortCommitments(sortBy) {
    const container = document.getElementById('commitmentsList');
    const commitments = Array.from(document.querySelectorAll('.commitment-card:not([style*="display: none"])'));
    
    commitments.sort((a, b) => {
        switch(sortBy) {
            case 'name':
                return a.dataset.name.localeCompare(b.dataset.name);
            case 'amount_desc':
                return parseFloat(b.dataset.amount) - parseFloat(a.dataset.amount);
            case 'amount_asc':
                return parseFloat(a.dataset.amount) - parseFloat(b.dataset.amount);
            case 'payment_day':
                return parseInt(a.dataset.paymentDay) - parseInt(b.dataset.paymentDay);
            case 'status':
                const statusOrder = { 'active': 1, 'pending': 2, 'overdue': 3, 'completed': 4 };
                return (statusOrder[a.dataset.status] || 5) - (statusOrder[b.dataset.status] || 5);
            default:
                return 0;
        }
    });
    
    commitments.forEach(card => container.appendChild(card));
}

async function editCommitment(id) {
    try {
        const response = await fetch(`<?= base_url('api/commitments/') ?>${id}`);
        if (!response.ok) {
            throw new Error('فشل في تحميل بيانات الالتزام');
        }
        
        const result = await response.json();
        
        let commitment;
        if (result.success && result.data) {
            commitment = result.data;
        } else if (result.id || result.name) {
            commitment = result;
        } else {
            throw new Error('بيانات الالتزام غير صحيحة');
        }
            
        document.getElementById('commitmentId').value = commitment.id || '';
            document.getElementById('modalTitle').textContent = 'تعديل الالتزام';
        
        document.getElementById('commitmentName').value = commitment.name || '';
        document.getElementById('recipient').value = commitment.recipient || '';
        document.getElementById('commitmentAmount').value = commitment.amount || 0;
        document.getElementById('annualAmount').value = commitment.annual_amount || '';
        document.getElementById('receivedAmount').value = commitment.received_amount || 0;
        document.getElementById('paymentDay').value = commitment.payment_day || 1;
        document.getElementById('commitmentType').value = commitment.type || 'monthly';
        document.getElementById('commitmentCategory').value = commitment.category || '';
            
            if (commitment.start_date) {
            const startDate = commitment.start_date.includes('T') 
                ? commitment.start_date.split('T')[0] 
                : commitment.start_date;
            document.getElementById('startDate').value = startDate;
        } else {
            document.getElementById('startDate').value = '';
            }
            
            if (commitment.end_date) {
            const endDate = commitment.end_date.includes('T') 
                ? commitment.end_date.split('T')[0] 
                : commitment.end_date;
            document.getElementById('endDate').value = endDate;
        } else {
            document.getElementById('endDate').value = '';
            }
            
            if (commitment.loan_start_date) {
            const loanStartDate = commitment.loan_start_date.includes('T') 
                ? commitment.loan_start_date.split('T')[0] 
                : commitment.loan_start_date;
            document.getElementById('loanStartDate').value = loanStartDate;
        } else {
            document.getElementById('loanStartDate').value = '';
            }
            
            document.getElementById('status').value = commitment.status || 'active';
            document.getElementById('notes').value = commitment.notes || '';
        
            document.getElementById('paidAmount').value = commitment.paid_amount || 0;
            document.getElementById('monthlyPayment').value = commitment.monthly_payment || '';
            
            const amount = parseFloat(commitment.amount || 0);
            const monthlyPayment = parseFloat(commitment.monthly_payment || 0);
            if (amount > 0 && monthlyPayment > 0) {
                const calculatedMonths = Math.ceil(amount / monthlyPayment);
                document.getElementById('installmentMonths').value = calculatedMonths;
                calculateMonthlyFromMonths();
            } else {
                document.getElementById('installmentMonths').value = '';
                document.getElementById('monthlyCalculationResult').style.display = 'none';
            }
            
            if (commitment.image_url) {
                document.getElementById('previewImg').src = '<?= base_url() ?>' + commitment.image_url;
                document.getElementById('imagePreview').style.display = 'block';
            } else {
                document.getElementById('imagePreview').style.display = 'none';
            }
            document.getElementById('commitmentImage').value = '';
            
            openModal('commitmentModal');
        
    } catch (error) {
        console.error('خطأ في تحميل الالتزام:', error);
        showToast(error.message || 'حدث خطأ في تحميل البيانات', 'error');
    }
}

async function saveCommitment() {
    const name = document.getElementById('commitmentName').value.trim();
    const amount = document.getElementById('commitmentAmount').value;
    const paymentDay = document.getElementById('paymentDay').value;
    const startDate = document.getElementById('startDate').value;
    
    if (!name) {
        showToast('اسم الالتزام مطلوب', 'error');
        return;
    }
    
    if (!amount || parseFloat(amount) <= 0) {
        showToast('المبلغ مطلوب ويجب أن يكون أكبر من صفر', 'error');
        return;
    }
    
    if (!paymentDay || parseInt(paymentDay) < 1 || parseInt(paymentDay) > 31) {
        showToast('يوم الدفع يجب أن يكون بين 1 و 31', 'error');
        return;
    }
    
    if (!startDate) {
        showToast('تاريخ البدء مطلوب', 'error');
        return;
    }
    
    const formData = new FormData();
    formData.append('name', name);
    formData.append('type', document.getElementById('commitmentType').value);
    formData.append('category', document.getElementById('commitmentCategory').value || '');
    formData.append('amount', parseFloat(amount));
    const annualAmount = document.getElementById('annualAmount').value;
    if (annualAmount) {
        formData.append('annual_amount', parseFloat(annualAmount));
    }
    formData.append('received_amount', parseFloat(document.getElementById('receivedAmount').value) || 0);
    formData.append('payment_day', parseInt(paymentDay));
    formData.append('recipient', document.getElementById('recipient').value.trim());
    formData.append('start_date', startDate);
    const endDate = document.getElementById('endDate').value;
    if (endDate) {
        formData.append('end_date', endDate);
    }
    const loanStartDate = document.getElementById('loanStartDate').value;
    if (loanStartDate) {
        formData.append('loan_start_date', loanStartDate);
    }
    formData.append('status', document.getElementById('status').value);
    formData.append('notes', document.getElementById('notes').value.trim());
    formData.append('paid_amount', parseFloat(document.getElementById('paidAmount').value) || 0);
    
    const monthlyPayment = document.getElementById('monthlyPayment').value;
    if (monthlyPayment) {
        formData.append('monthly_payment', parseFloat(monthlyPayment));
    }
    
    const imageFile = document.getElementById('commitmentImage').files[0];
    if (imageFile) {
        formData.append('image', imageFile);
    }
    
    const commitmentId = document.getElementById('commitmentId').value;
    const isEdit = commitmentId && commitmentId !== '';
    
    try {
        const url = isEdit 
            ? `<?= base_url('api/commitments/') ?>${commitmentId}`
            : '<?= base_url('api/commitments') ?>';
        
        const method = isEdit ? 'PUT' : 'POST';
        
        const response = await fetch(url, {
            method: method,
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: formData
        });
        
        if (response.ok) {
            const result = await response.json();
            showToast(result.message || 'تم حفظ الالتزام بنجاح', 'success');
            setTimeout(() => location.reload(), 1500);
        } else {
            const error = await response.json();
            showToast(error.message || 'حدث خطأ في الحفظ', 'error');
        }
    } catch (error) {
        console.error('خطأ في حفظ الالتزام:', error);
        showToast('حدث خطأ في الاتصال بالخادم', 'error');
    }
}

function previewCommitmentImage(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('previewImg').src = e.target.result;
            document.getElementById('imagePreview').style.display = 'block';
        };
        reader.readAsDataURL(input.files[0]);
    }
}

function removeCommitmentImage() {
    document.getElementById('commitmentImage').value = '';
    document.getElementById('previewImg').src = '';
    document.getElementById('imagePreview').style.display = 'none';
}

async function deleteCommitment(id) {
    if (!confirm('هل أنت متأكد من حذف هذا الالتزام؟')) return;
    
    try {
        const response = await fetch(`<?= base_url('api/commitments/') ?>${id}`, {
            method: 'DELETE',
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        });
        
        if (response.ok) {
            showToast('تم حذف الالتزام بنجاح', 'success');
            setTimeout(() => location.reload(), 1500);
        } else {
            const error = await response.json();
            showToast(error.message || 'حدث خطأ في الحذف', 'error');
        }
    } catch (error) {
        console.error('خطأ في حذف الالتزام:', error);
        showToast('حدث خطأ في الاتصال بالخادم', 'error');
    }
}

async function showAdvancePayment(id, type) {
    try {
        const response = await fetch(`<?= base_url('api/commitments/') ?>${id}`);
        if (!response.ok) {
            throw new Error('فشل في تحميل بيانات الالتزام');
        }
        
        const result = await response.json();
        
        let commitment;
        if (result.success && result.data) {
            commitment = result.data;
        } else if (result.id || result.name) {
            commitment = result;
        } else {
            throw new Error('بيانات الالتزام غير صحيحة');
        }
        
        if (!commitment.amount || commitment.amount <= 0) {
            throw new Error('المبلغ الإجمالي غير صحيح');
        }
        
        const remaining = commitment.amount - (commitment.paid_amount || 0);
        const monthlyPayment = commitment.monthly_payment || 0;
        
        if (remaining <= 0) {
            throw new Error('تم سداد هذا الالتزام بالكامل');
        }
        
        let html = `
            <div class="payment-header">
                <h4>${commitment.name}</h4>
                <p>المستلم: ${commitment.recipient || 'غير محدد'}</p>
            </div>
            
            <div class="payment-summary">
                <div class="summary-item">
                    <span>المبلغ الإجمالي:</span>
                    <strong>${commitment.amount.toLocaleString('ar-SA')} دينار</strong>
                </div>
                <div class="summary-item">
                    <span>المدفوع:</span>
                    <strong style="color: #27ae60;">${(commitment.paid_amount || 0).toLocaleString('ar-SA')} دينار</strong>
                </div>
                <div class="summary-item">
                    <span>المتبقي:</span>
                    <strong style="color: #e74c3c;">${remaining.toLocaleString('ar-SA')} دينار</strong>
                </div>
        `;
        
        if (monthlyPayment > 0) {
            html += `
                <div class="summary-item">
                    <span>الدفعة الشهرية:</span>
                    <strong>${monthlyPayment.toLocaleString('ar-SA')} دينار</strong>
                </div>
            `;
        }
        
        html += `
            </div>
            
            <h4 style="margin-top: 20px;">اختر خيار الدفع المقدم:</h4>
            <div class="advance-payment-options">
        `;
        
        if (monthlyPayment > 0) {
            html += `
                <div class="advance-option" onclick="selectAdvanceOption('months', 1, ${monthlyPayment})">
                    <div class="months">1 شهر</div>
                    <div class="amount">${monthlyPayment.toLocaleString('ar-SA')} دينار</div>
                    <small>دفعة شهر واحد</small>
                </div>
                
                <div class="advance-option" onclick="selectAdvanceOption('months', 3, ${monthlyPayment})">
                    <div class="months">3 أشهر</div>
                    <div class="amount">${(monthlyPayment * 3).toLocaleString('ar-SA')} دينار</div>
                    <small>دفعة 3 أشهر</small>
                </div>
            `;
            
            if (type === 'debt') {
                html += `
                    <div class="advance-option" onclick="selectAdvanceOption('months', 6, ${monthlyPayment})">
                        <div class="months">6 أشهر</div>
                        <div class="amount">${(monthlyPayment * 6).toLocaleString('ar-SA')} دينار</div>
                        <small>دفعة 6 أشهر</small>
                    </div>
                    
                    <div class="advance-option" onclick="selectAdvanceOption('months', 12, ${monthlyPayment})">
                        <div class="months">12 شهر</div>
                        <div class="amount">${(monthlyPayment * 12).toLocaleString('ar-SA')} دينار</div>
                        <small>دفعة سنة كاملة</small>
                    </div>
                `;
            }
        }
        
        html += `
                <div class="advance-option" onclick="selectAdvanceOption('percentage', 0.25, ${remaining})">
                    <div class="months">25%</div>
                    <div class="amount">${(remaining * 0.25).toLocaleString('ar-SA')} دينار</div>
                    <small>دفعة ربع المبلغ</small>
                </div>
                
                <div class="advance-option" onclick="selectAdvanceOption('percentage', 0.5, ${remaining})">
                    <div class="months">50%</div>
                    <div class="amount">${(remaining * 0.5).toLocaleString('ar-SA')} دينار</div>
                    <small>دفعة نصف المبلغ</small>
                </div>
                
                <div class="advance-option" onclick="selectAdvanceOption('percentage', 0.75, ${remaining})">
                    <div class="months">75%</div>
                    <div class="amount">${(remaining * 0.75).toLocaleString('ar-SA')} دينار</div>
                    <small>دفعة ثلاثة أرباع</small>
                </div>
                
                <div class="advance-option" onclick="selectAdvanceOption('percentage', 1, ${remaining})">
                    <div class="months">100%</div>
                    <div class="amount">${remaining.toLocaleString('ar-SA')} دينار</div>
                    <small>دفعة كاملة</small>
                </div>
            </div>
            
            <div class="custom-advance" style="margin-top: 20px;">
                <label>أو أدخل مبلغاً مخصصاً:</label>
                <input type="number" id="customAdvanceAmount" class="form-control" 
                       placeholder="المبلغ المدفوع مقدمًا" 
                       oninput="updateCustomAdvance(this.value)"
                       style="margin-top: 10px;">
                <div id="advanceInfo" style="margin-top: 10px; font-size: 0.9rem; color: #666;"></div>
            </div>
            
            <input type="hidden" id="selectedCommitmentId" value="${id}">
            <input type="hidden" id="selectedAdvanceType" value="">
            <input type="hidden" id="selectedAdvanceValue" value="">
            <input type="hidden" id="selectedAdvanceAmount" value="">
            
            <div style="margin-top: 30px; display: flex; gap: 10px;">
                <button class="btn btn-secondary" onclick="closeModal('advancePaymentModal')">
                    <i class="fas fa-times"></i> إلغاء
                </button>
                <button class="btn btn-success" onclick="processAdvancePayment()">
                    <i class="fas fa-check"></i> تأكيد الدفع
                </button>
            </div>
        `;
        
        const contentElement = document.getElementById('advancePaymentContent');
        if (!contentElement) {
            throw new Error('عنصر محتوى الدفع المقدم غير موجود');
        }
        
        contentElement.innerHTML = html;
        openModal('advancePaymentModal');
        
    } catch (error) {
        console.error('خطأ في تحميل خيارات الدفع:', error);
        showToast(error.message || 'حدث خطأ في تحميل الخيارات', 'error');
    }
}

function selectAdvanceOption(type, value, baseAmount) {
    document.querySelectorAll('.advance-option').forEach(opt => {
        opt.classList.remove('selected');
    });
    
    const selectedElement = event.target.closest('.advance-option');
    if (selectedElement) {
        selectedElement.classList.add('selected');
    }
    
    let amount = 0;
    if (type === 'percentage') {
        amount = baseAmount * value;
    } else if (type === 'months') {
        amount = baseAmount * value;
    }
    
    const typeElement = document.getElementById('selectedAdvanceType');
    const valueElement = document.getElementById('selectedAdvanceValue');
    const amountElement = document.getElementById('selectedAdvanceAmount');
    const customAmountElement = document.getElementById('customAdvanceAmount');
    const infoElement = document.getElementById('advanceInfo');
    
    if (typeElement) typeElement.value = type;
    if (valueElement) valueElement.value = value;
    if (amountElement) amountElement.value = amount;
    if (customAmountElement) customAmountElement.value = amount;
    
    if (infoElement) {
        infoElement.innerHTML = `
        <div style="background: #e8f5e9; padding: 8px; border-radius: 5px;">
            <i class="fas fa-check-circle" style="color: #27ae60;"></i>
            تم اختيار دفعة ${type === 'percentage' ? (value * 100) + '%' : value + ' أشهر'} (${amount.toLocaleString('ar-SA')} دينار)
        </div>
    `;
    }
}

function updateCustomAdvance(amount) {
    const customAmount = parseFloat(amount) || 0;
    const typeElement = document.getElementById('selectedAdvanceType');
    const amountElement = document.getElementById('selectedAdvanceAmount');
    const infoElement = document.getElementById('advanceInfo');
    
    if (typeElement) typeElement.value = 'custom';
    if (amountElement) amountElement.value = customAmount;
    
    document.querySelectorAll('.advance-option').forEach(opt => {
        opt.classList.remove('selected');
    });
    
    if (infoElement) {
        infoElement.innerHTML = `
        <div style="background: #e3f2fd; padding: 8px; border-radius: 5px;">
            <i class="fas fa-check-circle" style="color: #2196f3;"></i>
            تم اختيار مبلغ ${customAmount.toLocaleString('ar-SA')} دينار
        </div>
    `;
    }
}

async function processAdvancePayment() {
    const commitmentIdElement = document.getElementById('selectedCommitmentId');
    const amountElement = document.getElementById('selectedAdvanceAmount');
    
    if (!commitmentIdElement || !amountElement) {
        showToast('حدث خطأ في الوصول إلى بيانات الدفع', 'error');
        return;
    }
    
    const commitmentId = commitmentIdElement.value;
    const amount = parseFloat(amountElement.value);
    
    if (!commitmentId) {
        showToast('معرف الالتزام غير موجود', 'error');
        return;
    }
    
    if (!amount || amount <= 0) {
        showToast('يرجى اختيار مبلغ صالح للدفع', 'warning');
        return;
    }
    
    if (!confirm(`هل تريد تأكيد الدفع المقدم بمبلغ ${amount.toLocaleString('ar-SA')} دينار؟`)) {
        return;
    }
    
    try {
        const response = await fetch(`<?= base_url('api/commitments/') ?>${commitmentId}/advance-payment`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({
                amount: amount,
                payment_date: new Date().toISOString().split('T')[0]
            })
        });
        
        if (response.ok) {
            const result = await response.json();
            showToast('تم تسجيل الدفعة المقدمة بنجاح', 'success');
            closeModal('advancePaymentModal');
            setTimeout(() => location.reload(), 1500);
        } else {
            const error = await response.json();
            showToast(error.message || 'حدث خطأ في معالجة الدفع', 'error');
        }
    } catch (error) {
        console.error('خطأ في معالجة الدفع:', error);
        showToast('حدث خطأ في الاتصال بالخادم', 'error');
    }
}

function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        background: ${type === 'success' ? '#27ae60' : type === 'error' ? '#e74c3c' : '#3498db'};
        color: white;
        border-radius: 8px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        z-index: 10000;
        display: flex;
        align-items: center;
        gap: 10px;
        font-weight: 600;
        opacity: 0;
        transform: translateY(-20px);
        transition: all 0.3s ease;
    `;
    
    toast.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
        ${message}
    `;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.style.opacity = '1';
        toast.style.transform = 'translateY(0)';
    }, 100);
    
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(-20px)';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

function openModal(id) {
    document.getElementById(id).style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

function closeModal(id) {
    document.getElementById(id).style.display = 'none';
    document.body.style.overflow = 'auto';
}
</script>

<?= $this->endSection() ?>