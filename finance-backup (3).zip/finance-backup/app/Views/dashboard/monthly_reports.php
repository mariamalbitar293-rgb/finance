<?= $this->extend('layouts/main') ?>

<?= $this->section('title') ?>
التقارير الشهرية
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="section-header">
    <h2><i class="fas fa-chart-pie"></i> التقارير الشهرية</h2>
    <div class="controls">
        <button class="btn btn-success" id="exportExcelBtn">
            <i class="fas fa-file-excel"></i> تصدير Excel
        </button>
    </div>
</div>

<div class="filters-bar" style="margin-bottom: 20px; display: flex; gap: 15px; flex-wrap: wrap; align-items: center;">
    <div class="form-group">
        <label for="yearFilter">السنة</label>
        <select id="yearFilter" class="form-select">
            <?php foreach ($available_years as $y): ?>
                <option value="<?= $y ?>" <?= $y == $year ? 'selected' : '' ?>><?= $y ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="form-group">
        <label for="monthFilter">الشهر</label>
        <select id="monthFilter" class="form-select">
            <?php
            $months = [
                1 => 'يناير', 2 => 'فبراير', 3 => 'مارس', 4 => 'أبريل',
                5 => 'مايو', 6 => 'يونيو', 7 => 'يوليو', 8 => 'أغسطس',
                9 => 'سبتمبر', 10 => 'أكتوبر', 11 => 'نوفمبر', 12 => 'ديسمبر'
            ];
            foreach ($months as $m => $name): ?>
                <option value="<?= sprintf('%02d', $m) ?>" <?= sprintf('%02d', $m) == $month ? 'selected' : '' ?>>
                    <?= $name ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
    <button class="btn btn-primary" id="loadReportBtn">
        <i class="fas fa-search"></i> عرض التقرير
    </button>
</div>

<div class="stats-cards">
    <div class="stat-card card-1">
        <div class="stat-info">
            <h3>إجمالي المدخولات</h3>
            <div class="value"><?= number_format($report['total_income'] ?? 0, 2) ?> <span style="font-size: 1rem;">دينار</span></div>
        </div>
        <div class="stat-icon"><i class="fas fa-arrow-up"></i></div>
    </div>

    <div class="stat-card card-2">
        <div class="stat-info">
            <h3>إجمالي المصروفات</h3>
            <div class="value"><?= number_format($report['total_expenses'] ?? 0, 2) ?> <span style="font-size: 1rem;">دينار</span></div>
        </div>
        <div class="stat-icon"><i class="fas fa-arrow-down"></i></div>
    </div>

    <div class="stat-card card-3">
        <div class="stat-info">
            <h3>صافي الربح</h3>
            <div class="value" style="color: <?= ($report['net_profit'] ?? 0) >= 0 ? '#27ae60' : '#e74c3c' ?>;">
                <?= number_format($report['net_profit'] ?? 0, 2) ?> <span style="font-size: 1rem;">دينار</span>
            </div>
        </div>
        <div class="stat-icon"><i class="fas fa-chart-line"></i></div>
    </div>
</div>

<div class="table-container" style="margin-top: 30px;">
    <div class="table-header">
        <h3><i class="fas fa-list"></i> تفاصيل المدخولات</h3>
    </div>
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>نوع المدخول</th>
                    <th>المبلغ</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $incomeDetails = json_decode($report['income_details'] ?? '{}', true);
                if (empty($incomeDetails)): ?>
                    <tr>
                        <td colspan="2" style="text-align:center;">لا توجد مدخولات مسجلة</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($incomeDetails as $key => $value): ?>
                        <tr>
                            <td><?= esc($key) ?></td>
                            <td><?= number_format($value, 2) ?> دينار</td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="table-container" style="margin-top: 30px;">
    <div class="table-header">
        <h3><i class="fas fa-list"></i> تفاصيل المصروفات</h3>
    </div>
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>نوع المصروف</th>
                    <th>المبلغ</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $expenseDetails = json_decode($report['expense_details'] ?? '{}', true);
                if (empty($expenseDetails)): ?>
                    <tr>
                        <td colspan="2" style="text-align:center;">لا توجد مصروفات مسجلة</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($expenseDetails as $key => $value): ?>
                        <tr>
                            <td><?= esc($key) ?></td>
                            <td><?= number_format($value, 2) ?> دينار</td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('yearFilter').addEventListener('change', function() {
        loadReport();
    });
    
    document.getElementById('monthFilter').addEventListener('change', function() {
        loadReport();
    });
    
    document.getElementById('loadReportBtn').addEventListener('click', function() {
        loadReport();
    });

    function loadReport() {
        const year = document.getElementById('yearFilter').value;
        const month = document.getElementById('monthFilter').value;
        window.location.href = `<?= site_url('dashboard/monthlyReports') ?>?year=${year}&month=${month}`;
    }

    document.getElementById('exportExcelBtn').addEventListener('click', function() {
        const year = document.getElementById('yearFilter').value;
        const month = document.getElementById('monthFilter').value;
        window.location.href = `<?= site_url('dashboard/monthlyReports/export') ?>?year=${year}&month=${month}`;
    });
});
</script>

<?= $this->endSection() ?>
