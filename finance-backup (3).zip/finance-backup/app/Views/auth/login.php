<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل الدخول - نظام إدارة الحسابات المالية</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Cairo', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px;
            padding-bottom: 200px;
            position: relative;
            overflow-x: hidden;
        }

        body::before {
            content: '';
            position: absolute;
            width: 200%;
            height: 200%;
            background: url('data:image/svg+xml,<svg width="100" height="100" xmlns="http://www.w3.org/2000/svg"><circle cx="50" cy="50" r="2" fill="rgba(255,255,255,0.1)"/></svg>');
            animation: float 20s infinite linear;
            z-index: 0;
            pointer-events: none;
        }

        @keyframes float {
            0% { transform: translate(0, 0); }
            100% { transform: translate(-50%, -50%); }
        }

        .login-container {
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            padding: 50px;
            width: 100%;
            max-width: 450px;
            position: relative;
            z-index: 10;
            animation: slideIn 0.5s ease-out;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .login-header {
            text-align: center;
            margin-bottom: 40px;
        }

        .login-logo {
            width: 130px;
            height: 130px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            box-shadow: 0 15px 40px rgba(102, 126, 234, 0.5);
            animation: pulse 2s infinite;
            position: relative;
            overflow: hidden;
            border: 4px solid rgba(255, 255, 255, 0.3);
        }

        .login-logo::before {
            content: '';
            position: absolute;
            width: 100%;
            height: 100%;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" style="stop-color:white;stop-opacity:1" /><stop offset="100%" style="stop-color:white;stop-opacity:0.8" /></linearGradient></defs><circle cx="50" cy="38" r="18" fill="url(%23grad)"/><path d="M25 80 Q50 65 75 80 L75 100 L25 100 Z" fill="url(%23grad)"/></svg>') center/75% no-repeat;
        }

        @keyframes pulse {
            0%, 100% { 
                transform: scale(1);
                box-shadow: 0 15px 40px rgba(102, 126, 234, 0.5);
            }
            50% { 
                transform: scale(1.08);
                box-shadow: 0 20px 50px rgba(102, 126, 234, 0.7);
            }
        }

        .user-avatar-svg {
            width: 100%;
            height: 100%;
            position: relative;
            z-index: 1;
        }

        .user-avatar-svg svg {
            width: 100%;
            height: 100%;
        }

        .login-header h1 {
            color: #333;
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 10px;
        }

        .login-header p {
            color: #666;
            font-size: 14px;
        }

        .form-group {
            margin-bottom: 25px;
            position: relative;
        }

        .form-group label {
            display: block;
            color: #333;
            font-weight: 600;
            margin-bottom: 8px;
            font-size: 14px;
            position: relative;
            z-index: 1;
        }

        .input-wrapper {
            position: relative;
        }

        .input-wrapper i {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
            font-size: 18px;
            z-index: 2;
            pointer-events: none;
        }

        .form-group input {
            width: 100%;
            padding: 15px 50px 15px 20px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 16px;
            font-family: 'Cairo', sans-serif;
            transition: all 0.3s ease;
            background: #ffffff;
            color: #333;
            position: relative;
            z-index: 1;
        }

        .form-group input:focus {
            outline: none;
            border-color: #667eea;
            background: white;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .remember-forgot {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            font-size: 14px;
            position: relative;
            z-index: 1;
        }

        .remember-me {
            display: flex;
            align-items: center;
            gap: 8px;
            position: relative;
            z-index: 1;
        }

        .remember-me input[type="checkbox"] {
            width: 18px;
            height: 18px;
            cursor: pointer;
        }

        .forgot-password {
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s;
            position: relative;
            z-index: 1;
        }

        .forgot-password:hover {
            color: #764ba2;
        }

        .login-btn {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 18px;
            font-weight: 600;
            font-family: 'Cairo', sans-serif;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
            position: relative;
            overflow: hidden;
            z-index: 1;
        }

        .login-btn::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.3);
            transform: translate(-50%, -50%);
            transition: width 0.6s, height 0.6s;
        }

        .login-btn:hover::before {
            width: 300px;
            height: 300px;
        }

        .login-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(102, 126, 234, 0.5);
        }

        .login-btn:active {
            transform: translateY(0);
        }

        .error-message {
            background: #fee;
            color: #c33;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-right: 4px solid #c33;
            display: none;
            position: relative;
            z-index: 1;
        }

        .error-message.show {
            display: block;
            animation: shake 0.5s;
        }

        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-10px); }
            75% { transform: translateX(10px); }
        }

        .loading {
            display: none;
            text-align: center;
            margin-top: 20px;
        }

        .loading.show {
            display: block;
        }

        .spinner {
            border: 3px solid rgba(102, 126, 234, 0.3);
            border-top: 3px solid #667eea;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 0 auto;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .login-footer {
            position: fixed;
            bottom: 30px;
            left: 50%;
            transform: translateX(-50%);
            text-align: center;
            z-index: 5;
            width: 100%;
            max-width: 500px;
            padding: 0 20px;
        }

        .footer-image {
            width: 100%;
            max-width: 400px;
            height: auto;
            margin: 0 auto 15px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            animation: fadeInUp 1s ease-out 0.5s both;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .footer-text {
            color: white;
            font-size: 14px;
            font-weight: 500;
            text-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
        }

        @media (max-width: 480px) {
            .login-container {
                padding: 30px 20px;
            }

            .login-header h1 {
                font-size: 24px;
            }

            .login-footer {
                bottom: 15px;
            }

            .footer-image {
                max-width: 300px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <div class="login-logo">
                <svg class="user-avatar-svg" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                    <defs>
                        <linearGradient id="avatarGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" style="stop-color:white;stop-opacity:1" />
                            <stop offset="100%" style="stop-color:white;stop-opacity:0.9" />
                        </linearGradient>
                    </defs>
                    <!-- رأس المستخدم -->
                    <circle cx="50" cy="38" r="18" fill="url(#avatarGrad)"/>
                    <!-- جسم المستخدم -->
                    <path d="M25 80 Q50 65 75 80 L75 100 L25 100 Z" fill="url(#avatarGrad)"/>
                </svg>
            </div>
            <h1>مرحباً بك</h1>
            <p>سجل دخولك للوصول إلى لوحة التحكم</p>
        </div>

        <div class="error-message" id="errorMessage"></div>

        <form id="loginForm">
            <div class="form-group">
                <label for="username"><i class="fas fa-user"></i> اسم المستخدم</label>
                <div class="input-wrapper">
                    <i class="fas fa-user"></i>
                    <input type="text" id="username" name="username" required autocomplete="username" placeholder="أدخل اسم المستخدم">
                </div>
            </div>

            <div class="form-group">
                <label for="password"><i class="fas fa-lock"></i> كلمة المرور</label>
                <div class="input-wrapper">
                    <i class="fas fa-lock"></i>
                    <input type="password" id="password" name="password" required autocomplete="current-password" placeholder="أدخل كلمة المرور">
                </div>
            </div>

            <div class="form-group">
                <label for="userType"><i class="fas fa-user-tag"></i> نوع المستخدم</label>
                <div class="input-wrapper">
                    <i class="fas fa-user-tag"></i>
                    <select id="userType" name="userType" required style="padding: 15px 50px 15px 20px; border: 2px solid #e0e0e0; border-radius: 10px; font-size: 16px; font-family: 'Cairo', sans-serif; width: 100%; background: #ffffff; color: #333; appearance: none; cursor: pointer;">
                        <option value="">اختر نوع المستخدم</option>
                        <option value="admin">مدير النظام</option>
                        <option value="employee">موظف</option>
                    </select>
                </div>
            </div>

            <div class="remember-forgot">
                <label class="remember-me">
                    <input type="checkbox" id="remember" name="remember">
                    <span>تذكرني</span>
                </label>
                <a href="#" class="forgot-password">نسيت كلمة المرور؟</a>
            </div>

            <button type="submit" class="login-btn">
                <span id="btnText">تسجيل الدخول</span>
            </button>

            <div style="text-align: center; margin-top: 20px; padding-top: 20px; border-top: 1px solid #e0e0e0;">
                <p style="color: #666; font-size: 14px;">
                    ليس لديك حساب؟ 
                    <a href="<?= base_url('auth/register') ?>" style="color: #667eea; text-decoration: none; font-weight: 600;">إنشاء حساب جديد</a>
                </p>
            </div>
        </form>

        <div class="loading" id="loading">
            <div class="spinner"></div>
            <p style="margin-top: 10px; color: #666;">جاري تسجيل الدخول...</p>
        </div>
    </div>

    <script>
        const baseURL = '<?= base_url() ?>';
        const loginForm = document.getElementById('loginForm');
        const errorMessage = document.getElementById('errorMessage');
        const loading = document.getElementById('loading');
        const btnText = document.getElementById('btnText');

        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            const userType = document.getElementById('userType').value;
            const remember = document.getElementById('remember').checked;

            if (!userType) {
                errorMessage.textContent = 'يرجى اختيار نوع المستخدم';
                errorMessage.classList.add('show');
                return;
            }

            errorMessage.classList.remove('show');
            loading.classList.add('show');
            loginForm.style.opacity = '0.5';
            loginForm.style.pointerEvents = 'none';
            btnText.textContent = 'جاري التحقق...';

            try {
                const response = await fetch(`${baseURL}/auth/login`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ username, password, userType, remember })
                });

                let result;
                try {
                    const contentType = response.headers.get('content-type');
                    if (contentType && contentType.includes('application/json')) {
                        result = await response.json();
                    } else {
                        const text = await response.text();
                        result = { success: false, message: text || 'حدث خطأ غير متوقع' };
                    }
                } catch (e) {
                    result = { success: false, message: 'خطأ في قراءة الاستجابة من الخادم' };
                }

                if (response.ok && result && result.success) {
                    // Success - redirect to dashboard
                    window.location.href = `${baseURL}/dashboard`;
                } else {
                    // Show error
                    errorMessage.textContent = (result && result.message) ? result.message : 'اسم المستخدم أو كلمة المرور غير صحيحة';
                    errorMessage.classList.add('show');
                    loading.classList.remove('show');
                    loginForm.style.opacity = '1';
                    loginForm.style.pointerEvents = 'auto';
                    btnText.textContent = 'تسجيل الدخول';
                }
            } catch (error) {
                errorMessage.textContent = 'حدث خطأ في الاتصال. يرجى المحاولة مرة أخرى.';
                errorMessage.classList.add('show');
                loading.classList.remove('show');
                loginForm.style.opacity = '1';
                loginForm.style.pointerEvents = 'auto';
                btnText.textContent = 'تسجيل الدخول';
                console.error('Login error:', error);
            }
        });

        // Auto-focus on username field
        document.getElementById('username').focus();
    </script>

    <div class="login-footer">
        <div class="footer-image" style="background: linear-gradient(135deg, rgba(255,255,255,0.2) 0%, rgba(255,255,255,0.1) 100%); padding: 30px; border-radius: 15px; backdrop-filter: blur(10px);">
            <svg viewBox="0 0 400 200" xmlns="http://www.w3.org/2000/svg" style="width: 100%; height: auto;">
                <defs>
                    <linearGradient id="footerGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" style="stop-color:rgba(255,255,255,0.9);stop-opacity:1" />
                        <stop offset="100%" style="stop-color:rgba(255,255,255,0.7);stop-opacity:1" />
                    </linearGradient>
                </defs>
                <!-- رسمة مالية -->
                <rect x="50" y="80" width="80" height="60" rx="5" fill="url(#footerGrad)" opacity="0.8"/>
                <rect x="160" y="60" width="80" height="80" rx="5" fill="url(#footerGrad)" opacity="0.8"/>
                <rect x="270" y="90" width="80" height="50" rx="5" fill="url(#footerGrad)" opacity="0.8"/>
                <circle cx="90" cy="50" r="15" fill="url(#footerGrad)" opacity="0.9"/>
                <circle cx="200" cy="30" r="20" fill="url(#footerGrad)" opacity="0.9"/>
                <circle cx="310" cy="60" r="18" fill="url(#footerGrad)" opacity="0.9"/>
                <!-- خطوط الاتصال -->
                <line x1="130" y1="110" x2="160" y2="100" stroke="url(#footerGrad)" stroke-width="3" opacity="0.6"/>
                <line x1="240" y1="100" x2="270" y2="115" stroke="url(#footerGrad)" stroke-width="3" opacity="0.6"/>
            </svg>
        </div>
        <p class="footer-text">نظام إدارة الحسابات المالية المتكامل</p>
    </div>
</body>
</html>
