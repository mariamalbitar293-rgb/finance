<?php

namespace App\Controllers;

use App\Models\MonthlyReportModel;
use App\Models\ClientModel;
use App\Models\CommitmentModel;
use App\Models\SalaryModel;
use App\Helpers\DatabaseHelper;
use CodeIgniter\Controller;

class MonthlyReportController extends BaseController
{
    private function checkAccess()
    {
        $userRole = session()->get('role');
        if ($userRole !== 'admin') {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('غير مصرح لك بالوصول إلى هذه الصفحة');
        }
    }

    public function index()
    {
        $this->checkAccess();
        
        try {
            $db = \Config\Database::connect();
            if (!DatabaseHelper::monthlyReportsTableExists($db)) {
                DatabaseHelper::createMonthlyReportsTable($db);
            }
        } catch (\Exception $e) {
            log_message('error', 'Failed to check/create monthly_reports table: ' . $e->getMessage());
        }

        $year = $this->request->getGet('year') ?? date('Y');
        $month = $this->request->getGet('month') ?? date('m');
        
        $monthlyModel = new MonthlyReportModel();
        $report = $monthlyModel->getOrCreateReport($year, $month);
        
        $data = [
            'year' => $year,
            'month' => $month,
            'report' => $report,
            'available_years' => $monthlyModel->getAvailableYears()
        ];
        
        return view('dashboard/monthly_reports', $data);
    }

    public function exportExcel()
    {
        $this->checkAccess();
        try {
            $db = \Config\Database::connect();
            if (!DatabaseHelper::monthlyReportsTableExists($db)) {
                DatabaseHelper::createMonthlyReportsTable($db);
            }
        } catch (\Exception $e) {
            log_message('error', 'Failed to check/create monthly_reports table: ' . $e->getMessage());
        }

        $year = $this->request->getGet('year') ?? date('Y');
        $month = $this->request->getGet('month') ?? date('m');
        
        $monthlyModel = new MonthlyReportModel();
        $report = $monthlyModel->getOrCreateReport($year, $month);
        
        $filename = "monthly_report_{$year}_{$month}.csv";
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Pragma: no-cache');
        header('Expires: 0');
        
        $output = fopen('php://output', 'w');
        
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
        
        fputcsv($output, ['التقرير الشهري', "{$year}/{$month}"], ',');
        fputcsv($output, [], ',');
        fputcsv($output, ['إجمالي المدخولات', number_format($report['total_income'], 2) . ' دينار'], ',');
        fputcsv($output, ['إجمالي المصروفات', number_format($report['total_expenses'], 2) . ' دينار'], ',');
        fputcsv($output, ['صافي الربح', number_format($report['net_profit'], 2) . ' دينار'], ',');
        fputcsv($output, [], ',');
        
        $incomeDetails = json_decode($report['income_details'] ?? '{}', true);
        if (!empty($incomeDetails)) {
            fputcsv($output, ['تفاصيل المدخولات'], ',');
            foreach ($incomeDetails as $key => $value) {
                fputcsv($output, [$key, number_format($value, 2) . ' دينار'], ',');
            }
            fputcsv($output, [], ',');
        }
        
        $expenseDetails = json_decode($report['expense_details'] ?? '{}', true);
        if (!empty($expenseDetails)) {
            fputcsv($output, ['تفاصيل المصروفات'], ',');
            foreach ($expenseDetails as $key => $value) {
                fputcsv($output, [$key, number_format($value, 2) . ' دينار'], ',');
            }
        }
        
        fclose($output);
        exit;
    }
}
