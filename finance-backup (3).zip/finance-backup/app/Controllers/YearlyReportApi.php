<?php

namespace App\Controllers;

use App\Models\YearlyReportModel;
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;

class YearlyReportApi extends ResourceController
{
    use ResponseTrait;

    protected $modelName = 'App\Models\YearlyReportModel';
    protected $format = 'json';

    public function show($year = null)
    {
        if (!$year || !is_numeric($year)) {
            return $this->fail('السنة مطلوبة ويجب أن تكون رقمًا', 400);
        }

        $data = $this->model->getYearlyData((int)$year);

        if (!$data) {
            return $this->failNotFound("لا توجد بيانات للسنة $year");
        }

        
        if (isset($data['budget_data']) && is_string($data['budget_data'])) {
            $decoded = json_decode($data['budget_data'], true);
            $data['budget_data'] = $decoded ?: [];
        }

        
        $defaultBudget = [
            'salaries' => 7800,
            'operational' => 4750,
            'marketing' => 2850,
            'assets' => 2300,
            'other' => 1500
        ];

        $budgetData = $data['budget_data'] ?? $defaultBudget;

        $budgetItems = [
            'salaries'    => ['label' => 'الرواتب',             'planned' => 8000],
            'operational' => ['label' => 'المصروفات التشغيلية', 'planned' => 4500],
            'marketing'   => ['label' => 'التسويق والإعلان',     'planned' => 3000],
            'assets'      => ['label' => 'الموجودات والمعدات',   'planned' => 2500],
            'other'       => ['label' => 'مصاريف أخرى',           'planned' => 1500],
        ];

        $tableData = [];
        foreach ($budgetItems as $key => $item) {
            $actual = $budgetData[$key] ?? 0;
            $deviation = $actual - $item['planned'];
            $percentage = $item['planned'] > 0 ? round(($actual / $item['planned']) * 100, 1) : 0;

            $tableData[] = [
                'label'       => $item['label'],
                'planned'     => $item['planned'],
                'actual'      => $actual,
                'deviation'   => $deviation,
                'deviation_text' => $deviation >= 0 ? '+' . $deviation : $deviation,
                'percentage'  => $percentage,
                'class'       => $deviation > 0 ? 'overdue' : ($deviation < 0 ? 'paid' : 'neutral')
            ];
        }

        $response = [
            'year'         => $year,
            'revenue'      => $data['revenue'] ?? 34500,
            'expenses'     => $data['expenses'] ?? 18200,
            'profit'       => $data['profit'] ?? 16300,
            'monthly_avg'  => round(($data['revenue'] ?? 34500) / 12),
            'budget_table' => $tableData,
            'budget_values' => array_values($budgetData)
        ];

        return $this->respond($response);
    }

    public function index()
    {
        $years = $this->request->getGet('years');
        $yearArray = $years ? explode(',', $years) : [];

        if (empty($yearArray)) {
            $available = $this->model->select('year')->orderBy('year', 'DESC')->findAll();
            $yearArray = array_column($available, 'year');
        }

        $result = [];
        foreach ($yearArray as $y) {
            $result[$y] = $this->model->getYearlyData($y);
        }

        return $this->respond($result);
    }
}