<?php

namespace App\Controllers;

class Main extends BaseController
{
    public function index()
    {
        if (!session()->has('logged_in') || !session()->get('logged_in')) {
            return redirect()->to('/auth/login');
        }
        return redirect()->to('/dashboard');
    }
}