<?php

namespace App\Controllers;

use App\Models\SalaryModel;
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;

class SalaryApi extends ResourceController
{
    use ResponseTrait;

    protected $modelName = 'App\Models\SalaryModel';
    protected $format = 'json';

    public function index()
    {
        $month = $this->request->getGet('month');
        $employee = $this->request->getGet('employee');

        $salaryModel = new SalaryModel();
        $salaries = $salaryModel->getSalaries($month, $employee);

        if (!\App\Helpers\PermissionHelper::canViewNumbers()) {
            foreach ($salaries as &$s) {
                $s['basic_salary'] = null;
                $s['bonuses'] = null;
                $s['deductions'] = null;
                $s['net_salary'] = null;
                $s['exchange_rate'] = null;
            }
        }

        return $this->respond($salaries);
    }

    public function create()
    {
        $data = $this->request->getJSON(true);

        if (empty($data)) {
            return $this->respond([
                'success' => false,
                'message' => 'لم يتم إرسال أي بيانات'
            ], 400);
        }

        if (empty($data['employee_name']) || trim($data['employee_name']) === '') {
            return $this->respond([
                'success' => false,
                'message' => 'اسم الموظف مطلوب'
            ], 400);
        }

        if (empty($data['basic_salary']) || floatval($data['basic_salary']) <= 0) {
            return $this->respond([
                'success' => false,
                'message' => 'الراتب الأساسي مطلوب ويجب أن يكون أكبر من صفر'
            ], 400);
        }

        if (empty($data['payment_date'])) {
            return $this->respond([
                'success' => false,
                'message' => 'تاريخ الصرف مطلوب'
            ], 400);
        }

        $basicSalary = floatval($data['basic_salary']);
        $bonuses = floatval($data['bonuses'] ?? 0);
        $deductions = floatval($data['deductions'] ?? 0);
        $netSalary = $basicSalary + $bonuses - $deductions;

        $salaryData = [
            'employee_name' => trim($data['employee_name']),
            'basic_salary' => $basicSalary,
            'bonuses' => $bonuses,
            'deductions' => $deductions,
            'net_salary' => $netSalary,
            'payment_date' => $data['payment_date'],
            'status' => $data['status'] ?? 'pending'
        ];

        if (isset($data['position']) && $data['position'] !== null && $data['position'] !== '') {
            $position = trim($data['position']);
            if ($position !== '') {
                $salaryData['position'] = $position;
            }
        }
        
        if (isset($data['country']) && $data['country'] !== null && $data['country'] !== '') {
            $country = trim($data['country']);
            if ($country !== '') {
                $salaryData['country'] = $country;
            }
        }
        
        if (isset($data['exchange_rate']) && $data['exchange_rate'] !== null && $data['exchange_rate'] !== '') {
            $exchangeRate = floatval($data['exchange_rate']);
            if ($exchangeRate > 0) {
                $salaryData['exchange_rate'] = $exchangeRate;
            }
        }
        
        if (isset($data['notes']) && !empty(trim($data['notes']))) {
            $salaryData['notes'] = trim($data['notes']);
        }
        
        if (isset($data['photo_url']) && !empty(trim($data['photo_url']))) {
            $salaryData['photo_url'] = trim($data['photo_url']);
        }

        $salaryModel = new SalaryModel();
        
        $debugInfo = [
            'received_position' => $data['position'] ?? 'NOT_SET',
            'received_country' => $data['country'] ?? 'NOT_SET',
            'salaryData_position' => $salaryData['position'] ?? 'NOT_SET',
            'salaryData_country' => $salaryData['country'] ?? 'NOT_SET',
            'salaryData_keys' => array_keys($salaryData)
        ];
        
        try {
            $id = $salaryModel->insert($salaryData);
            
            if (!$id) {
                $errors = $salaryModel->errors();
                return $this->respond([
                    'success' => false,
                    'message' => 'فشل في إضافة الراتب',
                    'errors' => $errors,
                    'debug' => $debugInfo
                ], 500);
            }
            
            $salary = $salaryModel->find($id);
            
            $debugInfo['saved_position'] = $salary['position'] ?? 'NULL';
            $debugInfo['saved_country'] = $salary['country'] ?? 'NULL';
            $debugInfo['saved_exchange_rate'] = $salary['exchange_rate'] ?? 'NULL';
            
            return $this->respondCreated([
                'success' => true,
                'message' => 'تم إضافة الراتب بنجاح',
                'data' => $salary,
                'debug' => $debugInfo
            ]);
        } catch (\CodeIgniter\Database\Exceptions\DatabaseException $e) {
            $errorMessage = $e->getMessage();
            
            if (strpos($errorMessage, 'position') !== false) {
                unset($salaryData['position']);
                try {
                    $id = $salaryModel->insert($salaryData);
                    if ($id) {
                        $salary = $salaryModel->find($id);
                        return $this->respondCreated([
                            'success' => true,
                            'message' => 'تم إضافة الراتب بنجاح',
                            'data' => $salary
                        ]);
                    }
                } catch (\Exception $e2) {
                    $errorMessage = $e2->getMessage();
                }
            }
            
            if (strpos($errorMessage, 'country') !== false) {
                unset($salaryData['country']);
                unset($salaryData['exchange_rate']);
                try {
                    $id = $salaryModel->insert($salaryData);
                    if ($id) {
                        $salary = $salaryModel->find($id);
                        return $this->respondCreated([
                            'success' => true,
                            'message' => 'تم إضافة الراتب بنجاح',
                            'data' => $salary
                        ]);
                    }
                } catch (\Exception $e2) {
                    $errorMessage = $e2->getMessage();
                }
            }
            
            if (strpos($errorMessage, 'exchange_rate') !== false) {
                unset($salaryData['exchange_rate']);
                try {
                    $id = $salaryModel->insert($salaryData);
                    if ($id) {
                        $salary = $salaryModel->find($id);
                        return $this->respondCreated([
                            'success' => true,
                            'message' => 'تم إضافة الراتب بنجاح',
                            'data' => $salary
                        ]);
                    }
                } catch (\Exception $e2) {
                    $errorMessage = $e2->getMessage();
                }
            }
            
            if (strpos($errorMessage, 'notes') !== false) {
                unset($salaryData['notes']);
                try {
                    $id = $salaryModel->insert($salaryData);
                    if ($id) {
                        $salary = $salaryModel->find($id);
                        return $this->respondCreated([
                            'success' => true,
                            'message' => 'تم إضافة الراتب بنجاح',
                            'data' => $salary
                        ]);
                    }
                } catch (\Exception $e2) {
                    $errorMessage = $e2->getMessage();
                }
            }
            
            if (strpos($errorMessage, 'photo_url') !== false) {
                unset($salaryData['photo_url']);
                try {
                    $id = $salaryModel->insert($salaryData);
                    if ($id) {
                        $salary = $salaryModel->find($id);
                        return $this->respondCreated([
                            'success' => true,
                            'message' => 'تم إضافة الراتب بنجاح',
                            'data' => $salary
                        ]);
                    }
                } catch (\Exception $e2) {
                    $errorMessage = $e2->getMessage();
                }
            }
            
            return $this->respond([
                'success' => false,
                'message' => 'فشل في إضافة الراتب: ' . $errorMessage
            ], 500);
        } catch (\Exception $e) {
            return $this->respond([
                'success' => false,
                'message' => 'حدث خطأ: ' . $e->getMessage()
            ], 500);
        }
    }

    public function update($id = null)
    {
        if (!$id) {
            return $this->fail('معرف الراتب مطلوب', 400);
        }

        $data = $this->request->getJSON(true);
        $salaryModel = new SalaryModel();

        $salary = $salaryModel->find($id);
        if (!$salary) {
            return $this->failNotFound('الراتب غير موجود');
        }

        if (isset($data['basic_salary']) || isset($data['bonuses']) || isset($data['deductions'])) {
            $basicSalary = floatval($data['basic_salary'] ?? $salary['basic_salary']);
            $bonuses = floatval($data['bonuses'] ?? $salary['bonuses'] ?? 0);
            $deductions = floatval($data['deductions'] ?? $salary['deductions'] ?? 0);
            $data['net_salary'] = $basicSalary + $bonuses - $deductions;
        }

        if (isset($data['position']) && $data['position'] !== null && $data['position'] !== '') {
            $position = trim($data['position']);
            if ($position !== '') {
                $data['position'] = $position;
            } else {
            unset($data['position']);
            }
        }
        
        if (isset($data['country']) && $data['country'] !== null && $data['country'] !== '') {
            $country = trim($data['country']);
            if ($country !== '') {
                $data['country'] = $country;
            } else {
                unset($data['country']);
            }
        }
        
        if (isset($data['exchange_rate'])) {
            if ($data['exchange_rate'] === null || $data['exchange_rate'] === '') {
                unset($data['exchange_rate']);
            } else {
                $exchangeRate = floatval($data['exchange_rate']);
                if ($exchangeRate > 0) {
                    $data['exchange_rate'] = $exchangeRate;
                } else {
                    unset($data['exchange_rate']);
                }
            }
        }

        try {
            $updated = $salaryModel->update($id, $data);
        } catch (\CodeIgniter\Database\Exceptions\DatabaseException $e) {
            $errorMessage = $e->getMessage();
            
            if (strpos($errorMessage, 'position') !== false) {
                unset($data['position']);
            }
            if (strpos($errorMessage, 'country') !== false) {
                unset($data['country']);
            }
            if (strpos($errorMessage, 'exchange_rate') !== false) {
                unset($data['exchange_rate']);
            }
            if (strpos($errorMessage, 'notes') !== false) {
                unset($data['notes']);
            }
            if (strpos($errorMessage, 'photo_url') !== false) {
                unset($data['photo_url']);
            }
            
            try {
                $updated = $salaryModel->update($id, $data);
            } catch (\Exception $e2) {
                return $this->respond([
                    'success' => false,
                    'message' => 'فشل في تحديث الراتب: ' . $e2->getMessage()
                ], 500);
            }
        }

        if ($updated) {
            $updatedSalary = $salaryModel->find($id);
            return $this->respond([
                'success' => true,
                'message' => 'تم تحديث الراتب بنجاح',
                'data' => $updatedSalary
            ]);
        } else {
            $errors = $salaryModel->errors();
            return $this->respond([
                'success' => false,
                'message' => 'فشل في تحديث الراتب',
                'errors' => $errors
            ], 500);
        }
    }

    public function show($id = null)
    {
        if (!$id) {
            return $this->fail('معرف الراتب مطلوب', 400);
        }

        $salaryModel = new SalaryModel();
        $salary = $salaryModel->find($id);

        if (!$salary) {
            return $this->failNotFound('الراتب غير موجود');
        }

        if (!\App\Helpers\PermissionHelper::canViewNumbers()) {
            $salary['basic_salary'] = null;
            $salary['bonuses'] = null;
            $salary['deductions'] = null;
            $salary['net_salary'] = null;
            $salary['exchange_rate'] = null;
        }

        return $this->respond($salary);
    }

    public function delete($id = null)
    {
        if (!$id) {
            return $this->fail('معرف الراتب مطلوب', 400);
        }

        $salaryModel = new SalaryModel();
        
        if ($salaryModel->delete($id)) {
            return $this->respondDeleted(['message' => 'تم حذف الراتب بنجاح']);
        } else {
            return $this->fail('فشل في حذف الراتب', 500);
        }
    }

    public function stats()
    {
        $month = $this->request->getGet('month');
        $salaryModel = new SalaryModel();
        $stats = $salaryModel->getStats($month);

        if (!\App\Helpers\PermissionHelper::canViewNumbers()) {
            $stats = [
                'total_employees' => $stats['total_employees'] ?? 0,
            ];
        }

        return $this->respond($stats);
    }
}
