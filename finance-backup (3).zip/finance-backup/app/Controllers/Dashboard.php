<?php
namespace App\Controllers;
use App\Models\ClientModel;
class Dashboard extends BaseController
{
    private function checkAccess($requiredRole = 'admin')
    {
        $userRole = session()->get('role');
        if ($userRole !== $requiredRole && $userRole !== 'admin') {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('غير مصرح لك بالوصول إلى هذه الصفحة');
        }
    }

    private function isAdmin()
    {
        return session()->get('role') === 'admin';
    }

    public function index()
    {
        return redirect()->to('/dashboard/clients');
    }
    public function clients()
    {
        $clientModel = new ClientModel();
        $data = [
            'clients' => $clientModel->orderBy('date', 'DESC')->findAll(),
            'stats' => $clientModel->getStats(),
            'canViewFinancial' => $this->isAdmin()
        ];
        return view('dashboard/clients', $data);
    }
    
    public function yearlyReports()
    {
        $this->checkAccess('admin');
        
        $yearlyModel = new \App\Models\YearlyReportModel();
        
        
        $selectedYear = $this->request->getGet('year') ?? date('Y');
        
        
        $availableYears = $yearlyModel->getAvailableYears();
        
        
        $yearData = $yearlyModel->getYearlyData($selectedYear);
        
        
        $budgetData = $yearData['budget_data'] ?? null;
        
        if (is_string($budgetData)) {
            $budgetData = json_decode($budgetData, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                $budgetData = null;
            }
        }
        
        if (!is_array($budgetData) || empty($budgetData)) {
            $budgetData = [
                'salaries'     => 7800,
                'operational' => 4750,
                'marketing'   => 2850,
                'assets'      => 2300,
                'other'       => 1500
            ];
        }
        
        $yearData['budget_data'] = $budgetData;
        
        
        $data['selected_year'] = $selectedYear;
        $data['available_years'] = $availableYears;
        $data['revenue']     = $yearData['revenue'] ?? 34500;
        $data['expenses']    = $yearData['expenses'] ?? 18200;
        $data['profit']      = $yearData['profit'] ?? 16300;
        $data['monthly_avg'] = round($data['revenue'] / 12);
        
        
        $budgetItems = [
            'salaries'     => ['label' => 'الرواتب',             'planned' => 8000,  'actual' => $budgetData['salaries'] ?? 7800],
            'operational'  => ['label' => 'المصروفات التشغيلية', 'planned' => 4500,  'actual' => $budgetData['operational'] ?? 4750],
            'marketing'    => ['label' => 'التسويق والإعلان',     'planned' => 3000,  'actual' => $budgetData['marketing'] ?? 2850],
            'assets'       => ['label' => 'الموجودات والمعدات',   'planned' => 2500,  'actual' => $budgetData['assets'] ?? 2300],
            'other'        => ['label' => 'مصاريف أخرى',         'planned' => 1500,  'actual' => $budgetData['other'] ?? 1500],
        ];
        
        $table = [];
        foreach ($budgetItems as $item) {
            $deviation = $item['actual'] - $item['planned'];
            $percentage = $item['planned'] > 0 ? round(($item['actual'] / $item['planned']) * 100, 1) : 0;
            $table[] = [
                'label'          => $item['label'],
                'planned'        => $item['planned'],
                'actual'         => $item['actual'],
                'deviation'      => $deviation,
                'deviation_text' => $deviation > 0 ? '+' . $deviation : $deviation,
                'percentage'     => $percentage,
                'class'          => $deviation > 0 ? 'overdue' : ($deviation < 0 ? 'paid' : '')
            ];
        }
        
        $data['budget_table']  = $table;
        $data['budget_values'] = array_values($budgetData);
        
        return view('dashboard/yearly_reports', $data);
    }
    
    public function salaries()
{
    $salaryModel = new \App\Models\SalaryModel();

    
    $selectedMonth = $this->request->getGet('month') ?? date('Y-m');
    $selectedEmployee = $this->request->getGet('employee') ?? 'all';

    $data = [
        'salaries'        => $salaryModel->getSalaries($selectedMonth, $selectedEmployee),
        'stats'           => $salaryModel->getStats($selectedMonth),
        'selected_month'  => $selectedMonth,
        'selected_employee' => $selectedEmployee,
        'current_month'   => date('Y-m'),
        'canViewFinancial' => $this->isAdmin()
    ];

    return view('dashboard/salaries', $data);
}

    public function commitments()
{
    $commitmentModel = new \App\Models\CommitmentModel();

    $data = [
        'commitments' => $commitmentModel->orderBy('payment_day', 'ASC')->findAll(),
        'stats'       => $commitmentModel->getStats(),
        'canViewFinancial' => $this->isAdmin()
    ];

    return view('dashboard/commitments', $data);
}

public function assets()
{
    $assetModel = new \App\Models\AssetModel();

    $data = [
        'assets' => $assetModel->getAssets(),
        'stats'  => $assetModel->getStats(),
        'canViewFinancial' => $this->isAdmin()
    ];

    return view('dashboard/assets', $data);
}
}