<?php

namespace App\Helpers;

use CodeIgniter\Database\BaseConnection;

/**
 * Helper class for database operations
 */
class DatabaseHelper
{
    /**
     * Create users table if it doesn't exist
     * 
     * @param BaseConnection $db
     * @return bool
     */
    public static function createUsersTable(BaseConnection $db): bool
    {
        try {
            // Check if table exists
            $tables = $db->listTables();
            if (in_array('users', $tables)) {
                return true; // Table already exists
            }

            // Create users table
            $sql = "CREATE TABLE IF NOT EXISTS `users` (
              `id` int(11) NOT NULL AUTO_INCREMENT,
              `username` varchar(100) NOT NULL,
              `password` varchar(255) NOT NULL,
              `email` varchar(255) DEFAULT NULL,
              `full_name` varchar(255) DEFAULT NULL,
              `photo_url` varchar(500) DEFAULT NULL,
              `role` enum('admin','user') DEFAULT 'user',
              `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
              `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
              PRIMARY KEY (`id`),
              UNIQUE KEY `username` (`username`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

            $db->query($sql);

            $userModel = new \App\Models\UserModel();
            
            $adminUser = $userModel->where('username', 'admin')->first();
            if (!$adminUser) {
                $hashedPassword = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi';
                $userModel->insert([
                    'username' => 'admin',
                    'password' => $hashedPassword,
                    'email' => 'admin@finance.com',
                    'full_name' => 'مدير النظام',
                    'role' => 'admin'
                ]);
            }

            $employeeUser = $userModel->where('username', 'employee')->first();
            if (!$employeeUser) {
                $hashedPassword = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi';
                $userModel->insert([
                    'username' => 'employee',
                    'password' => $hashedPassword,
                    'email' => 'employee@finance.com',
                    'full_name' => 'موظف النظام',
                    'role' => 'user'
                ]);
            }

            return true;
        } catch (\Exception $e) {
            log_message('error', 'Failed to create users table: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Check if users table exists
     * 
     * @param BaseConnection $db
     * @return bool
     */
    public static function usersTableExists(BaseConnection $db): bool
    {
        try {
            $tables = $db->listTables();
            return in_array('users', $tables);
        } catch (\Exception $e) {
            log_message('error', 'Failed to check users table: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Create monthly_reports table if it doesn't exist
     * 
     * @param BaseConnection $db
     * @return bool
     */
    public static function createMonthlyReportsTable(BaseConnection $db): bool
    {
        try {
            // Check if table exists
            $tables = $db->listTables();
            if (in_array('monthly_reports', $tables)) {
                return true; // Table already exists
            }

            // Create monthly_reports table
            $sql = "CREATE TABLE IF NOT EXISTS `monthly_reports` (
              `id` int(11) NOT NULL AUTO_INCREMENT,
              `year` int(4) NOT NULL,
              `month` int(2) NOT NULL,
              `total_income` decimal(10,2) DEFAULT '0.00',
              `total_expenses` decimal(10,2) DEFAULT '0.00',
              `net_profit` decimal(10,2) DEFAULT '0.00',
              `income_details` json DEFAULT NULL,
              `expense_details` json DEFAULT NULL,
              `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
              `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
              PRIMARY KEY (`id`),
              UNIQUE KEY `year_month` (`year`, `month`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

            $db->query($sql);

            return true;
        } catch (\Exception $e) {
            log_message('error', 'Failed to create monthly_reports table: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Check if monthly_reports table exists
     * 
     * @param BaseConnection $db
     * @return bool
     */
    public static function monthlyReportsTableExists(BaseConnection $db): bool
    {
        try {
            $tables = $db->listTables();
            return in_array('monthly_reports', $tables);
        } catch (\Exception $e) {
            log_message('error', 'Failed to check monthly_reports table: ' . $e->getMessage());
            return false;
        }
    }
}
