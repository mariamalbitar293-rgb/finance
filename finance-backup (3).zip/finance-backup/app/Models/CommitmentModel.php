<?php

namespace App\Models;

use CodeIgniter\Model;
use CodeIgniter\Database\ConnectionInterface;
use CodeIgniter\Validation\ValidationInterface;

class CommitmentModel extends Model
{
    protected $table = 'commitments';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'name', 'type', 'category', 'amount', 'annual_amount', 'received_amount', 
        'payment_day', 'start_date', 'end_date', 'recipient', 'status', 'notes', 
        'paid_amount', 'monthly_payment', 'loan_start_date', 'image_url'
    ];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    public function __construct(?ConnectionInterface $db = null, ?ValidationInterface $validation = null)
    {
        parent::__construct($db, $validation);
        $this->ensureSchema();
    }

    private function ensureSchema(): void
    {
        try {
            $db = $this->db;
            if (!$db) {
                return;
            }

            $forge = \Config\Database::forge($db);
            $table = $this->table;

            if (!$db->fieldExists('category', $table)) {
                $forge->addColumn($table, [
                    'category' => [
                        'type' => 'VARCHAR',
                        'constraint' => 100,
                        'null' => true,
                        'after' => 'type'
                    ]
                ]);
            }
            
            if (!$db->fieldExists('loan_start_date', $table)) {
                $forge->addColumn($table, [
                    'loan_start_date' => [
                        'type' => 'DATE',
                        'null' => true,
                        'after' => 'end_date'
                    ]
                ]);
            }
            
            if (!$db->fieldExists('annual_amount', $table)) {
                $forge->addColumn($table, [
                    'annual_amount' => [
                        'type' => 'DECIMAL',
                        'constraint' => '10,2',
                        'null' => true,
                        'after' => 'amount'
                    ]
                ]);
            }
            
            if (!$db->fieldExists('received_amount', $table)) {
                $forge->addColumn($table, [
                    'received_amount' => [
                        'type' => 'DECIMAL',
                        'constraint' => '10,2',
                        'null' => true,
                        'default' => '0.00',
                        'after' => 'annual_amount'
                    ]
                ]);
            }
            
            if (!$db->fieldExists('image_url', $table)) {
                $forge->addColumn($table, [
                    'image_url' => [
                        'type' => 'VARCHAR',
                        'constraint' => 500,
                        'null' => true,
                        'after' => 'notes'
                    ]
                ]);
            }
        } catch (\Exception $e) {
            log_message('error', 'Failed to ensure commitments table schema: ' . $e->getMessage());
        }
    }

    
    public function getCommitments()
    {
        return $this->orderBy('payment_day', 'ASC')->findAll();
    }

    
    public function getStats()
    {
        $builder = $this->builder();

        $monthly = $builder->selectSum('amount', 'total')
                          ->where('type', 'monthly')
                          ->where('status', 'active')
                          ->get()
                          ->getRowArray();

        $debts = $builder->select('SUM(amount) as total, SUM(paid_amount) as paid')
                        ->where('type', 'debt')
                        ->where('status', 'active')
                        ->get()
                        ->getRowArray();

        $deductions = $builder->selectSum('amount', 'total')
                             ->whereIn('type', ['deduction', 'yearly'])
                             ->where('status', 'active')
                             ->get()
                             ->getRowArray();

        $activeCount = $builder->where('status', 'active')->countAllResults();

        return [
            'total_monthly'     => $monthly['total'] ?? 0,
            'total_debts'       => ($debts['total'] ?? 0) - ($debts['paid'] ?? 0),
            'total_deductions'  => $deductions['total'] ?? 0,
            'active_count'      => $activeCount
        ];
    }
}