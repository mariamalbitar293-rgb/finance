<?php

namespace App\Models;

use CodeIgniter\Database\ConnectionInterface;
use CodeIgniter\Model;
use CodeIgniter\Validation\ValidationInterface;

class SalaryModel extends Model
{
    protected $table = 'salaries';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'employee_name', 'position', 'country', 'exchange_rate', 'basic_salary', 'bonuses', 
        'deductions', 'net_salary', 'payment_date', 'status', 'notes', 'photo_url'
    ];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    public function __construct(?ConnectionInterface $db = null, ?ValidationInterface $validation = null)
    {
        parent::__construct($db, $validation);
        $this->ensureSchema();
    }

    private function ensureSchema(): void
    {
        try {
            $db = $this->db;
            if (!$db) {
                return;
            }

            $forge = \Config\Database::forge($db);
            $table = $this->table;

            if (!$db->fieldExists('position', $table)) {
                $forge->addColumn($table, [
                    'position' => [
                        'type' => 'VARCHAR',
                        'constraint' => 255,
                        'null' => true,
                    ],
                ]);
            }

            if (!$db->fieldExists('country', $table)) {
                $forge->addColumn($table, [
                    'country' => [
                        'type' => 'VARCHAR',
                        'constraint' => 100,
                        'null' => true,
                    ],
                ]);
            }

            if (!$db->fieldExists('exchange_rate', $table)) {
                $forge->addColumn($table, [
                    'exchange_rate' => [
                        'type' => 'DECIMAL',
                        'constraint' => '10,4',
                        'null' => true,
                    ],
                ]);
            }
        } catch (\Throwable $e) {
            
        }
    }

    
    public function getSalaries($month = null, $employee = null)
    {
        $builder = $this->builder();
        
        $builder->select('*');

        if ($month) {
            $builder->like('payment_date', $month . '%');
        }

        if ($employee && $employee !== 'all') {
            $builder->where('employee_name', $employee);
        }

        $builder->orderBy('payment_date', 'DESC');

        $results = $builder->get()->getResultArray();
        
        foreach ($results as &$result) {
            if (!isset($result['position'])) {
                $result['position'] = null;
            }
            if (!isset($result['country'])) {
                $result['country'] = null;
            }
            if (!isset($result['exchange_rate'])) {
                $result['exchange_rate'] = null;
            }
        }
        
        return $results;
    }

    
    public function getStats($month = null)
    {
        $builder = $this->builder();

        if ($month) {
            $builder->like('payment_date', $month . '%');
        }

        $result = $builder->selectSum('basic_salary', 'total_basic')
                          ->selectSum('bonuses', 'total_bonuses')
                          ->selectSum('deductions', 'total_deductions')
                          ->selectSum('net_salary', 'total_net')
                          ->selectCount('id', 'total_employees')
                          ->selectAvg('net_salary', 'avg_salary')
                          ->get()
                          ->getRowArray();

        return [
            'total_employees'   => $result['total_employees'] ?? 0,
            'total_basic'       => $result['total_basic'] ?? 0,
            'total_bonuses'     => $result['total_bonuses'] ?? 0,
            'total_deductions'  => $result['total_deductions'] ?? 0,
            'total_net'         => $result['total_net'] ?? 0,
            'avg_salary'        => $result['avg_salary'] ? round($result['avg_salary'], 2) : 0
        ];
    }
}