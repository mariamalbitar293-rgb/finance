USE `financial_system`;

CREATE TABLE IF NOT EXISTS `monthly_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `year` int(4) NOT NULL,
  `month` int(2) NOT NULL,
  `total_income` decimal(10,2) DEFAULT '0.00',
  `total_expenses` decimal(10,2) DEFAULT '0.00',
  `net_profit` decimal(10,2) DEFAULT '0.00',
  `income_details` json DEFAULT NULL,
  `expense_details` json DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `year_month` (`year`, `month`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SELECT '✓ جدول monthly_reports تم إنشاؤه بنجاح!' AS 'النتيجة';
