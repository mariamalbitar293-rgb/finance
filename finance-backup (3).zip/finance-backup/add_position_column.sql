USE `financial_system`;

ALTER TABLE `salaries` 
ADD COLUMN IF NOT EXISTS `position` varchar(255) DEFAULT NULL AFTER `employee_name`;

