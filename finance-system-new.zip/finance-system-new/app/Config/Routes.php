<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
// الصفحة الرئيسية تذهب إلى لوحة التحكم
$routes->get('/', 'Main::index');

// لوحة التحكم الرئيسية
$routes->get('dashboard', 'Dashboard::index');
$routes->get('dashboard/', 'Dashboard::index');

// الصفحات الفرعية
$routes->get('dashboard/clients', 'Dashboard::clients');
$routes->get('dashboard/yearlyReports', 'Dashboard::yearlyReports');
$routes->get('dashboard/salaries', 'Dashboard::salaries');
$routes->get('dashboard/commitments', 'Dashboard::commitments');
$routes->get('dashboard/assets', 'Dashboard::assets');
