<?php

namespace App\Controllers;

class Dashboard extends BaseController
{


    public function clients()
    {
        return view('dashboard/clients');
    }

    public function yearlyReports()
    {
        return view('dashboard/yearly_reports'); // اسم الملف بالضبط
    }

    public function salaries()
    {
        return view('dashboard/salaries');
    }

    public function commitments()
    {
        return view('dashboard/commitments');
    }

    public function assets()
    {
        return view('dashboard/assets');
    }
}