<?php

namespace App\Controllers;

class Main extends BaseController
{
    public function index()
    {
        return view('main'); // أو 'auth/login' أو 'pages/main' حسب مكان الملف
    }
}