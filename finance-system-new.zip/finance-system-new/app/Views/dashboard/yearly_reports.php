<?= $this->extend('layouts/main') ?>

<?= $this->section('title') ?>
التقارير السنوية والموازنات
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="section-header">
    <h2><i class="fas fa-chart-bar"></i> التقارير السنوية والموازنات</h2>
    <div class="controls">
        <button class="btn btn-primary" id="exportYearlyBtn">
            <i class="fas fa-download"></i> تصدير التقرير
        </button>
        <button class="btn btn-success" id="toggleChartsBtn">
            <i class="fas fa-chart-pie"></i> عرض الرسوم البيانية
        </button>
    </div>
</div>

<!-- فلترة السنوات -->
<div class="table-container" style="margin-bottom: 25px;">
    <div class="table-header">
        <div class="search-filter">
            <button class="btn btn-primary year-btn active" data-year="2025">2025</button>
            <button class="btn btn-secondary year-btn" data-year="2024">2024</button>
            <button class="btn btn-secondary year-btn" data-year="2023">2023</button>
            <button class="btn btn-secondary year-btn" data-year="2022">2022</button>
            <button class="btn btn-secondary year-btn" data-year="2021">2021</button>
        </div>
    </div>
</div>

<!-- الإحصائيات السنوية -->
<div class="stats-cards">
    <div class="stat-card card-1">
        <div class="stat-info">
            <h3>إجمالي الإيرادات السنوية</h3>
            <div class="value">34,500 <span style="font-size: 1rem;">دينار</span></div>
            <div style="font-size: 0.8rem; color: var(--primary-color); margin-top: 5px;">↑ 12% عن العام الماضي</div>
        </div>
        <div class="stat-icon">
            <i class="fas fa-chart-line"></i>
        </div>
    </div>
    
    <div class="stat-card card-2">
        <div class="stat-info">
            <h3>إجمالي المصروفات</h3>
            <div class="value">18,200 <span style="font-size: 1rem;">دينار</span></div>
            <div style="font-size: 0.8rem; color: var(--success-color); margin-top: 5px;">↓ 5% عن العام الماضي</div>
        </div>
        <div class="stat-icon">
            <i class="fas fa-receipt"></i>
        </div>
    </div>
    
    <div class="stat-card card-3">
        <div class="stat-info">
            <h3>صافي الأرباح</h3>
            <div class="value">16,300 <span style="font-size: 1rem;">دينار</span></div>
            <div style="font-size: 0.8rem; color: var(--accent-color); margin-top: 5px;">↑ 18% عن العام الماضي</div>
        </div>
        <div class="stat-icon">
            <i class="fas fa-hand-holding-usd"></i>
        </div>
    </div>
    
    <div class="stat-card card-4">
        <div class="stat-info">
            <h3>متوسط المبيعات الشهرية</h3>
            <div class="value">2,875 <span style="font-size: 1rem;">دينار</span></div>
            <div style="font-size: 0.8rem; color: var(--warning-color); margin-top: 5px;">↑ 8% عن العام الماضي</div>
        </div>
        <div class="stat-icon">
            <i class="fas fa-shopping-cart"></i>
        </div>
    </div>
</div>

<!-- الرسوم البيانية -->
<div id="chartsSection">
    <div class="charts-container">
        <div class="chart-card">
            <h3><i class="fas fa-chart-pie"></i> توزيع الميزانية السنوية</h3>
            <div class="chart-wrapper">
                <canvas id="budgetChart"></canvas>
            </div>
        </div>
        
        <div class="chart-card">
            <h3><i class="fas fa-chart-line"></i> الإيرادات والمصروفات خلال العام</h3>
            <div class="chart-wrapper">
                <canvas id="revenueExpenseChart"></canvas>
            </div>
        </div>
    </div>
</div>

<!-- جدول الميزانية -->
<div class="table-container">
    <div class="table-header">
        <h3 style="margin: 0; color: var(--dark-color);"><i class="fas fa-balance-scale"></i> الميزانية السنوية</h3>
    </div>
    
    <table>
        <thead>
            <tr>
                <th>البند</th>
                <th>الميزانية المخطط لها</th>
                <th>المصروف الفعلي</th>
                <th>الانحراف</th>
                <th>النسبة</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>الرواتب</td>
                <td>8,000 دينار</td>
                <td>7,800 دينار</td>
                <td class="status paid">-200 دينار</td>
                <td>97.5%</td>
            </tr>
            <tr>
                <td>المصروفات التشغيلية</td>
                <td>4,500 دينار</td>
                <td>4,750 دينار</td>
                <td class="status overdue">+250 دينار</td>
                <td>105.6%</td>
            </tr>
            <tr>
                <td>التسويق والإعلان</td>
                <td>3,000 دينار</td>
                <td>2,850 دينار</td>
                <td class="status paid">-150 دينار</td>
                <td>95%</td>
            </tr>
            <tr>
                <td>الموجودات والمعدات</td>
                <td>2,500 دينار</td>
                <td>2,300 دينار</td>
                <td class="status paid">-200 دينار</td>
                <td>92%</td>
            </tr>
            <tr>
                <td>مصاريف أخرى</td>
                <td>1,500 دينار</td>
                <td>1,500 دينار</td>
                <td>0 دينار</td>
                <td>100%</td>
            </tr>
        </tbody>
    </table>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize yearly charts
    initYearlyCharts();
    
    // Year buttons event listeners
    document.querySelectorAll('.year-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.year-btn').forEach(b => {
                b.classList.remove('active');
                b.classList.remove('btn-primary');
                b.classList.add('btn-secondary');
            });
            this.classList.add('active');
            this.classList.remove('btn-secondary');
            this.classList.add('btn-primary');
            
            const year = this.getAttribute('data-year');
            updateYearlyData(year);
        });
    });
    
    // Export button
    document.getElementById('exportYearlyBtn')?.addEventListener('click', function() {
        showNotification('جارٍ تصدير التقرير السنوي إلى ملف PDF...');
    });
    
    // Toggle charts button
    document.getElementById('toggleChartsBtn')?.addEventListener('click', function() {
        const chartsSection = document.getElementById('chartsSection');
        if (chartsSection.style.display === 'none') {
            chartsSection.style.display = 'block';
            this.innerHTML = '<i class="fas fa-chart-pie"></i> إخفاء الرسوم البيانية';
        } else {
            chartsSection.style.display = 'none';
            this.innerHTML = '<i class="fas fa-chart-pie"></i> عرض الرسوم البيانية';
        }
    });
});

function initYearlyCharts() {
    // مخطط توزيع الميزانية (دونات)
    const budgetCtx = document.getElementById('budgetChart');
    if (budgetCtx) {
        new Chart(budgetCtx.getContext('2d'), {
            type: 'doughnut',
            data: {
                labels: ['الرواتب', 'المصروفات التشغيلية', 'التسويق والإعلان', 'الموجودات والمعدات', 'مصاريف أخرى'],
                datasets: [{
                    data: [7800, 4750, 2850, 2300, 1500],
                    backgroundColor: [
                        'var(--primary-color)',
                        'var(--success-color)',
                        'var(--danger-color)',
                        'var(--warning-color)',
                        'var(--accent-color)'
                    ],
                    borderWidth: 2,
                    borderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        rtl: true,
                        labels: {
                            font: {
                                family: "'Cairo', sans-serif",
                                size: 12
                            },
                            padding: 20
                        }
                    },
                    tooltip: {
                        rtl: true,
                        callbacks: {
                            label: function(context) {
                                let label = context.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                label += context.parsed.toLocaleString() + ' دينار';
                                return label;
                            }
                        }
                    }
                },
                animation: {
                    animateScale: true,
                    animateRotate: true,
                    duration: 1000
                }
            }
        });
    }
    
    // مخطط الإيرادات والمصروفات خلال العام
    const revenueCtx = document.getElementById('revenueExpenseChart');
    if (revenueCtx) {
        new Chart(revenueCtx.getContext('2d'), {
            type: 'line',
            data: {
                labels: ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'],
                datasets: [
                    {
                        label: 'الإيرادات',
                        data: [2500, 2800, 3000, 3200, 2900, 3100, 3400, 3600, 3300, 3500, 3700, 3800],
                        borderColor: 'var(--success-color)',
                        backgroundColor: 'rgba(46, 204, 113, 0.1)',
                        borderWidth: 3,
                        fill: true,
                        tension: 0.3
                    },
                    {
                        label: 'المصروفات',
                        data: [1400, 1500, 1600, 1700, 1550, 1650, 1800, 1900, 1750, 1850, 1950, 2000],
                        borderColor: 'var(--danger-color)',
                        backgroundColor: 'rgba(231, 76, 60, 0.1)',
                        borderWidth: 3,
                        fill: true,
                        tension: 0.3
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                        rtl: true,
                        labels: {
                            font: {
                                family: "'Cairo', sans-serif",
                                size: 12
                            }
                        }
                    },
                    tooltip: {
                        rtl: true,
                        callbacks: {
                            label: function(context) {
                                let label = context.dataset.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                label += context.parsed.y.toLocaleString() + ' دينار';
                                return label;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return value.toLocaleString() + ' دينار';
                            }
                        }
                    }
                },
                animation: {
                    duration: 1500,
                    easing: 'easeInOutQuart'
                }
            }
        });
    }
}

function updateYearlyData(year) {
    // في تطبيق حقيقي، هنا ستجلب البيانات من الخادم حسب السنة
    showNotification(`جارٍ تحديث بيانات سنة ${year}...`);
}
</script>

<?= $this->endSection() ?>