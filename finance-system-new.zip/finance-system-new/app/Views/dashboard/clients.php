<?= $this->extend('layouts/main') ?>

<?= $this->section('title') ?>
العملاء
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="content-wrapper">
    <div class="content-header">
        <div class="header-actions">
            <div class="search-box">
                <i class="fas fa-search"></i>
                <input type="text" id="clientSearch" placeholder="ابحث عن عميل بالاسم أو رقم الهاتف...">
            </div>
            
            <div class="filter-box" style="margin-right: 15px;">
                <select id="statusFilter" class="form-select">
                    <option value="all">جميع الحالات</option>
                    <option value="paid">مسددون بالكامل</option>
                    <option value="partial">مسددون جزئياً</option>
                    <option value="pending">غير مسددين</option>
                </select>
            </div>
            
            <div class="action-buttons">
                <button class="btn btn-primary" id="addClientBtn">
                    <i class="fas fa-user-plus"></i> إضافة عميل
                </button>
                <button class="btn btn-secondary" id="exportClientsBtn">
                    <i class="fas fa-download"></i> تصدير
                </button>
            </div>
        </div>
    </div>
    
    <div class="content-body">
        <div class="stats-cards">
            <div class="stat-card">
                <div class="stat-icon" style="background-color: rgba(41, 128, 185, 0.1); color: #2980b9;">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-info">
                    <h3 id="totalClients">8</h3>
                    <span>إجمالي العملاء</span>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon" style="background-color: rgba(39, 174, 96, 0.1); color: #27ae60;">
                    <i class="fas fa-money-bill-wave"></i>
                </div>
                <div class="stat-info">
                    <h3 id="totalPrincipal">2,800</h3>
                    <span>إجمالي المبالغ</span>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon" style="background-color: rgba(52, 152, 219, 0.1); color: #3498db;">
                    <i class="fas fa-hand-holding-usd"></i>
                </div>
                <div class="stat-info">
                    <h3 id="totalPaid">1,850</h3>
                    <span>إجمالي المدفوع</span>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon" style="background-color: rgba(231, 76, 60, 0.1); color: #e74c3c;">
                    <i class="fas fa-exclamation-triangle"></i>
                </div>
                <div class="stat-info">
                    <h3 id="totalRemaining">950</h3>
                    <span>إجمالي المتبقي</span>
                </div>
            </div>
        </div>
        
        <div class="main-card">
            <div class="card-header">
                <h3><i class="fas fa-list"></i> قائمة العملاء</h3>
                <div class="card-actions">
                    <button class="btn-icon" id="refreshClientsBtn" title="تحديث">
                        <i class="fas fa-sync-alt"></i>
                    </button>
                    <button class="btn-icon" id="printClientsBtn" title="طباعة">
                        <i class="fas fa-print"></i>
                    </button>
                </div>
            </div>
            
            <div class="card-body">
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>اسم العميل</th>
                                <th>المبلغ الأساسي</th>
                                <th>المسدد</th>
                                <th>المتبقي</th>
                                <th>ملاحظات</th>
                                <th>التاريخ</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody id="clientsTableBody">
                            <!-- سيتم تعبئة البيانات من JavaScript -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// تهيئة صفحة العملاء
document.addEventListener('DOMContentLoaded', function() {
    // تحديث الإحصائيات أولاً
    updateClientsStats();
    
    // عرض بيانات العملاء
    renderClientsTable();
    
    // إعداد مستمعي الأحداث
    setupClientsEventListeners();
});

// تحديث الإحصائيات
function updateClientsStats() {
    // هذه البيانات ستأتي من الخادم في التطبيق الحقيقي
    document.getElementById('clientBadge').textContent = '8';
    
    // إضافة حدث تحديث الزر
    document.getElementById('refreshClientsBtn')?.addEventListener('click', function() {
        renderClientsTable();
        showNotification('تم تحديث بيانات العملاء');
    });
}
</script>

<?= $this->endSection() ?>