<?= $this->extend('layouts/main') ?>

<?= $this->section('title') ?>
الأصول الثابتة
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="section-header">
    <h2><i class="fas fa-server"></i> الأصول الثابتة</h2>
    <div class="controls">
        <button class="btn btn-primary" id="addAssetBtn">
            <i class="fas fa-plus"></i> إضافة أصل جديد
        </button>
        <button class="btn btn-secondary" id="printAssetsBtn">
            <i class="fas fa-print"></i> طباعة التقرير
        </button>
        <button class="btn btn-success" id="exportAssetsBtn">
            <i class="fas fa-file-export"></i> تصدير البيانات
        </button>
    </div>
</div>

<!-- إحصائيات الأصول الثابتة -->
<div class="stats-cards">
    <div class="stat-card card-1">
        <div class="stat-info">
            <h3>إجمالي قيمة الأصول</h3>
            <div class="value">245,000 <span style="font-size: 1rem;">دينار</span></div>
            <div style="font-size: 0.8rem; color: var(--primary-color); margin-top: 5px;">↑ 15% عن العام الماضي</div>
        </div>
        <div class="stat-icon">
            <i class="fas fa-building"></i>
        </div>
    </div>
    
    <div class="stat-card card-2">
        <div class="stat-info">
            <h3>القيمة السوقية</h3>
            <div class="value">310,000 <span style="font-size: 1rem;">دينار</span></div>
            <div style="font-size: 0.8rem; color: var(--success-color); margin-top: 5px;">↑ 22% عن القيمة الدفترية</div>
        </div>
        <div class="stat-icon">
            <i class="fas fa-chart-line"></i>
        </div>
    </div>
    
    <div class="stat-card card-3">
        <div class="stat-info">
            <h3>عدد الأصول النشطة</h3>
            <div class="value" id="activeAssets">12</div>
            <div style="font-size: 0.8rem; color: var(--accent-color); margin-top: 5px;">3 أصول تحت الصيانة</div>
        </div>
        <div class="stat-icon">
            <i class="fas fa-server"></i>
        </div>
    </div>
    
    <div class="stat-card card-4">
        <div class="stat-info">
            <h3>الإهلاك السنوي</h3>
            <div class="value">15,400 <span style="font-size: 1rem;">دينار</span></div>
            <div style="font-size: 0.8rem; color: var(--warning-color); margin-top: 5px;">معدل إهلاك 8.5% سنوياً</div>
        </div>
        <div class="stat-icon">
            <i class="fas fa-percentage"></i>
        </div>
    </div>
</div>

<!-- البحث والفلترة -->
<div class="table-container" style="margin-bottom: 25px;">
    <div class="table-header">
        <div class="search-filter">
            <select class="filter-select" id="assetTypeFilter">
                <option value="all">جميع أنواع الأصول</option>
                <option value="servers">السيرفرات</option>
                <option value="equipment">المعدات</option>
                <option value="property">العقارات</option>
                <option value="vehicles">المركبات</option>
                <option value="other">أخرى</option>
            </select>
            <input type="text" class="search-box" id="assetSearch" placeholder="ابحث عن أصل بالاسم أو الرقم التسلسلي...">
            <button class="btn btn-success" id="searchAssetsBtn">
                <i class="fas fa-search"></i> بحث
            </button>
        </div>
    </div>
</div>

<!-- شبكة بطاقات الأصول -->
<div class="assets-grid">
    <div class="asset-card">
        <div class="asset-image">
            <i class="fas fa-server"></i>
        </div>
        <div class="asset-details">
            <h3>سيرفرات البيانات الرئيسية</h3>
            <div class="asset-meta">
                <span><i class="fas fa-hdd"></i> رقم: SRV-001</span>
                <span><i class="fas fa-calendar"></i> 2023</span>
            </div>
            <div class="asset-value">85,000 دينار</div>
            <div class="asset-meta">
                <span><strong>القيمة السوقية:</strong> 95,000 دينار</span>
                <span class="asset-status active">نشط</span>
            </div>
        </div>
    </div>
    
    <div class="asset-card">
        <div class="asset-image">
            <i class="fas fa-server"></i>
        </div>
        <div class="asset-details">
            <h3>سيرفر النسخ الاحتياطي</h3>
            <div class="asset-meta">
                <span><i class="fas fa-hdd"></i> رقم: SRV-002</span>
                <span><i class="fas fa-calendar"></i> 2022</span>
            </div>
            <div class="asset-value">45,000 دينار</div>
            <div class="asset-meta">
                <span><strong>القيمة السوقية:</strong> 38,000 دينار</span>
                <span class="asset-status active">نشط</span>
            </div>
        </div>
    </div>
    
    <div class="asset-card">
        <div class="asset-image">
            <i class="fas fa-network-wired"></i>
        </div>
        <div class="asset-details">
            <h3>معدات الشبكة والاتصال</h3>
            <div class="asset-meta">
                <span><i class="fas fa-network-wired"></i> رقم: NET-001</span>
                <span><i class="fas fa-calendar"></i> 2024</span>
            </div>
            <div class="asset-value">28,500 دينار</div>
            <div class="asset-meta">
                <span><strong>القيمة السوقية:</strong> 32,000 دينار</span>
                <span class="asset-status active">نشط</span>
            </div>
        </div>
    </div>
    
    <div class="asset-card">
        <div class="asset-image">
            <i class="fas fa-building"></i>
        </div>
        <div class="asset-details">
            <h3>مبنى المقر الرئيسي</h3>
            <div class="asset-meta">
                <span><i class="fas fa-building"></i> رقم: BLD-001</span>
                <span><i class="fas fa-calendar"></i> 2020</span>
            </div>
            <div class="asset-value">120,000 دينار</div>
            <div class="asset-meta">
                <span><strong>القيمة السوقية:</strong> 185,000 دينار</span>
                <span class="asset-status active">نشط</span>
            </div>
        </div>
    </div>
</div>

<!-- جدول الأصول الثابتة -->
<div class="table-container">
    <div class="table-header">
        <h3 style="margin: 0; color: var(--dark-color);"><i class="fas fa-list"></i> جميع الأصول الثابتة</h3>
    </div>
    
    <table>
        <thead>
            <tr>
                <th>اسم الأصل</th>
                <th>النوع</th>
                <th>رقم التسلسلي</th>
                <th>القيمة الدفترية</th>
                <th>القيمة السوقية</th>
                <th>تاريخ الشراء</th>
                <th>الحالة</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>سيرفرات البيانات الرئيسية</td>
                <td>سيرفرات</td>
                <td>SRV-001</td>
                <td>85,000 دينار</td>
                <td>95,000 دينار</td>
                <td>2023-05-15</td>
                <td><span class="asset-status active">نشط</span></td>
            </tr>
            <tr>
                <td>سيرفر النسخ الاحتياطي</td>
                <td>سيرفرات</td>
                <td>SRV-002</td>
                <td>45,000 دينار</td>
                <td>38,000 دينار</td>
                <td>2022-08-22</td>
                <td><span class="asset-status active">نشط</span></td>
            </tr>
            <tr>
                <td>معدات الشبكة والاتصال</td>
                <td>معدات</td>
                <td>NET-001</td>
                <td>28,500 دينار</td>
                <td>32,000 دينار</td>
                <td>2024-01-10</td>
                <td><span class="asset-status active">نشط</span></td>
            </tr>
            <tr>
                <td>مبنى المقر الرئيسي</td>
                <td>عقارات</td>
                <td>BLD-001</td>
                <td>120,000 دينار</td>
                <td>185,000 دينار</td>
                <td>2020-03-05</td>
                <td><span class="asset-status active">نشط</span></td>
            </tr>
            <tr>
                <td>سيارات الشركة</td>
                <td>مركبات</td>
                <td>CAR-001</td>
                <td>35,000 دينار</td>
                <td>28,000 دينار</td>
                <td>2021-11-18</td>
                <td><span class="asset-status active">نشط</span></td>
            </tr>
            <tr>
                <td>أجهزة الكمبيوتر المكتبية</td>
                <td>معدات</td>
                <td>COM-001</td>
                <td>15,000 دينار</td>
                <td>12,000 دينار</td>
                <td>2023-09-12</td>
                <td><span class="asset-status active">نشط</span></td>
            </tr>
        </tbody>
    </table>
</div>

<!-- نافذة إضافة أصل جديد -->
<div class="modal-overlay" id="addAssetModal">
    <div class="modal">
        <div style="padding: 25px; border-bottom: 1px solid #f0f0f0; display: flex; justify-content: space-between; align-items: center;">
            <h2 style="color: var(--dark-color); margin: 0; display: flex; align-items: center; gap: 10px;">
                <i class="fas fa-plus-circle"></i> إضافة أصل جديد
            </h2>
            <button style="background: none; border: none; font-size: 1.5rem; color: var(--gray-color); cursor: pointer;" id="closeAssetModalBtn">&times;</button>
        </div>
        
        <div style="padding: 25px; max-height: 70vh; overflow-y: auto;">
            <form id="addAssetForm">
                <div style="display: flex; gap: 20px; margin-bottom: 25px; flex-wrap: wrap;">
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">اسم الأصل</label>
                        <input type="text" id="assetName" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" placeholder="أدخل اسم الأصل" required>
                    </div>
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">نوع الأصل</label>
                        <select id="assetType" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;">
                            <option value="servers">سيرفرات</option>
                            <option value="equipment">معدات</option>
                            <option value="property">عقارات</option>
                            <option value="vehicles">مركبات</option>
                            <option value="other">أخرى</option>
                        </select>
                    </div>
                </div>
                
                <div style="display: flex; gap: 20px; margin-bottom: 25px; flex-wrap: wrap;">
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">رقم التسلسلي</label>
                        <input type="text" id="assetSerial" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" placeholder="رقم تسلسلي فريد" required>
                    </div>
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">تاريخ الشراء</label>
                        <input type="date" id="purchaseDate" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" required>
                    </div>
                </div>
                
                <div style="display: flex; gap: 20px; margin-bottom: 25px; flex-wrap: wrap;">
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">القيمة الدفترية (دينار)</label>
                        <input type="number" id="bookValue" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" placeholder="القيمة الدفترية للأصل" required min="1">
                    </div>
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">القيمة السوقية (دينار)</label>
                        <input type="number" id="marketValue" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" placeholder="القيمة السوقية الحالية" required min="1">
                    </div>
                </div>
                
                <div style="display: flex; gap: 20px; margin-bottom: 25px; flex-wrap: wrap;">
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">معدل الإهلاك السنوي (%)</label>
                        <input type="number" id="depreciationRate" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" placeholder="معدل الإهلاك السنوي" min="0" max="100" step="0.1" value="10">
                    </div>
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">الحالة</label>
                        <select id="assetStatus" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;">
                            <option value="active">نشط</option>
                            <option value="inactive">غير نشط</option>
                            <option value="maintenance">تحت الصيانة</option>
                        </select>
                    </div>
                </div>
                
                <div style="margin-bottom: 25px;">
                    <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">وصف الأصل</label>
                    <textarea id="assetDescription" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease; min-height: 100px;" placeholder="أضف وصفاً مفصلاً للأصل..."></textarea>
                </div>
                
                <div style="margin-bottom: 25px;">
                    <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">رابط صورة الأصل (اختياري)</label>
                    <input type="url" id="assetImageUrl" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" placeholder="https://example.com/image.jpg">
                </div>
            </form>
        </div>
        
        <div style="padding: 20px 25px; background-color: #f8f9fa; display: flex; justify-content: flex-end; gap: 15px; border-top: 1px solid #f0f0f0;">
            <button class="btn btn-secondary" id="cancelAddAssetBtn">إلغاء</button>
            <button class="btn btn-success" id="saveAssetBtn">
                <i class="fas fa-save"></i> حفظ الأصل
            </button>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Set default date
    document.getElementById('purchaseDate').valueAsDate = new Date();
    
    // Event listeners
    document.getElementById('addAssetBtn')?.addEventListener('click', openAddAssetModal);
    document.getElementById('closeAssetModalBtn')?.addEventListener('click', closeAddAssetModal);
    document.getElementById('cancelAddAssetBtn')?.addEventListener('click', closeAddAssetModal);
    document.getElementById('printAssetsBtn')?.addEventListener('click', function() {
        window.print();
        showNotification('جارٍ تحضير تقرير الأصول للطباعة...');
    });
    document.getElementById('exportAssetsBtn')?.addEventListener('click', function() {
        showNotification('جارٍ تصدير بيانات الأصول إلى ملف Excel...');
    });
    document.getElementById('searchAssetsBtn')?.addEventListener('click', function() {
        const type = document.getElementById('assetTypeFilter').value;
        const search = document.getElementById('assetSearch').value;
        showNotification(`جارٍ البحث عن الأصول: ${type === 'all' ? 'جميع الأنواع' : type} - "${search}"`);
    });
    document.getElementById('saveAssetBtn')?.addEventListener('click', saveNewAsset);
    
    // Close modal when clicking outside
    document.getElementById('addAssetModal')?.addEventListener('click', function(e) {
        if (e.target === this) {
            closeAddAssetModal();
        }
    });
});

function openAddAssetModal() {
    document.getElementById('addAssetModal').style.display = 'flex';
    document.getElementById('assetName').focus();
    showNotification('فتح نموذج إضافة أصل جديد');
}

function closeAddAssetModal() {
    document.getElementById('addAssetModal').style.display = 'none';
    document.getElementById('addAssetForm').reset();
    document.getElementById('purchaseDate').valueAsDate = new Date();
}

function saveNewAsset() {
    const name = document.getElementById('assetName').value.trim();
    const type = document.getElementById('assetType').value;
    const serial = document.getElementById('assetSerial').value.trim();
    const purchaseDate = document.getElementById('purchaseDate').value;
    const bookValue = parseFloat(document.getElementById('bookValue').value);
    const marketValue = parseFloat(document.getElementById('marketValue').value);
    const depreciationRate = parseFloat(document.getElementById('depreciationRate').value);
    const status = document.getElementById('assetStatus').value;
    const description = document.getElementById('assetDescription').value.trim();
    const imageUrl = document.getElementById('assetImageUrl').value.trim();
    
    if (!name || !serial || !purchaseDate || !bookValue || !marketValue) {
        showNotification('الرجاء ملء جميع الحقول المطلوبة بشكل صحيح', 'error');
        return;
    }
    
    showNotification(`تم إضافة الأصل ${name} بنجاح`);
    closeAddAssetModal();
}
</script>

<?= $this->endSection() ?>