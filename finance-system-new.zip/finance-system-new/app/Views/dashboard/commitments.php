<?= $this->extend('layouts/main') ?>

<?= $this->section('title') ?>
الالتزامات والديون الشهرية
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="section-header">
    <h2><i class="fas fa-hand-holding-usd"></i> الالتزامات والديون الشهرية</h2>
    <div class="controls">
        <button class="btn btn-primary" id="addCommitmentBtn">
            <i class="fas fa-plus"></i> إضافة التزام جديد
        </button>
        <button class="btn btn-secondary" id="printCommitmentBtn">
            <i class="fas fa-print"></i> طباعة التقرير
        </button>
        <button class="btn btn-success" id="exportCommitmentBtn">
            <i class="fas fa-file-export"></i> تصدير البيانات
        </button>
    </div>
</div>

<!-- إحصائيات الالتزامات -->
<div class="stats-cards">
    <div class="stat-card card-1">
        <div class="stat-info">
            <h3>إجمالي الالتزامات الشهرية</h3>
            <div class="value" id="totalMonthlyCommitments">5,000 <span style="font-size: 1rem;">دينار</span></div>
            <div style="font-size: 0.8rem; color: var(--primary-color); margin-top: 5px;">دفعات شهرية ثابتة</div>
        </div>
        <div class="stat-icon">
            <i class="fas fa-calendar-alt"></i>
        </div>
    </div>
    
    <div class="stat-card card-3">
        <div class="stat-info">
            <h3>الديون المستحقة</h3>
            <div class="value" id="totalDebts">12,500 <span style="font-size: 1rem;">دينار</span></div>
            <div style="font-size: 0.8rem; color: var(--danger-color); margin-top: 5px;">دفعات شهرية للديون</div>
        </div>
        <div class="stat-icon">
            <i class="fas fa-file-invoice-dollar"></i>
        </div>
    </div>
    
    <div class="stat-card card-4">
        <div class="stat-info">
            <h3>إجمالي المبالغ المخصومة</h3>
            <div class="value" id="totalDeducted">1,200 <span style="font-size: 1rem;">دينار</span></div>
            <div style="font-size: 0.8rem; color: var(--warning-color); margin-top: 5px;">خصومات شهرية دورية</div>
        </div>
        <div class="stat-icon">
            <i class="fas fa-minus-circle"></i>
        </div>
    </div>
    
    <div class="stat-card card-5">
        <div class="stat-info">
            <h3>عدد الالتزامات النشطة</h3>
            <div class="value" id="activeCommitments">6</div>
            <div style="font-size: 0.8rem; color: var(--accent-color); margin-top: 5px;">يشمل الالتزامات والديون</div>
        </div>
        <div class="stat-icon">
            <i class="fas fa-list"></i>
        </div>
    </div>
</div>

<!-- البحث والفلترة -->
<div class="table-container" style="margin-bottom: 25px;">
    <div class="table-header">
        <div class="search-filter">
            <select class="filter-select" id="commitmentTypeFilter">
                <option value="all">جميع الالتزامات</option>
                <option value="monthly">التزامات شهرية</option>
                <option value="yearly">التزامات سنوية</option>
                <option value="debt">ديون</option>
                <option value="loan">قروض</option>
            </select>
            <input type="text" class="search-box" id="commitmentSearch" placeholder="ابحث عن التزام بالاسم أو التفاصيل...">
            <button class="btn btn-success" id="searchCommitmentsBtn">
                <i class="fas fa-search"></i> بحث
            </button>
        </div>
    </div>
</div>

<!-- بطاقات الالتزامات -->
<div class="commitment-card" style="border-right-color: var(--primary-color);">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
        <h3 style="color: var(--dark-color); margin: 0;">إيجار المحل التجاري</h3>
        <div style="font-size: 1.5rem; font-weight: 800; color: var(--primary-color);">2,000 دينار/شهر</div>
    </div>
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-top: 15px;">
        <div>
            <div style="font-size: 0.9rem; color: var(--gray-color);">نوع الالتزام</div>
            <div style="font-size: 1.1rem; font-weight: 600; color: var(--dark-color);">إيجار شهري</div>
        </div>
        <div>
            <div style="font-size: 0.9rem; color: var(--gray-color);">تاريخ الدفع</div>
            <div style="font-size: 1.1rem; font-weight: 600; color: var(--dark-color);">يوم 5 من كل شهر</div>
        </div>
        <div>
            <div style="font-size: 0.9rem; color: var(--gray-color);">المستلم</div>
            <div style="font-size: 1.1rem; font-weight: 600; color: var(--dark-color);">شركة الأموال للتجارة</div>
        </div>
    </div>
    <div style="margin-top: 15px; display: flex; gap: 10px; align-items: center;">
        <span class="status paid">مسدد لشهر <?= date('F') ?></span>
        <span style="color: var(--gray-color); font-size: 0.9rem;">آخر دفع: <?= date('d/m/Y', strtotime(date('Y-m-05'))) ?></span>
    </div>
</div>

<div class="commitment-card" style="border-right-color: var(--success-color);">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
        <h3 style="color: var(--dark-color); margin: 0;">رواتب الموظفين</h3>
        <div style="font-size: 1.5rem; font-weight: 800; color: var(--success-color);">2,400 دينار/شهر</div>
    </div>
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-top: 15px;">
        <div>
            <div style="font-size: 0.9rem; color: var(--gray-color);">نوع الالتزام</div>
            <div style="font-size: 1.1rem; font-weight: 600; color: var(--dark-color);">رواتب شهرية</div>
        </div>
        <div>
            <div style="font-size: 0.9rem; color: var(--gray-color);">تاريخ الدفع</div>
            <div style="font-size: 1.1rem; font-weight: 600; color: var(--dark-color);">يوم 10 من كل شهر</div>
        </div>
        <div>
            <div style="font-size: 0.9rem; color: var(--gray-color);">عدد الموظفين</div>
            <div style="font-size: 1.1rem; font-weight: 600; color: var(--dark-color);">5 موظفين</div>
        </div>
    </div>
    <div style="margin-top: 15px; display: flex; gap: 10px; align-items: center;">
        <span class="status paid">مسدد لشهر <?= date('F') ?></span>
        <span style="color: var(--gray-color); font-size: 0.9rem;">آخر دفع: <?= date('d/m/Y', strtotime(date('Y-m-10'))) ?></span>
    </div>
</div>

<!-- جدول الالتزامات -->
<div class="table-container">
    <div class="table-header">
        <h3 style="margin: 0; color: var(--dark-color);"><i class="fas fa-list"></i> جميع الالتزامات</h3>
    </div>
    
    <table>
        <thead>
            <tr>
                <th>اسم الالتزام</th>
                <th>النوع</th>
                <th>المبلغ</th>
                <th>تاريخ الدفع</th>
                <th>المستلم</th>
                <th>الحالة</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>إيجار المحل التجاري</td>
                <td>التزام شهري</td>
                <td>2,000 دينار</td>
                <td>يوم 5 من كل شهر</td>
                <td>شركة الأموال للتجارة</td>
                <td><span class="status paid">مسدد</span></td>
            </tr>
            <tr>
                <td>رواتب الموظفين</td>
                <td>التزام شهري</td>
                <td>2,400 دينار</td>
                <td>يوم 10 من كل شهر</td>
                <td>موظفو الشركة</td>
                <td><span class="status paid">مسدد</span></td>
            </tr>
            <tr>
                <td>فواتير المياه والكهرباء</td>
                <td>التزام شهري</td>
                <td>300 دينار</td>
                <td>يوم 15 من كل شهر</td>
                <td>شركة الكهرباء الوطنية</td>
                <td><span class="status paid">مسدد</span></td>
            </tr>
            <tr>
                <td>فواتير الإنترنت والهاتف</td>
                <td>التزام شهري</td>
                <td>200 دينار</td>
                <td>يوم 20 من كل شهر</td>
                <td>شركة اتصالات الوطن</td>
                <td><span class="status pending">قيد الانتظار</span></td>
            </tr>
            <tr>
                <td>ديون بنكية - قرض تجاري</td>
                <td>دين</td>
                <td>10,000 دينار</td>
                <td>يوم 25 من كل شهر</td>
                <td>البنك التجاري الوطني</td>
                <td><span class="status pending">قيد الانتظار</span></td>
            </tr>
        </tbody>
    </table>
</div>
<!-- نافذة إضافة التزام جديد -->
<div class="modal-overlay" id="addCommitmentModal" style="display: none;">
    <div class="modal">
        <div class="modal-header">
            <h3><i class="fas fa-hand-holding-usd"></i> إضافة التزام جديد</h3>
            <button class="close-modal" id="closeCommitmentModalBtn">
                <i class="fas fa-times"></i>
            </button>
        </div>
        
        <div class="modal-body">
            <form id="addCommitmentForm">
                <div class="form-row">
                    <div class="form-group">
                        <label for="commitmentName"><i class="fas fa-tag"></i> اسم الالتزام *</label>
                        <input type="text" id="commitmentName" placeholder="أدخل اسم الالتزام" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="commitmentType"><i class="fas fa-list"></i> نوع الالتزام</label>
                        <select id="commitmentType">
                            <option value="monthly">التزام شهري</option>
                            <option value="yearly">التزام سنوي</option>
                            <option value="debt">دين</option>
                            <option value="loan">قرض</option>
                            <option value="deduction">خصم شهري</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="commitmentAmount"><i class="fas fa-money-bill-wave"></i> المبلغ (دينار) *</label>
                        <input type="number" id="commitmentAmount" placeholder="المبلغ الشهري أو الإجمالي" required min="1" step="0.01">
                    </div>
                    
                    <div class="form-group">
                        <label for="paymentDay"><i class="fas fa-calendar-day"></i> يوم الدفع/الخصم *</label>
                        <input type="number" id="paymentDay" placeholder="أدخل يوم الشهر (1-31)" min="1" max="31" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="startDate"><i class="fas fa-calendar-alt"></i> تاريخ البدء *</label>
                        <input type="date" id="startDate" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="endDate"><i class="fas fa-calendar-times"></i> تاريخ الانتهاء (اختياري)</label>
                        <input type="date" id="endDate">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="recipient"><i class="fas fa-user-tie"></i> المستلم/الجهة</label>
                        <input type="text" id="recipient" placeholder="اسم المستلم أو الجهة">
                    </div>
                    
                    <div class="form-group">
                        <label for="status"><i class="fas fa-info-circle"></i> حالة الالتزام</label>
                        <select id="status">
                            <option value="active">نشط</option>
                            <option value="pending">معلق</option>
                            <option value="completed">مكتمل</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="commitmentNotes"><i class="fas fa-sticky-note"></i> تفاصيل إضافية</label>
                    <textarea id="commitmentNotes" rows="4" placeholder="أضف أي تفاصيل حول الالتزام..."></textarea>
                </div>
            </form>
        </div>
        
        <div class="modal-footer">
            <button class="btn btn-secondary" id="cancelAddCommitmentBtn">
                <i class="fas fa-times"></i> إلغاء
            </button>
            <button class="btn btn-success" id="saveCommitmentBtn">
                <i class="fas fa-save"></i> حفظ الالتزام
            </button>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Set default date
    document.getElementById('startDate').valueAsDate = new Date();
    
    // Event listeners
    document.getElementById('addCommitmentBtn')?.addEventListener('click', openAddCommitmentModal);
    document.getElementById('closeCommitmentModalBtn')?.addEventListener('click', closeAddCommitmentModal);
    document.getElementById('cancelAddCommitmentBtn')?.addEventListener('click', closeAddCommitmentModal);
    document.getElementById('printCommitmentBtn')?.addEventListener('click', function() {
        window.print();
        showNotification('جارٍ تحضير تقرير الالتزامات للطباعة...');
    });
    document.getElementById('exportCommitmentBtn')?.addEventListener('click', function() {
        showNotification('جارٍ تصدير بيانات الالتزامات إلى ملف Excel...');
    });
    document.getElementById('searchCommitmentsBtn')?.addEventListener('click', function() {
        const type = document.getElementById('commitmentTypeFilter').value;
        const search = document.getElementById('commitmentSearch').value;
        showNotification(`جارٍ البحث عن الالتزامات: ${type === 'all' ? 'جميع الأنواع' : type} - "${search}"`);
    });
    document.getElementById('saveCommitmentBtn')?.addEventListener('click', saveNewCommitment);
    
    // Close modal when clicking outside
    document.getElementById('addCommitmentModal')?.addEventListener('click', function(e) {
        if (e.target === this) {
            closeAddCommitmentModal();
        }
    });
});

function openAddCommitmentModal() {
    document.getElementById('addCommitmentModal').style.display = 'flex';
    document.getElementById('commitmentName').focus();
    showNotification('فتح نموذج إضافة التزام جديد');
}

function closeAddCommitmentModal() {
    document.getElementById('addCommitmentModal').style.display = 'none';
    document.getElementById('addCommitmentForm').reset();
    document.getElementById('startDate').valueAsDate = new Date();
}

function saveNewCommitment() {
    const name = document.getElementById('commitmentName').value.trim();
    const type = document.getElementById('commitmentType').value;
    const amount = parseFloat(document.getElementById('commitmentAmount').value);
    const paymentDay = parseInt(document.getElementById('paymentDay').value);
    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('endDate').value;
    const recipient = document.getElementById('recipient').value.trim();
    const status = document.getElementById('status').value;
    const notes = document.getElementById('commitmentNotes').value.trim();
    
    if (!name || !amount || !paymentDay || !startDate) {
        showNotification('الرجاء ملء جميع الحقول المطلوبة بشكل صحيح', 'error');
        return;
    }
    
    if (paymentDay < 1 || paymentDay > 31) {
        showNotification('يوم الدفع يجب أن يكون بين 1 و 31', 'error');
        return;
    }
    
    showNotification(`تم إضافة الالتزام ${name} بنجاح`);
    closeAddCommitmentModal();
}
</script>

<?= $this->endSection() ?>