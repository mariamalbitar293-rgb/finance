<?= $this->extend('layouts/main') ?>

<?= $this->section('title') ?>
تقارير الرواتب والمصروفات
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="section-header">
    <h2><i class="fas fa-file-invoice-dollar"></i> تقارير الرواتب والمصروفات</h2>
    <div class="controls">
        <button class="btn btn-primary" id="exportSalaryBtn">
            <i class="fas fa-file-export"></i> تصدير البيانات
        </button>
        <button class="btn btn-secondary" id="filterSalaryBtn">
            <i class="fas fa-filter"></i> فلترة متقدمة
        </button>
        <button class="btn btn-success" id="salaryChartBtn">
            <i class="fas fa-chart-bar"></i> عرض الرسوم البيانية
        </button>
    </div>
</div>

<!-- ملخص الرسوم المالية -->
<div class="stats-cards">
    <div class="stat-card card-1">
        <div class="stat-info">
            <h3>إجمالي الرواتب الشهرية</h3>
            <div class="value">7,800 <span style="font-size: 1rem;">دينار</span></div>
            <div style="font-size: 0.8rem; color: var(--primary-color); margin-top: 5px;">دفعات شهرية ثابتة</div>
        </div>
        <div class="stat-icon">
            <i class="fas fa-money-check-alt"></i>
        </div>
    </div>
    
    <div class="stat-card card-2">
        <div class="stat-info">
            <h3>متوسط الراتب</h3>
            <div class="value">975 <span style="font-size: 1rem;">دينار</span></div>
            <div style="font-size: 0.8rem; color: var(--success-color); margin-top: 5px;">زيادة 5% عن الشهر الماضي</div>
        </div>
        <div class="stat-icon">
            <i class="fas fa-chart-bar"></i>
        </div>
    </div>
    
    <div class="stat-card card-3">
        <div class="stat-info">
            <h3>إجمالي الحوافز</h3>
            <div class="value">580 <span style="font-size: 1rem;">دينار</span></div>
            <div style="font-size: 0.8rem; color: var(--accent-color); margin-top: 5px;">حوافز أداء للموظفين</div>
        </div>
        <div class="stat-icon">
            <i class="fas fa-award"></i>
        </div>
    </div>
    
    <div class="stat-card card-4">
        <div class="stat-info">
            <h3>إجمالي الاستقطاعات</h3>
            <div class="value">200 <span style="font-size: 1rem;">دينار</span></div>
            <div style="font-size: 0.8rem; color: var(--warning-color); margin-top: 5px;">تأمينات وضرائب</div>
        </div>
        <div class="stat-icon">
            <i class="fas fa-percentage"></i>
        </div>
    </div>
</div>

<!-- البحث والفلترة -->
<div class="table-container" style="margin-bottom: 25px;">
    <div class="table-header">
        <div class="search-filter">
            <select class="filter-select" id="employeeFilter">
                <option value="all">جميع الموظفين</option>
                <option value="employee1">أحمد محمد</option>
                <option value="employee2">سارة خالد</option>
                <option value="employee3">محمد علي</option>
                <option value="employee4">فاطمة حسين</option>
                <option value="employee5">خالد وليد</option>
            </select>
            <input type="month" class="search-box" id="salaryMonth" value="<?= date('Y-m') ?>">
            <button class="btn btn-success" id="searchSalariesBtn">
                <i class="fas fa-search"></i> بحث
            </button>
        </div>
    </div>
</div>

<!-- رسم بياني للرواتب -->
<div class="chart-card" style="margin-bottom: 25px;">
    <h3><i class="fas fa-chart-bar"></i> توزيع الرواتب والرسوم</h3>
    <div class="chart-wrapper">
        <canvas id="salaryChart"></canvas>
    </div>
</div>

<!-- جدول الرواتب -->
<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>اسم الموظف</th>
                <th>الراتب الأساسي</th>
                <th>الحوافز</th>
                <th>الاستقطاعات</th>
                <th>صافي الراتب</th>
                <th>تاريخ الصرف</th>
                <th>الحالة</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>أحمد محمد</td>
                <td>1,200 دينار</td>
                <td>150 دينار</td>
                <td>50 دينار</td>
                <td>1,300 دينار</td>
                <td><?= date('Y-m-05') ?></td>
                <td><span class="status paid">مسدد</span></td>
            </tr>
            <tr>
                <td>سارة خالد</td>
                <td>1,500 دينار</td>
                <td>200 دينار</td>
                <td>75 دينار</td>
                <td>1,625 دينار</td>
                <td><?= date('Y-m-05') ?></td>
                <td><span class="status paid">مسدد</span></td>
            </tr>
            <tr>
                <td>محمد علي</td>
                <td>900 دينار</td>
                <td>100 دينار</td>
                <td>30 دينار</td>
                <td>970 دينار</td>
                <td><?= date('Y-m-05') ?></td>
                <td><span class="status paid">مسدد</span></td>
            </tr>
            <tr>
                <td>فاطمة حسين</td>
                <td>800 دينار</td>
                <td>80 دينار</td>
                <td>25 دينار</td>
                <td>855 دينار</td>
                <td><?= date('Y-m-05') ?></td>
                <td><span class="status paid">مسدد</span></td>
            </tr>
            <tr>
                <td>خالد وليد</td>
                <td>700 دينار</td>
                <td>50 دينار</td>
                <td>20 دينار</td>
                <td>730 دينار</td>
                <td><?= date('Y-m-05') ?></td>
                <td><span class="status paid">مسدد</span></td>
            </tr>
        </tbody>
    </table>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize salary chart
    initSalaryChart();
    
    // Event listeners
    document.getElementById('exportSalaryBtn')?.addEventListener('click', function() {
        showNotification('جارٍ تصدير بيانات الرواتب إلى ملف Excel...');
    });
    
    document.getElementById('salaryChartBtn')?.addEventListener('click', function() {
        const chartCard = document.querySelector('.chart-card');
        if (chartCard.style.display === 'none') {
            chartCard.style.display = 'block';
            this.innerHTML = '<i class="fas fa-chart-bar"></i> إخفاء الرسم البياني';
        } else {
            chartCard.style.display = 'none';
            this.innerHTML = '<i class="fas fa-chart-bar"></i> عرض الرسوم البيانية';
        }
    });
    
    document.getElementById('searchSalariesBtn')?.addEventListener('click', function() {
        const employee = document.getElementById('employeeFilter').value;
        const month = document.getElementById('salaryMonth').value;
        showNotification(`جارٍ البحث عن رواتب ${employee === 'all' ? 'جميع الموظفين' : 'موظف محدد'} لشهر ${month}`);
    });
});

function initSalaryChart() {
    const salaryCtx = document.getElementById('salaryChart');
    if (salaryCtx) {
        new Chart(salaryCtx.getContext('2d'), {
            type: 'bar',
            data: {
                labels: ['أحمد محمد', 'سارة خالد', 'محمد علي', 'فاطمة حسين', 'خالد وليد'],
                datasets: [
                    {
                        label: 'الراتب الأساسي',
                        data: [1200, 1500, 900, 800, 700],
                        backgroundColor: 'var(--primary-color)',
                        borderColor: 'var(--secondary-color)',
                        borderWidth: 1
                    },
                    {
                        label: 'الحوافز',
                        data: [150, 200, 100, 80, 50],
                        backgroundColor: 'var(--success-color)',
                        borderColor: '#27ae60',
                        borderWidth: 1
                    },
                    {
                        label: 'صافي الراتب',
                        data: [1300, 1625, 970, 855, 730],
                        backgroundColor: 'var(--warning-color)',
                        borderColor: '#e67e22',
                        borderWidth: 1
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                        rtl: true,
                        labels: {
                            font: {
                                family: "'Cairo', sans-serif",
                                size: 12
                            }
                        }
                    },
                    tooltip: {
                        rtl: true,
                        callbacks: {
                            label: function(context) {
                                let label = context.dataset.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                label += context.parsed.y.toLocaleString() + ' دينار';
                                return label;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return value.toLocaleString() + ' دينار';
                            }
                        }
                    }
                },
                animation: {
                    duration: 1200,
                    easing: 'easeOutQuart'
                }
            }
        });
    }
}
</script>

<?= $this->endSection() ?>