<!-- نافذة إضافة عميل جديد -->
<div class="modal-overlay" id="addClientModal">
    <!-- ... (نفس كود النافذة كما في ملفك) ... -->
</div>

<!-- نافذة إضافة التزام جديد -->
<div class="modal-overlay" id="addCommitmentModal">
    <!-- ... (نفس كود النافذة كما في ملفك) ... -->
</div>

<!-- نافذة إضافة أصل جديد -->
<div class="modal-overlay" id="addAssetModal">
    <!-- ... (نفس كود النافذة كما في ملفك) ... -->
</div>

<!-- نافذة إضافة راتب جديد -->
<div class="modal-overlay" id="addSalaryModal">
    <!-- ... (نفس كود النافذة كما في ملفك) ... -->
</div>

<!-- ========== نهاية النوافذ المنبثقة ========== -->

<script>
// الربط بين أزار الإغلاق ونوافذها
document.getElementById('closeModalBtn')?.addEventListener('click', () => closeModal('addClientModal'));
document.getElementById('cancelAddClientBtn')?.addEventListener('click', () => closeModal('addClientModal'));

document.getElementById('closeCommitmentModalBtn')?.addEventListener('click', () => closeModal('addCommitmentModal'));
document.getElementById('cancelAddCommitmentBtn')?.addEventListener('click', () => closeModal('addCommitmentModal'));

document.getElementById('closeAssetModalBtn')?.addEventListener('click', () => closeModal('addAssetModal'));
document.getElementById('cancelAddAssetBtn')?.addEventListener('click', () => closeModal('addAssetModal'));

document.getElementById('closeSalaryModalBtn')?.addEventListener('click', () => closeModal('addSalaryModal'));
document.getElementById('cancelAddSalaryBtn')?.addEventListener('click', () => closeModal('addSalaryModal'));

// دالة إغلاق النافذة
function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// دالة فتح النافذة
function openModal(modalId) {
    document.getElementById(modalId).style.display = 'flex';
}

// تحديث شريط التقدم للعملاء
function updatePaymentProgress() {
    const principal = parseFloat(document.getElementById('principalAmount')?.value) || 0;
    const paid = parseFloat(document.getElementById('paidAmount')?.value) || 0;
    
    if (principal > 0) {
        const percentage = Math.min(100, (paid / principal) * 100);
        const progressBar = document.getElementById('paymentProgress');
        const percentageText = document.getElementById('paymentPercentage');
        
        if (progressBar && percentageText) {
            progressBar.style.width = percentage + '%';
            percentageText.textContent = percentage.toFixed(1) + '%';
            
            if (percentage === 100) {
                progressBar.style.background = 'linear-gradient(90deg, var(--success-color), #27ae60)';
                percentageText.style.color = 'var(--success-color)';
            } else if (percentage > 0) {
                progressBar.style.background = 'linear-gradient(90deg, var(--warning-color), #e67e22)';
                percentageText.style.color = 'var(--warning-color)';
            } else {
                progressBar.style.background = 'linear-gradient(90deg, var(--primary-color), var(--secondary-color))';
                percentageText.style.color = 'var(--primary-color)';
            }
        }
    }
}

// إضافة مستمع الأحداث عند التحميل
document.addEventListener('DOMContentLoaded', function() {
    // تحديث شريط التقدم
    if (document.getElementById('principalAmount') && document.getElementById('paidAmount')) {
        document.getElementById('principalAmount').addEventListener('input', updatePaymentProgress);
        document.getElementById('paidAmount').addEventListener('input', updatePaymentProgress);
        updatePaymentProgress(); // تحديث أولي
    }
});
</script>