<!-- ظ†ط§ظپط°ط© ط¥ط¶ط§ظپط© ط±ط§طھط¨ ط¬ط¯ظٹط¯ -->
<div class="modal-overlay" id="addSalaryModal">
    <div class="modal">
        <div style="padding: 25px; border-bottom: 1px solid #f0f0f0; display: flex; justify-content: space-between; align-items: center;">
            <h2 style="color: var(--dark-color); margin: 0; display: flex; align-items: center; gap: 10px;">
                <i class="fas fa-file-invoice-dollar"></i> ط¥ط¶ط§ظپط© ط±ط§طھط¨ ط¬ط¯ظٹط¯
            </h2>
            <button style="background: none; border: none; font-size: 1.5rem; color: var(--gray-color); cursor: pointer;" id="closeSalaryModalBtn">&times;</button>
        </div>
        
        <div style="padding: 25px; max-height: 70vh; overflow-y: auto;">
            <form id="addSalaryForm">
                <input type="hidden" id="salaryId">
                <div style="display: flex; gap: 20px; margin-bottom: 25px; flex-wrap: wrap;">
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">ط§ط³ظ… ط§ظ„ظ…ظˆط¸ظپ</label>
                        <input type="text" id="employeeName" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" placeholder="ط£ط¯ط®ظ„ ط§ط³ظ… ط§ظ„ظ…ظˆط¸ظپ ط§ظ„ظƒط§ظ…ظ„" required>
                    </div>
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">ط§ظ„ظ…ظ†طµط¨ ط§ظ„ظˆط¸ظٹظپظٹ</label>
                        <input type="text" id="position" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" placeholder="ط§ظ„ظ…ظ†طµط¨ ط£ظˆ ط§ظ„ظˆط¸ظٹظپط©" required>
                    </div>
                </div>
                
                <div style="display: flex; gap: 20px; margin-bottom: 25px; flex-wrap: wrap;">
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">ط§ظ„ط±ط§طھط¨ ط§ظ„ط£ط³ط§ط³ظٹ (ط¯ظٹظ†ط§ط±)</label>
                        <input type="number" id="baseSalary" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" placeholder="ط§ظ„ط±ط§طھط¨ ط§ظ„ط£ط³ط§ط³ظٹ" required min="1">
                    </div>
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">ط§ظ„ط­ظˆط§ظپط² ظˆط§ظ„ظ…ظƒط§ظپط¢طھ (ط¯ظٹظ†ط§ط±)</label>
                        <input type="number" id="bonuses" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" placeholder="ط§ظ„ط­ظˆط§ظپط² ظˆط§ظ„ظ…ظƒط§ظپط¢طھ" min="0" value="0">
                    </div>
                </div>
                
                <div style="display: flex; gap: 20px; margin-bottom: 25px; flex-wrap: wrap;">
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">ط§ظ„ط®طµظˆظ…ط§طھ (ط¯ظٹظ†ط§ط±)</label>
                        <input type="number" id="deductions" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" placeholder="ط§ظ„ط®طµظˆظ…ط§طھ ط§ظ„ط´ظ‡ط±ظٹط©" min="0" value="0">
                    </div>
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">ط§ظ„ط±ط§طھط¨ ط§ظ„طµط§ظپظٹ (ط¯ظٹظ†ط§ط±)</label>
                        <input type="number" id="netSalary" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" placeholder="ط§ظ„ط±ط§طھط¨ ط§ظ„طµط§ظپظٹ" readonly required>
                    </div>
                </div>
                
                <div style="display: flex; gap: 20px; margin-bottom: 25px; flex-wrap: wrap;">
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">طھط§ط±ظٹط® ط§ظ„ط¯ظپط¹</label>
                        <input type="date" id="paymentDate" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" required>
                    </div>
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">ط­ط§ظ„ط© ط§ظ„ط³ط¯ط§ط¯</label>
                        <select id="salaryStatus" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;">
                            <option value="pending" selected>ظ‚ظٹط¯ ط§ظ„ط§ظ†طھط¸ط§ط±</option>
                            <option value="paid">ظ…ط³ط¯ط¯</option>
                        </select>
                    </div>
                </div>
                
                <div style="margin-bottom: 25px;">
                    <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">ظ…ظ„ط§ط­ط¸ط§طھ ط¥ط¶ط§ظپظٹط©</label>
                    <textarea id="salaryNotes" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease; min-height: 100px;" placeholder="ط£ط¶ظپ ط£ظٹ ظ…ظ„ط§ط­ط¸ط§طھ ط­ظˆظ„ ط§ظ„ط±ط§طھط¨..."></textarea>
                </div>
            </form>
        </div>
        
        <div style="padding: 20px 25px; background-color: #f8f9fa; display: flex; justify-content: flex-end; gap: 15px; border-top: 1px solid #f0f0f0;">
            <button class="btn btn-secondary" id="cancelAddSalaryBtn">ط¥ظ„ط؛ط§ط،</button>
            <button class="btn btn-success" id="saveSalaryBtn">
                <i class="fas fa-save"></i> ط­ظپط¸ ط§ظ„ط±ط§طھط¨
            </button>
        </div>
    </div>
</div>