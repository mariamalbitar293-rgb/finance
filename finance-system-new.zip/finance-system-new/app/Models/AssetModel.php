<?php
namespace App\Models;

use CodeIgniter\Model;

class AssetModel extends Model
{
    protected $table = 'assets';
    protected $primaryKey = 'id';
    protected $allowedFields = ['name', 'type', 'serial', 'purchase_date', 'book_value', 'market_value', 'depreciation_rate', 'status', 'description', 'image_url'];
    protected $useTimestamps = true;
    
    public function getStats()
    {
        $builder = $this->db->table($this->table);
        
        $stats = [
            'total_book_value' => 0,
            'total_market_value' => 0,
            'active_count' => 0,
            'total_depreciation' => 0
        ];
        
        $result = $builder->selectSum('book_value', 'total_book')
                         ->selectSum('market_value', 'total_market')
                         ->select('COUNT(*) as active_count')
                         ->where('status', 'active')
                         ->get()
                         ->getRowArray();
        
        if ($result) {
            $stats['total_book_value'] = $result['total_book'] ?? 0;
            $stats['total_market_value'] = $result['total_market'] ?? 0;
            $stats['active_count'] = $result['active_count'] ?? 0;
            
            // Calculate total annual depreciation
            $depreciation = $builder->select('book_value, depreciation_rate')
                                   ->where('status', 'active')
                                   ->get()
                                   ->getResultArray();
            
            $totalDepreciation = 0;
            foreach ($depreciation as $asset) {
                $totalDepreciation += ($asset['book_value'] * ($asset['depreciation_rate'] / 100));
            }
            $stats['total_depreciation'] = $totalDepreciation;
        }
        
        return $stats;
    }
}