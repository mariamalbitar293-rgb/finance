<!-- ظ†ط§ظپط°ط© ط¥ط¶ط§ظپط© ط£طµظ„ ط¬ط¯ظٹط¯ -->
<div class="modal-overlay" id="addAssetModal">
    <div class="modal">
        <div style="padding: 25px; border-bottom: 1px solid #f0f0f0; display: flex; justify-content: space-between; align-items: center;">
            <h2 style="color: var(--dark-color); margin: 0; display: flex; align-items: center; gap: 10px;">
                <i class="fas fa-server"></i> ط¥ط¶ط§ظپط© ط£طµظ„ ط¬ط¯ظٹط¯
            </h2>
            <button style="background: none; border: none; font-size: 1.5rem; color: var(--gray-color); cursor: pointer;" id="closeAssetModalBtn">&times;</button>
        </div>
        
        <div style="padding: 25px; max-height: 70vh; overflow-y: auto;">
            <form id="addAssetForm">
                <input type="hidden" id="assetId">
                <div style="display: flex; gap: 20px; margin-bottom: 25px; flex-wrap: wrap;">
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">ط§ط³ظ… ط§ظ„ط£طµظ„</label>
                        <input type="text" id="assetName" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" placeholder="ط£ط¯ط®ظ„ ط§ط³ظ… ط§ظ„ط£طµظ„" required>
                    </div>
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">ظ†ظˆط¹ ط§ظ„ط£طµظ„</label>
                        <select id="assetType" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" required>
                            <option value="servers">ط³ظٹط±ظپط±ط§طھ</option>
                            <option value="equipment">ظ…ط¹ط¯ط§طھ</option>
                            <option value="property">ط¹ظ‚ط§ط±ط§طھ</option>
                            <option value="vehicles">ظ…ط±ظƒط¨ط§طھ</option>
                            <option value="other">ط£ط®ط±ظ‰</option>
                        </select>
                    </div>
                </div>
                
                <div style="display: flex; gap: 20px; margin-bottom: 25px; flex-wrap: wrap;">
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">ط§ظ„ط±ظ‚ظ… ط§ظ„طھط³ظ„ط³ظ„ظٹ</label>
                        <input type="text" id="assetSerial" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" placeholder="ط±ظ‚ظ… طھط³ظ„ط³ظ„ظٹ ط£ظˆ طھط¹ط±ظٹظپ" required>
                    </div>
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">طھط§ط±ظٹط® ط§ظ„ط´ط±ط§ط،</label>
                        <input type="date" id="purchaseDate" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" required>
                    </div>
                </div>
                
                <div style="display: flex; gap: 20px; margin-bottom: 25px; flex-wrap: wrap;">
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">ط§ظ„ظ‚ظٹظ…ط© ط§ظ„ط¯ظپطھط±ظٹط© (ط¯ظٹظ†ط§ط±)</label>
                        <input type="number" id="bookValue" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" placeholder="طھظƒظ„ظپط© ط§ظ„ط´ط±ط§ط،" required min="1">
                    </div>
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">ط§ظ„ظ‚ظٹظ…ط© ط§ظ„ط³ظˆظ‚ظٹط© (ط¯ظٹظ†ط§ط±)</label>
                        <input type="number" id="marketValue" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" placeholder="ط§ظ„ظ‚ظٹظ…ط© ط§ظ„ط­ط§ظ„ظٹط© ظپظٹ ط§ظ„ط³ظˆظ‚" required min="1">
                    </div>
                </div>
                
                <div style="display: flex; gap: 20px; margin-bottom: 25px; flex-wrap: wrap;">
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">ظ†ط³ط¨ط© ط§ظ„ط¥ظ‡ظ„ط§ظƒ ط§ظ„ط³ظ†ظˆظٹط© (%)</label>
                        <input type="number" id="depreciationRate" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" placeholder="ظ†ط³ط¨ط© ط§ظ„ط¥ظ‡ظ„ط§ظƒ ط§ظ„ط³ظ†ظˆظٹ" min="0" max="100" step="0.1" value="10">
                    </div>
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">ط­ط§ظ„ط© ط§ظ„ط£طµظ„</label>
                        <select id="assetStatus" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;">
                            <option value="active" selected>ظ†ط´ط·</option>
                            <option value="inactive">ط؛ظٹط± ظ†ط´ط·</option>
                            <option value="maintenance">طµظٹط§ظ†ط©</option>
                            <option value="sold">ظ…ط¨ط§ط¹</option>
                        </select>
                    </div>
                </div>
                
                <div style="margin-bottom: 25px;">
                    <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">ظˆطµظپ ط§ظ„ط£طµظ„</label>
                    <textarea id="assetDescription" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease; min-height: 100px;" placeholder="ط£ط¶ظپ ظˆطµظپط§ظ‹ ظ…ظپطµظ„ط§ظ‹ ظ„ظ„ط£طµظ„..."></textarea>
                </div>
                
                <div style="margin-bottom: 25px;">
                    <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">ط±ط§ط¨ط· ط§ظ„طµظˆط±ط© (ط§ط®طھظٹط§ط±ظٹ)</label>
                    <input type="url" id="assetImageUrl" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" placeholder="https://example.com/image.jpg">
                </div>
            </form>
        </div>
        
        <div style="padding: 20px 25px; background-color: #f8f9fa; display: flex; justify-content: flex-end; gap: 15px; border-top: 1px solid #f0f0f0;">
            <button class="btn btn-secondary" id="cancelAddAssetBtn">ط¥ظ„ط؛ط§ط،</button>
            <button class="btn btn-success" id="saveAssetBtn">
                <i class="fas fa-save"></i> ط­ظپط¸ ط§ظ„ط£طµظ„
            </button>
        </div>
    </div>
</div>