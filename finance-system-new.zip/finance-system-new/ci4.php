<?php
/**
 * CodeIgniter 4 Direct Runner
 */

// Enable all errors
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

echo "=== CodeIgniter 4 Direct Runner ===\n";

$root = __DIR__;
echo "Root: $root\n";

// Check and define COMPOSER_PATH
$composerPath = $root . '/vendor/autoload.php';
if (!file_exists($composerPath)) {
    die("ERROR: Run 'composer install' first!\n");
}
define('COMPOSER_PATH', $composerPath);
echo "✓ Composer path set\n";

// Load Composer
require_once COMPOSER_PATH;

// Load Boot.php
$bootPath = $root . '/vendor/codeigniter4/framework/system/Boot.php';
if (!file_exists($bootPath)) {
    die("ERROR: Boot.php not found!\n");
}
require_once $bootPath;

// Get command line arguments
$args = $_SERVER['argv'];
array_shift($args); // Remove script name

echo "Command: " . ($args[0] ?? '(default)') . "\n";

// Create Paths object
if (file_exists($root . '/app/Config/Paths.php')) {
    require_once $root . '/app/Config/Paths.php';
    $paths = new Config\Paths();
} else {
    // Create simple paths
    $paths = new class($root) {
        public $systemDirectory;
        public $appDirectory;
        public $writableDirectory;
        public $testsDirectory;
        public $viewDirectory;
        
        public function __construct($root) {
            $this->systemDirectory = $root . '/vendor/codeigniter4/framework/system';
            $this->appDirectory = $root . '/app';
            $this->writableDirectory = $root . '/writable';
            $this->testsDirectory = $root . '/tests';
            $this->viewDirectory = $root . '/app/Views';
        }
    };
}

// Run the command
if (empty($args) || $args[0] === 'serve') {
    echo "\nStarting development server...\n";
    echo "Open: http://localhost:8080\n";
    echo "Press Ctrl+C to stop\n\n";
    
    // Start server
    system('php -S localhost:8080 -t public/');
} else {
    // Run other spark commands
    CodeIgniter\Boot::bootSpark($paths);
}
