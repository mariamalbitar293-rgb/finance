<?php
/**
 * Bootstrap File - Simple Fixed Version
 */

// Define COMPOSER_PATH with raw path
$root = dirname(__DIR__);
$composerPath = $root . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'autoload.php';

// Use forward slashes for consistency
$composerPath = str_replace('\\', '/', $composerPath);

if (!defined('COMPOSER_PATH')) {
    define('COMPOSER_PATH', $composerPath);
}

// Define SYSTEMPATH
$systemPath = $root . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'codeigniter4' . DIRECTORY_SEPARATOR . 'framework' . DIRECTORY_SEPARATOR . 'system';
$systemPath = str_replace('\\', '/', $systemPath);

if (!defined('SYSTEMPATH')) {
    define('SYSTEMPATH', $systemPath . DIRECTORY_SEPARATOR);
}

// Check if files exist
if (!file_exists(COMPOSER_PATH)) {
    die("ERROR: Composer autoload not found at: " . COMPOSER_PATH . 
        "\nPlease run: composer install");
}

if (!file_exists(SYSTEMPATH . 'Boot.php')) {
    die("ERROR: Boot.php not found at: " . SYSTEMPATH);
}

// Load Composer
require_once COMPOSER_PATH;

// Load CodeIgniter Boot
require_once SYSTEMPATH . 'Boot.php';

// Simple Paths class
class SimplePaths
{
    public $systemDirectory;
    public $appDirectory;
    public $writableDirectory;
    public $testsDirectory;
    public $viewDirectory;
    
    public function __construct()
    {
        $root = dirname(__DIR__);
        $this->systemDirectory = SYSTEMPATH;
        $this->appDirectory = $root . DIRECTORY_SEPARATOR . 'app';
        $this->writableDirectory = $root . DIRECTORY_SEPARATOR . 'writable';
        $this->testsDirectory = $root . DIRECTORY_SEPARATOR . 'tests';
        $this->viewDirectory = $root . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'Views';
    }
}

return CodeIgniter\Boot::bootWeb(new SimplePaths());
