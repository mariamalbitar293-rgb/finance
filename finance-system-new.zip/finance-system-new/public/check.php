<?php
echo "<h1>Basic System Check</h1>";

// Test 1: PHP
echo "<h3>PHP Test:</h3>";
echo "Version: " . phpversion() . "<br>";

// Test 2: Check Paths.php
echo "<h3>Config Files:</h3>";
$pathsFile = __DIR__ . "/../app/Config/Paths.php";
if (file_exists($pathsFile)) {
    echo " Paths.php exists<br>";
    
    // Check content
    $content = file_get_contents($pathsFile);
    if (strpos($content, "<?php") === 0) {
        echo " Starts with <?php<br>";
        
        try {
            require $pathsFile;
            if (class_exists('Config\Paths')) {
                $paths = new Config\Paths();
                echo " Paths class loaded<br>";
                echo "System Dir: " . $paths->systemDirectory . "<br>";
                
                // Check vendor
                $vendorAutoload = __DIR__ . "/../vendor/autoload.php";
                if (file_exists($vendorAutoload)) {
                    echo " vendor/autoload.php exists<br>";
                } else {
                    echo " vendor/autoload.php missing<br>";
                }
            }
        } catch (Exception $e) {
            echo " Error: " . $e->getMessage() . "<br>";
        }
    } else {
        echo " Does not start with <?php<br>";
    }
} else {
    echo " Paths.php not found<br>";
}

// Test 3: Quick CodeIgniter test
echo "<h3>Quick CI Test:</h3>";
echo "<a href='/index.php'>Test Home Page</a><br>";
echo "<a href='/test.php'>Test Page</a>";
