<?php
// public/test2.php

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h2>ًںڑ€ ط§ط®طھط¨ط§ط± CodeIgniter ط§ظ„ظ…ط¨ط§ط´ط±</h2>";

// 1. طھط­ظ…ظٹظ„ ط§ظ„ظ†ط¸ط§ظ… ظ…ط¨ط§ط´ط±ط©
define('FCPATH', __DIR__ . DIRECTORY_SEPARATOR);
$systemPath = FCPATH . '../vendor/codeigniter4/framework/system';

if (!is_dir($systemPath)) {
    die("â‌Œ ظ…ط¬ظ„ط¯ system ط؛ظٹط± ظ…ظˆط¬ظˆط¯");
}

// 2. طھط­ظ…ظٹظ„ Boot ظ…ط¨ط§ط´ط±ط©
require_once $systemPath . '/Boot.php';

// 3. طھط­ظ…ظٹظ„ Paths
$paths = new \Config\Paths();

// 4. طھط´ط؛ظٹظ„ CodeIgniter
try {
    $app = \CodeIgniter\Boot::bootWeb($paths);
    echo "âœ… CodeIgniter ظٹط¹ظ…ظ„ ط¨ظ†ط¬ط§ط­!";
} catch (Exception $e) {
    echo "â‌Œ ط®ط·ط£: " . $e->getMessage() . "<br><br>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
}