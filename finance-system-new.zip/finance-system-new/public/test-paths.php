<?php
echo "<h1>Direct Paths.php Test</h1>";

$file = __DIR__ . "/../app/Config/Paths.php";
echo "File path: $file<br>";

if (file_exists($file)) {
    echo " File exists<br>";
    
    // عرض أول 100 حرف
    $content = file_get_contents($file);
    $first100 = substr($content, 0, 100);
    echo "First 100 chars:<br><pre>" . htmlspecialchars($first100) . "</pre><br>";
    
    // تحقق من أول سطر
    $lines = explode("\n", $content);
    $firstLine = trim($lines[0]);
    echo "First line: '$firstLine'<br>";
    
    if ($firstLine === "<?php") {
        echo " First line is correct<br>";
        
        // حاول تحميل الكلاس
        try {
            require $file;
            echo " File loaded without errors<br>";
            
            if (class_exists('Config\Paths')) {
                echo " Config\Paths class exists<br>";
                
                $paths = new Config\Paths();
                echo " Paths object created<br>";
                echo "System Directory: " . $paths->systemDirectory . "<br>";
                echo "App Directory: " . $paths->appDirectory . "<br>";
                
                // تحقق من ملف bootstrap
                $bootstrap = rtrim($paths->systemDirectory, "\\/ ") . "/bootstrap.php";
                echo "Bootstrap path: $bootstrap<br>";
                
                if (file_exists($bootstrap)) {
                    echo " Bootstrap.php exists!<br>";
                } else {
                    echo " Bootstrap.php not found<br>";
                }
                
            } else {
                echo " Config\Paths class not found<br>";
            }
            
        } catch (Exception $e) {
            echo " Error loading file: " . $e->getMessage() . "<br>";
            echo "Stack trace:<br><pre>" . $e->getTraceAsString() . "</pre>";
        }
    } else {
        echo " First line should be '<?php', but got: '$firstLine'<br>";
    }
} else {
    echo " File not found<br>";
}
