<?php
echo "<h1> الاختبار النهائي</h1>";

$files = [
    "ContentSecurityPolicy.php",
    "Constants.php", 
    "Paths.php",
    "App.php"
];

foreach ($files as $file) {
    $path = __DIR__ . "/../app/Config/" . $file;
    if (file_exists($path)) {
        $content = file_get_contents($path);
        
        // تحقق من BOM
        if (strlen($content) >= 3 && 
            ord($content[0]) == 0xEF && 
            ord($content[1]) == 0xBB && 
            ord($content[2]) == 0xBF) {
            echo " $file - يحتوي على BOM<br>";
        } elseif (strpos(ltrim($content), "<?php") === 0) {
            echo " $file - صحيح<br>";
        } else {
            echo " $file - مشكلة في البنية<br>";
        }
    } else {
        echo " $file - غير موجود<br>";
    }
}

echo "<hr>";
echo "<h2><a href='/' style='color:green;font-size:24px;'> اضغط هنا للصفحة الرئيسية</a></h2>";
