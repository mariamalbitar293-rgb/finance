<?php echo "PHP Works! Time: " . date("Y-m-d H:i:s"); ?>
