<?php
// اختبار مباشر للثوابت
$file = __DIR__ . "/../app/Config/Constants.php";
echo "<h1>اختبار Constants.php</h1>";
echo "File: $file<br>";

if (file_exists($file)) {
    include $file;
    
    echo "APP_NAMESPACE: " . (defined('APP_NAMESPACE') ? APP_NAMESPACE : 'غير معرف') . "<br>";
    echo "ENVIRONMENT: " . (defined('ENVIRONMENT') ? ENVIRONMENT : 'غير معرف') . "<br>";
    echo "COMPOSER_PATH: " . (defined('COMPOSER_PATH') ? COMPOSER_PATH : 'غير معرف') . "<br>";
    
    if (defined('COMPOSER_PATH')) {
        $composerPath = constant('COMPOSER_PATH');
        echo "مسار COMPOSER_PATH: $composerPath<br>";
        
        if (file_exists($composerPath)) {
            echo " ملف autoload.php موجود!<br>";
        } else {
            echo " ملف autoload.php غير موجود في: $composerPath<br>";
        }
    }
} else {
    echo " ملف Constants.php غير موجود!<br>";
}
