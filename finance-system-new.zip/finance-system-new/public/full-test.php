<?php
echo "<h1>Complete System Test</h1>";

// Test 1: PHP
echo "<h2>1. PHP Environment</h2>";
echo "PHP Version: " . phpversion() . "<br>";
echo "Memory Limit: " . ini_get("memory_limit") . "<br>";

// Test 2: File permissions
echo "<h2>2. File Permissions</h2>";
$dirs = ["writable", "writable/cache", "writable/logs"];
foreach ($dirs as $dir) {
    if (is_writable($dir)) {
        echo " $dir is writable<br>";
    } else {
        echo " $dir is NOT writable<br>";
    }
}

// Test 3: Essential files
echo "<h2>3. Essential Files</h2>";
$files = [
    "index.php" => "public/index.php",
    "Paths.php" => "app/Config/Paths.php",
    "App.php" => "app/Config/App.php",
    "Constants.php" => "app/Config/Constants.php",
    "Autoload" => "vendor/autoload.php"
];

foreach ($files as $name => $path) {
    if (file_exists($path)) {
        echo " $name exists<br>";
    } else {
        echo " $name missing: $path<br>";
    }
}

// Test 4: Try to run CodeIgniter
echo "<h2>4. CodeIgniter Test</h2>";
try {
    define("FCPATH", __DIR__ . DIRECTORY_SEPARATOR);
    
    // Load Paths
    $pathsFile = realpath(FCPATH . "../app/Config/Paths.php");
    if (!$pathsFile) {
        throw new Exception("Paths.php not found");
    }
    
    require $pathsFile;
    $paths = new Config\Paths();
    echo " Paths loaded: " . $paths->systemDirectory . "<br>";
    
    // Check bootstrap
    $bootstrap = rtrim($paths->systemDirectory, "\\/ ") . "/bootstrap.php";
    if (file_exists($bootstrap)) {
        echo " Bootstrap exists<br>";
        
        // Try to load bootstrap
        $app = require $bootstrap;
        echo " Bootstrap loaded successfully!<br>";
        
        // Try to run
        ob_start();
        $app->run();
        $output = ob_get_clean();
        
        if (strlen($output) > 0) {
            echo " Application ran successfully<br>";
            echo "<a href='/'>Go to Home Page</a>";
        }
        
    } else {
        echo " Bootstrap not found: $bootstrap<br>";
    }
    
} catch (Throwable $e) {
    echo " Error: " . $e->getMessage() . "<br>";
    echo "<pre>Stack trace:\n" . $e->getTraceAsString() . "</pre>";
}
