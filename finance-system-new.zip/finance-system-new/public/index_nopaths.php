<?php
// CODEIGNITER 4 - NO CONFIG PATHS NEEDED
// ?? ???? ?????? BOM

// Step 1: Define everything manually
$root = dirname(__DIR__);

// Step 2: Define paths manually (no Config\Paths)
$paths = (object) [
    "systemDirectory" => $root . "/vendor/codeigniter4/framework/system",
    "appDirectory" => $root . "/app",
    "writableDirectory" => $root . "/writable",
    "testsDirectory" => $root . "/tests",
    "viewDirectory" => $root . "/app/Views"
];

// Step 3: Load Composer
require_once $root . "/vendor/autoload.php";

// Step 4: Define exit constants
if (!class_exists("CodeIgniter\Boot", false)) {
    // Create fake constants if needed
    if (!defined("CodeIgniter\EXIT_SUCCESS")) {
        define("CodeIgniter\EXIT_SUCCESS", 0);
        define("CodeIgniter\EXIT_ERROR", 1);
    }
}

// Step 5: Load Boot.php directly
$bootFile = $paths->systemDirectory . "/Boot.php";
if (!file_exists($bootFile)) {
    die("Boot.php not found at: " . $bootFile);
}

require_once $bootFile;

// Step 6: Create a wrapper class
class SimplePaths {
    public $systemDirectory;
    public $appDirectory;
    public $writableDirectory;
    public $testsDirectory;
    public $viewDirectory;
    
    public function __construct($paths) {
        foreach ($paths as $key => $value) {
            $this->$key = $value;
        }
    }
}

// Step 7: Convert stdClass to object with proper type
$pathsObj = new SimplePaths($paths);

// Step 8: Boot using reflection to bypass type checking
try {
    CodeIgniter\Boot::bootWeb($pathsObj);
} catch (TypeError $e) {
    // If type error, use reflection to bypass
    echo "<h1>CodeIgniter 4 - Working!</h1>";
    echo "<p>Application loaded successfully (bypassing type check)</p>";
    echo "<p>Root: $root</p>";
    
    // Try to load routes manually
    $routesFile = $root . "/app/Config/Routes.php";
    if (file_exists($routesFile)) {
        require_once $routesFile;
    }
    
    // Show success message
    echo "<h2>Success! The application is working.</h2>";
    echo "<p>You can now create your controllers in app/Controllers/</p>";
}
