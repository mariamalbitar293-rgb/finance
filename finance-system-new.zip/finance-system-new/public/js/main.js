// دوال عامة للـ Modals
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
}

// بيانات العملاء
let clientsData = [
    { id: 1, name: "محمد", principal: 200, paid: 100, phone: "0599123456", date: "2025-12-10", status: "partial", notes: "هون تكون عملية حسابه الكل المجموع" },
    { id: 2, name: "أحمد", principal: 500, paid: 300, phone: "0599765432", date: "2025-12-12", status: "partial", notes: "متبقي 200 دينار" }
];

// تهيئة التطبيق
document.addEventListener('DOMContentLoaded', function() {
    // عرض التاريخ
    const dateElement = document.getElementById('current-date');
    if (dateElement) {
        const now = new Date();
        dateElement.textContent = now.toLocaleDateString('ar-EG');
    }
    
    // تهيئة المستمعين
    setupEventListeners();
    
    // عرض بيانات العملاء
    if (document.getElementById('clientsTableBody')) {
        renderClientsTable();
    }
});

// إعداد مستمعي الأحداث
function setupEventListeners() {
    // تبديل الشريط الجانبي
    const toggleBtn = document.getElementById('toggleSidebarBtn');
    if (toggleBtn) {
        toggleBtn.addEventListener('click', toggleSidebar);
    }
    
    // زر الإضافة العائم
    const floatingBtn = document.getElementById('floatingAddBtn');
    if (floatingBtn) {
        floatingBtn.addEventListener('click', openAddClientModal);
    }
    
    // زر إضافة عميل
    const addBtn = document.getElementById('addClientBtn');
    if (addBtn) {
        addBtn.addEventListener('click', openAddClientModal);
    }
    
    // بحث العملاء
    const searchInput = document.getElementById('clientSearch');
    if (searchInput) {
        searchInput.addEventListener('input', searchClients);
    }
    
    // أزرار النافذة المنبثقة
    setupModalButtons();
    
    // إغلاق النافذة عند النقر خارجها
    document.querySelectorAll('.modal-overlay').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                closeModal(this.id);
            }
        });
    });
    
    // إغلاق النافذة عند الضغط على ESC
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            document.querySelectorAll('.modal-overlay').forEach(modal => {
                closeModal(modal.id);
            });
        }
    });
}

// إعداد أزرار النافذة المنبثقة
function setupModalButtons() {
    const saveBtn = document.getElementById('saveClientBtn');
    const saveAnotherBtn = document.getElementById('saveAndAddAnotherBtn');
    const cancelBtn = document.getElementById('cancelAddClientBtn');
    
    if (saveBtn) {
        saveBtn.addEventListener('click', function() {
            saveNewClient(false);
        });
    }
    
    if (saveAnotherBtn) {
        saveAnotherBtn.addEventListener('click', function() {
            saveNewClient(true);
        });
    }
    
    if (cancelBtn) {
        cancelBtn.addEventListener('click', function() {
            closeModal('addClientModal');
        });
    }
    
    // تحديث شريط التقدم
    const principalInput = document.getElementById('principalAmount');
    const paidInput = document.getElementById('paidAmount');
    
    if (principalInput) {
        principalInput.addEventListener('input', updatePaymentProgress);
    }
    
    if (paidInput) {
        paidInput.addEventListener('input', updatePaymentProgress);
    }
}

// تبديل الشريط الجانبي
function toggleSidebar() {
    document.body.classList.toggle('sidebar-collapsed');
}

// عرض بيانات العملاء
function renderClientsTable(clients = clientsData) {
    const tableBody = document.getElementById('clientsTableBody');
    if (!tableBody) return;
    
    tableBody.innerHTML = '';
    
    clients.forEach(client => {
        const remaining = client.principal - client.paid;
        
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${client.name}</td>
            <td>${client.principal.toLocaleString()} دينار</td>
            <td>${client.paid.toLocaleString()} دينار</td>
            <td>${remaining.toLocaleString()} دينار</td>
            <td>${client.notes || 'لا توجد'}</td>
            <td>${client.date}</td>
            <td>
                <button class="btn-action btn-edit" onclick="editClient(${client.id})">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn-action btn-delete" onclick="deleteClient(${client.id})">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        tableBody.appendChild(row);
    });
}

// البحث في العملاء
function searchClients() {
    const searchTerm = document.getElementById('clientSearch').value.toLowerCase();
    const filtered = clientsData.filter(client => 
        client.name.toLowerCase().includes(searchTerm) ||
        client.phone.includes(searchTerm) ||
        client.notes.toLowerCase().includes(searchTerm)
    );
    renderClientsTable(filtered);
}

// فتح نافذة إضافة عميل
function openAddClientModal() {
    // إعادة تعيين النموذج
    const form = document.getElementById('addClientForm');
    if (form) form.reset();
    
    // تعيين تاريخ اليوم
    const dateInput = document.getElementById('clientDate');
    if (dateInput) {
        dateInput.valueAsDate = new Date();
    }
    
    // إعادة تعيين ID
    const clientId = document.getElementById('clientId');
    if (clientId) clientId.value = '';
    
    // إظهار زر حفظ وإضافة آخر
    const saveAnotherBtn = document.getElementById('saveAndAddAnotherBtn');
    if (saveAnotherBtn) {
        saveAnotherBtn.style.display = 'inline-flex';
    }
    
    // تحديث شريط التقدم
    updatePaymentProgress();
    
    // فتح النافذة
    openModal('addClientModal');
    
    // التركيز على الاسم
    const nameInput = document.getElementById('clientName');
    if (nameInput) nameInput.focus();
}

// تحديث شريط التقدم
function updatePaymentProgress() {
    const principal = parseFloat(document.getElementById('principalAmount')?.value) || 0;
    const paid = parseFloat(document.getElementById('paidAmount')?.value) || 0;
    const progressBar = document.getElementById('paymentProgress');
    const percentageText = document.getElementById('paymentPercentage');
    
    if (!progressBar || !percentageText) return;
    
    if (principal > 0) {
        const percentage = Math.min(100, (paid / principal) * 100);
        progressBar.style.width = percentage + '%';
        percentageText.textContent = percentage.toFixed(1) + '%';
    } else {
        progressBar.style.width = '0%';
        percentageText.textContent = '0%';
    }
}

// حفظ عميل جديد
function saveNewClient(addAnother = false) {
    // جمع البيانات
    const name = document.getElementById('clientName')?.value.trim();
    const phone = document.getElementById('clientPhone')?.value.trim();
    const principal = parseFloat(document.getElementById('principalAmount')?.value);
    const paid = parseFloat(document.getElementById('paidAmount')?.value) || 0;
    const date = document.getElementById('clientDate')?.value;
    const notes = document.getElementById('clientNotes')?.value.trim() || '';
    
    // التحقق من البيانات
    if (!name || isNaN(principal)) {
        alert('الرجاء إدخال اسم العميل والمبلغ الأساسي');
        return;
    }
    
    if (paid > principal) {
        alert('المبلغ المدفوع لا يمكن أن يكون أكبر من المبلغ الأساسي');
        return;
    }
    
    // التحقق من التعديل
    const clientId = document.getElementById('clientId')?.value;
    
    if (clientId) {
        // تحديث عميل موجود
        updateClient(parseInt(clientId), { name, phone, principal, paid, date, notes });
        closeModal('addClientModal');
    } else {
        // إضافة جديد
        const newClient = {
            id: clientsData.length + 1,
            name,
            phone: phone || '',
            principal,
            paid,
            date: date || new Date().toISOString().split('T')[0],
            status: paid === principal ? 'paid' : paid > 0 ? 'partial' : 'pending',
            notes
        };
        
        clientsData.unshift(newClient);
        renderClientsTable();
        
        // إعادة تعيين النموذج إذا كان حفظ وإضافة آخر
        if (addAnother) {
            document.getElementById('addClientForm').reset();
            document.getElementById('clientDate').valueAsDate = new Date();
            document.getElementById('clientName').focus();
            updatePaymentProgress();
        } else {
            closeModal('addClientModal');
        }
    }
}

// تعديل عميل
function editClient(id) {
    const client = clientsData.find(c => c.id === id);
    if (!client) return;
    
    // تعبئة النموذج
    document.getElementById('clientId').value = client.id;
    document.getElementById('clientName').value = client.name;
    document.getElementById('clientPhone').value = client.phone || '';
    document.getElementById('principalAmount').value = client.principal;
    document.getElementById('paidAmount').value = client.paid;
    document.getElementById('clientDate').value = client.date;
    document.getElementById('clientNotes').value = client.notes || '';
    
    // إخفاء زر حفظ وإضافة آخر
    const saveAnotherBtn = document.getElementById('saveAndAddAnotherBtn');
    if (saveAnotherBtn) {
        saveAnotherBtn.style.display = 'none';
    }
    
    // تحديث شريط التقدم
    updatePaymentProgress();
    
    // فتح النافذة
    openModal('addClientModal');
}

// تحديث عميل
function updateClient(id, data) {
    const index = clientsData.findIndex(c => c.id === id);
    if (index !== -1) {
        clientsData[index] = {
            ...clientsData[index],
            ...data,
            status: data.paid === data.principal ? 'paid' : data.paid > 0 ? 'partial' : 'pending'
        };
        renderClientsTable();
    }
}

// حذف عميل
function deleteClient(id) {
    if (confirm('هل أنت متأكد من حذف هذا العميل؟')) {
        clientsData = clientsData.filter(c => c.id !== id);
        renderClientsTable();
    }
}

// تنسيق المبلغ
function formatCurrency(amount) {
    return `${parseFloat(amount).toLocaleString('ar-EG')} دينار`;
}