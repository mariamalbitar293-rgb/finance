// بيانات الأصول الثابتة
let assetsData = [
    {
        id: 1,
        name: "سيرفرات البيانات الرئيسية",
        type: "servers",
        serial: "SRV-001",
        purchaseDate: "2023-05-15",
        bookValue: 85000,
        marketValue: 95000,
        depreciationRate: 10,
        status: "active",
        description: "سيرفرات البيانات الرئيسية للمؤسسة بسعة تخزين عالية",
        imageUrl: ""
    },
    {
        id: 2,
        name: "سيرفر النسخ الاحتياطي",
        type: "servers",
        serial: "SRV-002",
        purchaseDate: "2022-08-22",
        bookValue: 45000,
        marketValue: 38000,
        depreciationRate: 15,
        status: "active",
        description: "سيرفر النسخ الاحتياطي للبيانات الهامة",
        imageUrl: ""
    },
    {
        id: 3,
        name: "معدات الشبكة والاتصال",
        type: "equipment",
        serial: "NET-001",
        purchaseDate: "2024-01-10",
        bookValue: 28500,
        marketValue: 32000,
        depreciationRate: 20,
        status: "active",
        description: "معدات الشبكة والاتصال المتقدمة",
        imageUrl: ""
    },
    {
        id: 4,
        name: "مبنى المقر الرئيسي",
        type: "property",
        serial: "BLD-001",
        purchaseDate: "2020-03-05",
        bookValue: 120000,
        marketValue: 185000,
        depreciationRate: 2,
        status: "active",
        description: "مبنى المقر الرئيسي للمؤسسة بمساحة 500 متر مربع",
        imageUrl: ""
    },
    {
        id: 5,
        name: "سيارات الشركة",
        type: "vehicles",
        serial: "CAR-001",
        purchaseDate: "2021-11-18",
        bookValue: 35000,
        marketValue: 28000,
        depreciationRate: 25,
        status: "active",
        description: "سيارات الشركة للنقل والمواصلات",
        imageUrl: ""
    },
    {
        id: 6,
        name: "أجهزة الكمبيوتر المكتبية",
        type: "equipment",
        serial: "COM-001",
        purchaseDate: "2023-09-12",
        bookValue: 15000,
        marketValue: 12000,
        depreciationRate: 30,
        status: "active",
        description: "أجهزة كمبيوتر مكتبية للموظفين",
        imageUrl: ""
    }
];

// تهيئة إدارة الأصول
function initAssetsManagement() {
    renderAssetsGrid();
    setupAssetsEventListeners();
    updateAssetsStats();
}

// وظيفة عرض بيانات الأصول في الشبكة
function renderAssetsGrid(assets = assetsData) {
    const assetsGrid = document.getElementById('assetsGrid');
    if (!assetsGrid) return;
    
    assetsGrid.innerHTML = '';
    
    assets.forEach(asset => {
        // حساب القيمة بعد الإهلاك
        const purchaseDate = new Date(asset.purchaseDate);
        const currentDate = new Date();
        const yearsDiff = (currentDate - purchaseDate) / (1000 * 60 * 60 * 24 * 365);
        const depreciation = (asset.bookValue * asset.depreciationRate / 100) * yearsDiff;
        const depreciatedValue = Math.max(0, asset.bookValue - depreciation);
        
        // نوع الأصل بالعربية
        let typeText = '';
        switch(asset.type) {
            case 'servers': typeText = 'سيرفرات'; break;
            case 'equipment': typeText = 'معدات'; break;
            case 'property': typeText = 'عقارات'; break;
            case 'vehicles': typeText = 'مركبات'; break;
            default: typeText = asset.type;
        }
        
        // أيقونة حسب النوع
        let icon = '';
        switch(asset.type) {
            case 'servers': icon = 'fa-server'; break;
            case 'equipment': icon = 'fa-desktop'; break;
            case 'property': icon = 'fa-building'; break;
            case 'vehicles': icon = 'fa-car'; break;
            default: icon = 'fa-box';
        }
        
        const assetCard = document.createElement('div');
        assetCard.className = 'asset-card';
        assetCard.innerHTML = `
            <div class="asset-image">
                ${asset.imageUrl ? 
                    `<img src="${asset.imageUrl}" alt="${asset.name}">` : 
                    `<i class="fas ${icon}"></i>`
                }
            </div>
            <div class="asset-details">
                <h3>${asset.name}</h3>
                <div class="asset-meta">
                    <span>${typeText}</span>
                    <span>${asset.serial}</span>
                </div>
                <div class="asset-value">${asset.bookValue.toLocaleString()} دينار</div>
                <div style="margin-bottom: 15px;">
                    <small style="color: var(--gray-color);">القيمة السوقية: ${asset.marketValue.toLocaleString()} دينار</small><br>
                    <small style="color: var(--gray-color);">القيمة بعد الإهلاك: ${depreciatedValue.toLocaleString()} دينار</small>
                </div>
                <div class="asset-status ${asset.status}">
                    ${asset.status === 'active' ? 'نشط' : 'غير نشط'}
                </div>
                <div style="margin-top: 15px; display: flex; gap: 10px;">
                    <button class="btn btn-secondary tooltip" style="padding: 6px 12px; font-size: 0.9rem; flex: 1;" onclick="editAsset(${asset.id})" data-tooltip="تعديل">
                        <i class="fas fa-edit"></i> تعديل
                    </button>
                    <button class="btn btn-danger tooltip" style="padding: 6px 12px; font-size: 0.9rem; flex: 1;" onclick="deleteAsset(${asset.id})" data-tooltip="حذف">
                        <i class="fas fa-trash"></i> حذف
                    </button>
                </div>
            </div>
        `;
        
        assetsGrid.appendChild(assetCard);
    });
}

// تحديث إحصائيات الأصول
function updateAssetsStats() {
    const totalBookValue = assetsData.reduce((sum, asset) => sum + asset.bookValue, 0);
    const totalMarketValue = assetsData.reduce((sum, asset) => sum + asset.marketValue, 0);
    const activeCount = assetsData.filter(asset => asset.status === 'active').length;
    
    // حساب الإهلاك السنوي الإجمالي
    const totalDepreciation = assetsData.reduce((sum, asset) => {
        return sum + (asset.bookValue * (asset.depreciationRate / 100));
    }, 0);
    
    // تحديث العناصر
    const totalAssetsValueElement = document.getElementById('totalAssetsValue');
    const totalMarketValueElement = document.getElementById('totalMarketValue');
    const annualDepreciationElement = document.getElementById('annualDepreciation');
    const activeAssetsElement = document.getElementById('activeAssets');
    const assetsBadgeElement = document.getElementById('assetsBadge');
    
    if (totalAssetsValueElement) {
        totalAssetsValueElement.innerHTML = `${totalBookValue.toLocaleString()} <span style="font-size: 1rem;">دينار</span>`;
    }
    
    if (totalMarketValueElement) {
        totalMarketValueElement.innerHTML = `${totalMarketValue.toLocaleString()} <span style="font-size: 1rem;">دينار</span>`;
    }
    
    if (annualDepreciationElement) {
        annualDepreciationElement.innerHTML = `${totalDepreciation.toLocaleString()} <span style="font-size: 1rem;">دينار</span>`;
    }
    
    if (activeAssetsElement) {
        activeAssetsElement.innerHTML = activeCount;
    }
    
    if (assetsBadgeElement) {
        assetsBadgeElement.innerHTML = activeCount;
    }
}

// إعداد مستمعي الأحداث للأصول
function setupAssetsEventListeners() {
    // فلترة البحث في الأصول
    const assetSearch = document.getElementById('assetSearch');
    if (assetSearch) {
        assetSearch.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const filteredAssets = assetsData.filter(asset => 
                asset.name.toLowerCase().includes(searchTerm) || 
                asset.serial.toLowerCase().includes(searchTerm) ||
                asset.description.toLowerCase().includes(searchTerm)
            );
            renderAssetsGrid(filteredAssets);
        });
    }
    
    // فلترة حسب نوع الأصل
    const assetTypeFilter = document.getElementById('assetTypeFilter');
    if (assetTypeFilter) {
        assetTypeFilter.addEventListener('change', function() {
            const type = this.value;
            let filteredAssets = [];
            
            if (type === 'all') {
                filteredAssets = assetsData;
            } else {
                filteredAssets = assetsData.filter(a => a.type === type);
            }
            
            renderAssetsGrid(filteredAssets);
        });
    }
    
    // فتح نافذة إضافة أصل جديد
    const addAssetBtn = document.getElementById('addAssetBtn');
    if (addAssetBtn) {
        addAssetBtn.addEventListener('click', openAddAssetModal);
    }
    
    // حفظ أصل جديد
    const saveAssetBtn = document.getElementById('saveAssetBtn');
    if (saveAssetBtn) {
        saveAssetBtn.addEventListener('click', saveNewAsset);
    }
    
    // إغلاق نافذة إضافة أصل
    const closeAssetModalBtn = document.getElementById('closeAssetModalBtn');
    const cancelAddAssetBtn = document.getElementById('cancelAddAssetBtn');
    
    if (closeAssetModalBtn) {
        closeAssetModalBtn.addEventListener('click', closeAddAssetModal);
    }
    
    if (cancelAddAssetBtn) {
        cancelAddAssetBtn.addEventListener('click', closeAddAssetModal);
    }
    
    // تصدير بيانات الأصول
    const exportAssetsBtn = document.getElementById('exportAssetsBtn');
    if (exportAssetsBtn) {
        exportAssetsBtn.addEventListener('click', exportAssetsData);
    }
}

// فتح نافذة إضافة أصل جديد
function openAddAssetModal() {
    openModal('addAssetModal');
    const assetNameInput = document.getElementById('assetName');
    if (assetNameInput) assetNameInput.focus();
    
    // تعيين تاريخ اليوم كقيمة افتراضية
    const purchaseDateInput = document.getElementById('purchaseDate');
    if (purchaseDateInput) purchaseDateInput.valueAsDate = new Date();
    
    showNotification('فتح نموذج إضافة أصل جديد');
}

// إغلاق نافذة إضافة أصل جديد
function closeAddAssetModal() {
    closeModal('addAssetModal');
    const form = document.getElementById('addAssetForm');
    if (form) form.reset();
    
    const purchaseDateInput = document.getElementById('purchaseDate');
    if (purchaseDateInput) purchaseDateInput.valueAsDate = new Date();
    
    // إعادة تعيين زر الحفظ
    const saveAssetBtn = document.getElementById('saveAssetBtn');
    if (saveAssetBtn) {
        saveAssetBtn.innerHTML = '<i class="fas fa-save"></i> حفظ الأصل';
        saveAssetBtn.onclick = saveNewAsset;
    }
}

// حفظ أصل جديد
function saveNewAsset() {
    const name = document.getElementById('assetName')?.value.trim();
    const type = document.getElementById('assetType')?.value;
    const serial = document.getElementById('assetSerial')?.value.trim();
    const purchaseDate = document.getElementById('purchaseDate')?.value;
    const bookValue = parseFloat(document.getElementById('bookValue')?.value);
    const marketValue = parseFloat(document.getElementById('marketValue')?.value);
    const depreciationRate = parseFloat(document.getElementById('depreciationRate')?.value);
    const status = document.getElementById('assetStatus')?.value;
    const description = document.getElementById('assetDescription')?.value.trim();
    const imageUrl = document.getElementById('assetImageUrl')?.value.trim();
    
    // التحقق من صحة البيانات
    if (!name || !serial || !purchaseDate || !bookValue || !marketValue) {
        showNotification('الرجاء ملء جميع الحقول المطلوبة بشكل صحيح', 'error');
        return;
    }
    
    if (bookValue < 0 || marketValue < 0 || depreciationRate < 0) {
        showNotification('القيم يجب أن تكون أرقاماً موجبة', 'error');
        return;
    }
    
    if (depreciationRate > 100) {
        showNotification('نسبة الإهلاك يجب أن تكون بين 0 و 100', 'error');
        return;
    }
    
    // التحقق من ID الأصل (للتحرير)
    const assetIdInput = document.getElementById('assetId');
    const assetId = assetIdInput ? parseInt(assetIdInput.value) : null;
    
    if (assetId) {
        // تحديث أصل موجود
        updateAsset(assetId, { 
            name, type, serial, purchaseDate, bookValue, marketValue, 
            depreciationRate, status, description, imageUrl 
        });
    } else {
        // إضافة أصل جديد
        const newAsset = {
            id: assetsData.length > 0 ? Math.max(...assetsData.map(a => a.id)) + 1 : 1,
            name: name,
            type: type,
            serial: serial,
            purchaseDate: purchaseDate,
            bookValue: bookValue,
            marketValue: marketValue,
            depreciationRate: depreciationRate,
            status: status,
            description: description || 'لا يوجد وصف',
            imageUrl: imageUrl || ''
        };
        
        assetsData.unshift(newAsset);
        renderAssetsGrid();
        updateAssetsStats();
        showNotification(`تم إضافة الأصل ${name} بنجاح`);
    }
    
    closeAddAssetModal();
}

// وظيفة تعديل أصل
function editAsset(id) {
    const asset = assetsData.find(a => a.id === id);
    if (!asset) return;
    
    // تعبئة النموذج ببيانات الأصل
    document.getElementById('assetId').value = asset.id;
    document.getElementById('assetName').value = asset.name;
    document.getElementById('assetType').value = asset.type;
    document.getElementById('assetSerial').value = asset.serial;
    document.getElementById('purchaseDate').value = asset.purchaseDate;
    document.getElementById('bookValue').value = asset.bookValue;
    document.getElementById('marketValue').value = asset.marketValue;
    document.getElementById('depreciationRate').value = asset.depreciationRate;
    document.getElementById('assetStatus').value = asset.status;
    document.getElementById('assetDescription').value = asset.description || '';
    document.getElementById('assetImageUrl').value = asset.imageUrl || '';
    
    // تغيير نص الزر
    const saveAssetBtn = document.getElementById('saveAssetBtn');
    if (saveAssetBtn) {
        saveAssetBtn.innerHTML = '<i class="fas fa-save"></i> تحديث البيانات';
        saveAssetBtn.onclick = saveNewAsset;
    }
    
    // فتح النافذة
    openModal('addAssetModal');
    showNotification('فتح نموذج تعديل بيانات الأصل');
}

// تحديث بيانات الأصل
function updateAsset(id, data) {
    const assetIndex = assetsData.findIndex(a => a.id === id);
    if (assetIndex !== -1) {
        assetsData[assetIndex] = {
            id: id,
            name: data.name,
            type: data.type,
            serial: data.serial,
            purchaseDate: data.purchaseDate,
            bookValue: data.bookValue,
            marketValue: data.marketValue,
            depreciationRate: data.depreciationRate,
            status: data.status,
            description: data.description || 'لا يوجد وصف',
            imageUrl: data.imageUrl || ''
        };
        
        renderAssetsGrid();
        updateAssetsStats();
        showNotification(`تم تحديث بيانات الأصل ${data.name} بنجاح`);
    }
}

// وظيفة حذف أصل
function deleteAsset(id) {
    if (confirm('هل أنت متأكد من حذف هذا الأصل؟')) {
        assetsData = assetsData.filter(a => a.id !== id);
        renderAssetsGrid();
        updateAssetsStats();
        showNotification('تم حذف الأصل بنجاح');
    }
}

// تصدير بيانات الأصول
function exportAssetsData() {
    const dataStr = JSON.stringify(assetsData, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `assets-data-${new Date().toISOString().split('T')[0]}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
    
    showNotification('تم تصدير بيانات الأصول بنجاح');
}

// حساب إهلاك الأصل
function calculateDepreciation(asset, asOfDate = new Date()) {
    const purchaseDate = new Date(asset.purchaseDate);
    const yearsDiff = (asOfDate - purchaseDate) / (1000 * 60 * 60 * 24 * 365);
    const depreciation = (asset.bookValue * asset.depreciationRate / 100) * yearsDiff;
    const depreciatedValue = Math.max(0, asset.bookValue - depreciation);
    
    return {
        years: yearsDiff,
        depreciation: depreciation,
        currentValue: depreciatedValue
    };
}

// تحديث القيم السوقية تلقائياً
function updateMarketValues() {
    assetsData.forEach(asset => {
        // في تطبيق حقيقي، هنا ستجلب القيم من خدمة خارجية
        // حالياً، سنقوم بمحاكاة تغيير طفيف في القيمة
        const change = (Math.random() * 0.1) - 0.05; // تغيير بين -5% و +5%
        asset.marketValue = Math.round(asset.marketValue * (1 + change));
    });
    
    renderAssetsGrid();
    updateAssetsStats();
    showNotification('تم تحديث القيم السوقية للأصول');
}

// إنشاء تقرير الإهلاك
function generateDepreciationReport() {
    const report = assetsData.map(asset => {
        const dep = calculateDepreciation(asset);
        return {
            'اسم الأصل': asset.name,
            'النوع': asset.type,
            'الرقم التسلسلي': asset.serial,
            'تاريخ الشراء': asset.purchaseDate,
            'القيمة الدفترية': asset.bookValue,
            'نسبة الإهلاك (%)': asset.depreciationRate,
            'عدد السنوات': dep.years.toFixed(2),
            'مجموع الإهلاك': dep.depreciation.toFixed(2),
            'القيمة الحالية': dep.currentValue.toFixed(2)
        };
    });
    
    return report;
}