// البيانات الأصلية
let clientsData = [
    { id: 1, name: "محمد", principal: 200, paid: 100, phone: "0599123456", date: "2025-12-10", status: "partial", notes: "هون تكون عملية حسابه الكل المجموع" },
    { id: 2, name: "أحمد", principal: 500, paid: 300, phone: "0599765432", date: "2025-12-12", status: "partial", notes: "متبقي 200 دينار" },
    { id: 3, name: "سارة", principal: 300, paid: 300, phone: "0599888777", date: "2025-12-05", status: "paid", notes: "مسدد بالكامل" },
    { id: 4, name: "محمد علي", principal: 450, paid: 200, phone: "0599333444", date: "2025-11-28", status: "partial", notes: "متبقي 250 دينار" },
    { id: 5, name: "فاطمة", principal: 600, paid: 400, phone: "0599555666", date: "2025-11-20", status: "partial", notes: "متبقي 200 دينار" },
    { id: 6, name: "خالد", principal: 350, paid: 150, phone: "0599777888", date: "2025-11-15", status: "partial", notes: "متبقي 200 دينار" },
    { id: 7, name: "نورا", principal: 200, paid: 200, phone: "0599222111", date: "2025-11-10", status: "paid", notes: "مسدد بالكامل" },
    { id: 8, name: "علي", principal: 200, paid: 100, phone: "0599444555", date: "2025-11-05", status: "partial", notes: "متبقي 100 دينار" }
];

// تهيئة إدارة العملاء
function initClientsManagement() {
    renderClientsTable();
    setupClientsEventListeners();
}

// وظيفة عرض بيانات العملاء في الجدول
function renderClientsTable(clients = clientsData) {
    const tableBody = document.getElementById('clientsTableBody');
    if (!tableBody) return;
    
    tableBody.innerHTML = '';
    
    clients.forEach(client => {
        const remaining = client.principal - client.paid;
        const row = document.createElement('tr');
        
        row.innerHTML = `
            <td>
                <strong>${client.name}</strong>
                ${client.phone ? `<br><small style="color: var(--gray-color);">${client.phone}</small>` : ''}
            </td>
            <td>${client.principal.toLocaleString()} دينار</td>
            <td>${client.paid.toLocaleString()} دينار</td>
            <td>${remaining.toLocaleString()} دينار</td>
            <td>${client.notes}</td>
            <td>${client.date}</td>
            <td>
                <button class="btn btn-secondary tooltip" style="padding: 6px 12px; font-size: 0.9rem;" onclick="editClient(${client.id})" data-tooltip="تعديل">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-danger tooltip" style="padding: 6px 12px; font-size: 0.9rem;" onclick="deleteClient(${client.id})" data-tooltip="حذف">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        
        tableBody.appendChild(row);
    });
    
    // تحديث الإحصائيات
    updateClientsStats(clients);
}

// تحديث إحصائيات العملاء
function updateClientsStats(clients = clientsData) {
    const totalPrincipal = clients.reduce((sum, client) => sum + client.principal, 0);
    const totalPaid = clients.reduce((sum, client) => sum + client.paid, 0);
    const totalRemaining = totalPrincipal - totalPaid;
    
    // تحديث بطاقات الإحصائيات
    const totalPrincipalElement = document.getElementById('totalPrincipal');
    const totalPaidElement = document.getElementById('totalPaid');
    const totalRemainingElement = document.getElementById('totalRemaining');
    const totalClientsElement = document.getElementById('totalClients');
    const clientBadgeElement = document.getElementById('clientBadge');
    
    if (totalPrincipalElement) {
        totalPrincipalElement.innerHTML = `${totalPrincipal.toLocaleString()} <span style="font-size: 1rem;">دينار</span>`;
    }
    
    if (totalPaidElement) {
        totalPaidElement.innerHTML = `${totalPaid.toLocaleString()} <span style="font-size: 1rem;">دينار</span>`;
    }
    
    if (totalRemainingElement) {
        totalRemainingElement.innerHTML = `${totalRemaining.toLocaleString()} <span style="font-size: 1rem;">دينار</span>`;
    }
    
    if (totalClientsElement) {
        totalClientsElement.innerHTML = clients.length;
    }
    
    if (clientBadgeElement) {
        clientBadgeElement.innerHTML = clients.length;
    }
}

// إعداد مستمعي الأحداث للعملاء
function setupClientsEventListeners() {
    // فلترة البحث في العملاء
    const clientSearch = document.getElementById('clientSearch');
    if (clientSearch) {
        clientSearch.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const filteredClients = clientsData.filter(client => 
                client.name.toLowerCase().includes(searchTerm) || 
                (client.phone && client.phone.includes(searchTerm)) ||
                client.notes.toLowerCase().includes(searchTerm)
            );
            renderClientsTable(filteredClients);
        });
    }
    
    // فلترة حسب الحالة
    const statusFilter = document.getElementById('statusFilter');
    if (statusFilter) {
        statusFilter.addEventListener('change', function() {
            const status = this.value;
            let filteredClients = [];
            
            if (status === 'all') {
                filteredClients = clientsData;
            } else if (status === 'paid') {
                filteredClients = clientsData.filter(client => client.principal === client.paid);
            } else if (status === 'partial') {
                filteredClients = clientsData.filter(client => client.paid > 0 && client.paid < client.principal);
            } else if (status === 'pending') {
                filteredClients = clientsData.filter(client => client.paid === 0);
            }
            
            renderClientsTable(filteredClients);
        });
    }
    
    // تحديث شريط التقدم بناءً على المبالغ المدخلة
    const principalInput = document.getElementById('principalAmount');
    const paidInput = document.getElementById('paidAmount');
    
    if (principalInput) {
        principalInput.addEventListener('input', updatePaymentProgress);
    }
    
    if (paidInput) {
        paidInput.addEventListener('input', updatePaymentProgress);
    }
    
    // أزرار إضافة العملاء
    const addClientBtn = document.getElementById('addClientBtn');
    const floatingAddBtn = document.getElementById('floatingAddBtn');
    
    if (addClientBtn) {
        addClientBtn.addEventListener('click', openAddClientModal);
    }
    
    if (floatingAddBtn) {
        floatingAddBtn.addEventListener('click', openAddClientModal);
    }
    
    // حفظ عميل جديد
    const saveClientBtn = document.getElementById('saveClientBtn');
    const saveAndAddAnotherBtn = document.getElementById('saveAndAddAnotherBtn');
    
    if (saveClientBtn) {
        saveClientBtn.addEventListener('click', () => saveNewClient(false));
    }
    
    if (saveAndAddAnotherBtn) {
        saveAndAddAnotherBtn.addEventListener('click', () => saveNewClient(true));
    }
    
    // إغلاق نافذة إضافة عميل
    const closeModalBtn = document.getElementById('closeModalBtn');
    const cancelAddClientBtn = document.getElementById('cancelAddClientBtn');
    
    if (closeModalBtn) {
        closeModalBtn.addEventListener('click', closeAddClientModal);
    }
    
    if (cancelAddClientBtn) {
        cancelAddClientBtn.addEventListener('click', closeAddClientModal);
    }
}

// فتح نافذة إضافة عميل جديد
function openAddClientModal() {
    openModal('addClientModal');
    const clientNameInput = document.getElementById('clientName');
    if (clientNameInput) clientNameInput.focus();
    updatePaymentProgress();
    showNotification('فتح نموذج إضافة عميل جديد');
}

// إغلاق نافذة إضافة عميل جديد
function closeAddClientModal() {
    closeModal('addClientModal');
    const form = document.getElementById('addClientForm');
    if (form) form.reset();
    
    const clientDateInput = document.getElementById('clientDate');
    if (clientDateInput) clientDateInput.valueAsDate = new Date();
    
    // إعادة تعيين زر الحفظ
    const saveClientBtn = document.getElementById('saveClientBtn');
    if (saveClientBtn) {
        saveClientBtn.innerHTML = '<i class="fas fa-save"></i> حفظ العميل';
        saveClientBtn.onclick = () => saveNewClient(false);
    }
    
    // إظهار زر حفظ وإضافة آخر
    const saveAndAddAnotherBtn = document.getElementById('saveAndAddAnotherBtn');
    if (saveAndAddAnotherBtn) {
        saveAndAddAnotherBtn.style.display = 'inline-flex';
    }
}

// تحديث شريط تقدم السداد
function updatePaymentProgress() {
    const principalInput = document.getElementById('principalAmount');
    const paidInput = document.getElementById('paidAmount');
    const progressBar = document.getElementById('paymentProgress');
    const percentageText = document.getElementById('paymentPercentage');
    
    if (!principalInput || !paidInput || !progressBar || !percentageText) return;
    
    const principal = parseFloat(principalInput.value) || 0;
    const paid = parseFloat(paidInput.value) || 0;
    
    if (principal > 0) {
        const percentage = Math.min(100, (paid / principal) * 100);
        
        progressBar.style.width = percentage + '%';
        percentageText.textContent = percentage.toFixed(1) + '%';
        
        // تغيير لون شريط التقدم بناءً على النسبة
        if (percentage === 100) {
            progressBar.style.background = 'linear-gradient(90deg, var(--success-color), #27ae60)';
            percentageText.style.color = 'var(--success-color)';
        } else if (percentage > 0) {
            progressBar.style.background = 'linear-gradient(90deg, var(--warning-color), #e67e22)';
            percentageText.style.color = 'var(--warning-color)';
        } else {
            progressBar.style.background = 'linear-gradient(90deg, var(--primary-color), var(--secondary-color))';
            percentageText.style.color = 'var(--primary-color)';
        }
    } else {
        progressBar.style.width = '0%';
        percentageText.textContent = '0%';
    }
}

// حفظ عميل جديد
function saveNewClient(addAnother = false) {
    const name = document.getElementById('clientName')?.value.trim();
    const phone = document.getElementById('clientPhone')?.value.trim();
    const principal = parseFloat(document.getElementById('principalAmount')?.value);
    const paid = parseFloat(document.getElementById('paidAmount')?.value);
    const date = document.getElementById('clientDate')?.value;
    const status = document.getElementById('clientStatus')?.value;
    const notes = document.getElementById('clientNotes')?.value.trim();
    
    // التحقق من صحة البيانات
    if (!name || !principal || paid < 0) {
        showNotification('الرجاء ملء جميع الحقول المطلوبة بشكل صحيح', 'error');
        return;
    }
    
    if (paid > principal) {
        showNotification('المبلغ المدفوع لا يمكن أن يكون أكبر من المبلغ الأساسي', 'error');
        return;
    }
    
    // التحقق من ID العميل (للتحرير)
    const clientIdInput = document.getElementById('clientId');
    const clientId = clientIdInput ? parseInt(clientIdInput.value) : null;
    
    if (clientId) {
        // تحديث عميل موجود
        updateClient(clientId, { name, phone, principal, paid, date, status, notes });
    } else {
        // إضافة عميل جديد
        const newClient = {
            id: clientsData.length > 0 ? Math.max(...clientsData.map(c => c.id)) + 1 : 1,
            name: name,
            phone: phone,
            principal: principal,
            paid: paid,
            date: date,
            status: status,
            notes: notes || 'لا توجد ملاحظات'
        };
        
        clientsData.unshift(newClient);
        renderClientsTable();
        showNotification(`تم إضافة العميل ${name} بنجاح`);
    }
    
    if (addAnother) {
        // تصفير النموذج للاستمرار في الإضافة
        const form = document.getElementById('addClientForm');
        if (form) {
            form.reset();
            const clientDateInput = document.getElementById('clientDate');
            if (clientDateInput) clientDateInput.valueAsDate = new Date();
            const clientNameInput = document.getElementById('clientName');
            if (clientNameInput) clientNameInput.focus();
            updatePaymentProgress();
            
            // إعادة تعيين ID العميل
            if (clientIdInput) clientIdInput.value = '';
        }
    } else {
        closeAddClientModal();
    }
}

// وظيفة تعديل عميل
function editClient(id) {
    const client = clientsData.find(c => c.id === id);
    if (!client) return;
    
    // تعبئة النموذج ببيانات العميل
    document.getElementById('clientId').value = client.id;
    document.getElementById('clientName').value = client.name;
    document.getElementById('clientPhone').value = client.phone || '';
    document.getElementById('principalAmount').value = client.principal;
    document.getElementById('paidAmount').value = client.paid;
    document.getElementById('clientDate').value = client.date;
    document.getElementById('clientStatus').value = client.status;
    document.getElementById('clientNotes').value = client.notes || '';
    
    // تغيير نص الزر
    const saveClientBtn = document.getElementById('saveClientBtn');
    if (saveClientBtn) {
        saveClientBtn.innerHTML = '<i class="fas fa-save"></i> تحديث البيانات';
        saveClientBtn.onclick = () => saveNewClient(false);
    }
    
    // إخفاء زر حفظ وإضافة آخر
    const saveAndAddAnotherBtn = document.getElementById('saveAndAddAnotherBtn');
    if (saveAndAddAnotherBtn) {
        saveAndAddAnotherBtn.style.display = 'none';
    }
    
    // تحديث شريط التقدم
    updatePaymentProgress();
    
    // فتح النافذة
    openModal('addClientModal');
    showNotification('فتح نموذج تعديل بيانات العميل');
}

// تحديث بيانات العميل
function updateClient(id, data) {
    const clientIndex = clientsData.findIndex(c => c.id === id);
    if (clientIndex !== -1) {
        clientsData[clientIndex] = {
            id: id,
            name: data.name,
            phone: data.phone,
            principal: data.principal,
            paid: data.paid,
            date: data.date,
            status: data.status,
            notes: data.notes || 'لا توجد ملاحظات'
        };
        
        renderClientsTable();
        showNotification(`تم تحديث بيانات العميل ${data.name} بنجاح`);
    }
}

// وظيفة حذف عميل
function deleteClient(id) {
    if (confirm('هل أنت متأكد من حذف هذا العميل؟')) {
        clientsData = clientsData.filter(c => c.id !== id);
        renderClientsTable();
        showNotification('تم حذف العميل بنجاح');
    }
}

// تصدير بيانات العملاء
function exportClientsData() {
    const dataStr = JSON.stringify(clientsData, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `clients-data-${new Date().toISOString().split('T')[0]}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
    
    showNotification('تم تصدير بيانات العملاء بنجاح');
}

// استيراد بيانات العملاء
function importClientsData(file) {
    const reader = new FileReader();
    
    reader.onload = function(e) {
        try {
            const importedData = JSON.parse(e.target.result);
            if (Array.isArray(importedData)) {
                clientsData = importedData;
                renderClientsTable();
                showNotification('تم استيراد بيانات العملاء بنجاح');
            } else {
                showNotification('تنسيق الملف غير صحيح', 'error');
            }
        } catch (error) {
            showNotification('حدث خطأ في قراءة الملف', 'error');
        }
    };
    
    reader.readAsText(file);
}