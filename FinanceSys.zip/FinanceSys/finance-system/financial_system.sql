-- إنشاء قاعدة البيانات (اختياري)
CREATE DATABASE IF NOT EXISTS financial_system 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_general_ci;

-- استخدام قاعدة البيانات
USE financial_system;

-- جدول العملاء
CREATE TABLE IF NOT EXISTS `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `principal` decimal(10,2) NOT NULL,
  `paid` decimal(10,2) NOT NULL DEFAULT '0.00',
  `date` date NOT NULL,
  `status` enum('paid','partial','pending') DEFAULT 'partial',
  `notes` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- جدول الالتزامات
CREATE TABLE IF NOT EXISTS `commitments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` enum('monthly','yearly','debt','loan','deduction') NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_day` int(2) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `recipient` varchar(255) DEFAULT NULL,
  `status` enum('active','pending','completed') DEFAULT 'active',
  `notes` text,
  `paid_amount` decimal(10,2) DEFAULT '0.00',
  `monthly_payment` decimal(10,2) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- جدول الأصول الثابتة
CREATE TABLE IF NOT EXISTS `assets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` enum('servers','equipment','property','vehicles','other') NOT NULL,
  `serial` varchar(100) NOT NULL,
  `purchase_date` date NOT NULL,
  `book_value` decimal(10,2) NOT NULL,
  `market_value` decimal(10,2) NOT NULL,
  `depreciation_rate` decimal(5,2) DEFAULT '10.00',
  `status` enum('active','inactive','maintenance') DEFAULT 'active',
  `description` text,
  `image_url` varchar(500) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `serial` (`serial`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- جدول الرواتب
CREATE TABLE IF NOT EXISTS `salaries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_name` varchar(255) NOT NULL,
  `basic_salary` decimal(10,2) NOT NULL,
  `bonuses` decimal(10,2) DEFAULT '0.00',
  `deductions` decimal(10,2) DEFAULT '0.00',
  `net_salary` decimal(10,2) NOT NULL,
  `payment_date` date NOT NULL,
  `status` enum('paid','pending','overdue') DEFAULT 'pending',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- جدول التقارير السنوية
CREATE TABLE IF NOT EXISTS `yearly_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `year` year(4) NOT NULL,
  `revenue` decimal(10,2) NOT NULL,
  `expenses` decimal(10,2) NOT NULL,
  `profit` decimal(10,2) NOT NULL,
  `budget_data` json DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `year` (`year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- إدراج بيانات العملاء
INSERT INTO `clients` (`name`, `phone`, `principal`, `paid`, `date`, `status`, `notes`) VALUES
('محمد', '0599123456', 200.00, 100.00, '2025-12-10', 'partial', 'هون تكون عملية حسابه الكل المجموع'),
('أحمد', '0599765432', 500.00, 300.00, '2025-12-12', 'partial', 'متبقي 200 دينار'),
('سارة', '0599888777', 300.00, 300.00, '2025-12-05', 'paid', 'مسدد بالكامل'),
('محمد علي', '0599333444', 450.00, 200.00, '2025-11-28', 'partial', 'متبقي 250 دينار'),
('فاطمة', '0599555666', 600.00, 400.00, '2025-11-20', 'partial', 'متبقي 200 دينار'),
('خالد', '0599777888', 350.00, 150.00, '2025-11-15', 'partial', 'متبقي 200 دينار'),
('نورا', '0599222111', 200.00, 200.00, '2025-11-10', 'paid', 'مسدد بالكامل'),
('علي', '0599444555', 200.00, 100.00, '2025-11-05', 'partial', 'متبقي 100 دينار');

-- إدراج بيانات الالتزامات
INSERT INTO `commitments` (`name`, `type`, `amount`, `payment_day`, `start_date`, `end_date`, `recipient`, `status`, `notes`, `paid_amount`, `monthly_payment`) VALUES
('إيجار المحل التجاري', 'monthly', 2000.00, 5, '2024-01-01', NULL, 'شركة الأموال للتجارة', 'active', 'إيجار شهري للمحل الرئيسي', NULL, NULL),
('رواتب الموظفين', 'monthly', 2400.00, 10, '2024-01-01', NULL, 'موظفو الشركة', 'active', 'رواتب شهرية لـ 5 موظفين', NULL, NULL),
('فواتير المياه والكهرباء', 'monthly', 300.00, 15, '2024-01-01', NULL, 'شركة الكهرباء الوطنية', 'active', 'فاتورة شهرية للخدمات', NULL, NULL),
('ديون بنكية - قرض تجاري', 'debt', 10000.00, 25, '2024-06-01', '2026-12-01', 'البنك التجاري الوطني', 'active', 'قرض تجاري لمدة 30 شهرًا', 4000.00, 500.00);

-- إدراج بيانات الأصول
INSERT INTO `assets` (`name`, `type`, `serial`, `purchase_date`, `book_value`, `market_value`, `depreciation_rate`, `status`, `description`, `image_url`) VALUES
('سيرفرات البيانات الرئيسية', 'servers', 'SRV-001', '2023-05-15', 85000.00, 95000.00, 10.00, 'active', 'سيرفرات البيانات الرئيسية للمؤسسة بسعة تخزين عالية', NULL),
('مبنى المقر الرئيسي', 'property', 'BLD-001', '2020-03-05', 120000.00, 185000.00, 2.00, 'active', 'مبنى المقر الرئيسي للمؤسسة بمساحة 500 متر مربع', NULL),
('معدات الشبكة والاتصال', 'equipment', 'NET-001', '2024-01-10', 28500.00, 32000.00, 20.00, 'active', 'معدات الشبكة والاتصال المتقدمة', NULL),
('سيارات الشركة', 'vehicles', 'CAR-001', '2021-11-18', 35000.00, 28000.00, 25.00, 'active', 'سيارات الشركة للنقل والمواصلات', NULL);

-- إدراج بيانات الرواتب
INSERT INTO `salaries` (`employee_name`, `basic_salary`, `bonuses`, `deductions`, `net_salary`, `payment_date`, `status`) VALUES
('أحمد محمد', 1200.00, 150.00, 50.00, 1300.00, '2025-12-05', 'paid'),
('سارة خالد', 1500.00, 200.00, 75.00, 1625.00, '2025-12-05', 'paid'),
('محمد علي', 900.00, 100.00, 30.00, 970.00, '2025-12-05', 'paid'),
('فاطمة حسين', 800.00, 80.00, 25.00, 855.00, '2025-12-05', 'paid'),
('خالد وليد', 700.00, 50.00, 20.00, 730.00, '2025-12-05', 'paid');

-- إدراج بيانات التقارير السنوية
INSERT INTO `yearly_reports` (`year`, `revenue`, `expenses`, `profit`, `budget_data`) VALUES
(2025, 34500.00, 18200.00, 16300.00, '{"salaries": 7800, "operational": 4750, "marketing": 2850, "assets": 2300, "other": 1500}');

-- عرض جميع الجداول
SHOW TABLES;

-- عرض عينة من البيانات
SELECT 'العملاء' AS 'الجدول', COUNT(*) AS 'عدد السجلات' FROM clients
UNION
SELECT 'الالتزامات', COUNT(*) FROM commitments
UNION
SELECT 'الأصول', COUNT(*) FROM assets
UNION
SELECT 'الرواتب', COUNT(*) FROM salaries
UNION
SELECT 'التقارير السنوية', COUNT(*) FROM yearly_reports;