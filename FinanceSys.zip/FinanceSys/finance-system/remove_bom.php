// remove_bom.php
// ??? ????? ???? BOM ?? ???? ????? PHP
<?php
$files = [
    "app/Config/Routes.php",
    "app/Config/Paths.php",
    "app/Config/Constants.php",
    "app/Controllers/Main.php",
    "app/Controllers/BaseController.php",
    "spark",
    "public/index.php"
];

foreach ($files as $file) {
    if (file_exists($file)) {
        $content = file_get_contents($file);
        // ????? BOM ??? ??? ???????
        if (substr($content, 0, 3) == "\xEF\xBB\xBF") {
            $content = substr($content, 3);
            file_put_contents($file, $content);
            echo "?? ????? BOM ??: $file\n";
        }
    }
}
echo "?????? ????? BOM\n";
