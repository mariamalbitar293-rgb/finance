<?php
/**
 * Bootstrap File - Fixed for Arabic Paths
 */

// Fix for paths with spaces and Arabic characters
function fixPathEncoding($path) {
    if (DIRECTORY_SEPARATOR === '\\') {
        // Windows: Use Windows-1252 encoding for paths
        return iconv('UTF-8', 'Windows-1252', $path);
    }
    return $path;
}

// Define critical constants
define('ROOTPATH', dirname(__DIR__) . DIRECTORY_SEPARATOR);
define('COMPOSER_PATH', ROOTPATH . 'vendor' . DIRECTORY_SEPARATOR . 'autoload.php');

// Fix system path
$systemPath = fixPathEncoding(ROOTPATH . 'vendor' . DIRECTORY_SEPARATOR . 'codeigniter4' . DIRECTORY_SEPARATOR . 'framework' . DIRECTORY_SEPARATOR . 'system');
define('SYSTEMPATH', $systemPath);

// Verify files exist
if (!file_exists(COMPOSER_PATH)) {
    die("ERROR: Composer autoload not found at: " . COMPOSER_PATH);
}

if (!file_exists(SYSTEMPATH . DIRECTORY_SEPARATOR . 'Boot.php')) {
    die("ERROR: System Boot.php not found at: " . SYSTEMPATH);
}

// Load Composer
require_once COMPOSER_PATH;

// Load CodeIgniter Boot
require_once SYSTEMPATH . DIRECTORY_SEPARATOR . 'Boot.php';

use CodeIgniter\Boot;
use Config\Paths;

// Custom Paths class with fixed encoding
class ArabicSafePaths extends Paths
{
    public $systemDirectory;
    public $appDirectory;
    public $writableDirectory = WRITEPATH;
    public $testsDirectory = TESTSPATH;
    public $viewDirectory = VIEWPATH;
    
    public function __construct()
    {
        $this->systemDirectory = SYSTEMPATH;
        $this->appDirectory = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'app';
    }
}

return Boot::bootWeb(new ArabicSafePaths());
