let salariesData = [
    {
        id: 1,
        employeeName: "أحمد محمد",
        position: "مدير مالي",
        baseSalary: 1200,
        bonuses: 150,
        deductions: 50,
        netSalary: 1300,
        paymentDate: "2025-12-25",
        status: "paid",
        notes: "راتب شهر ديسمبر"
    },
    {
        id: 2,
        employeeName: "سارة خالد",
        position: "محاسبة",
        baseSalary: 1500,
        bonuses: 200,
        deductions: 75,
        netSalary: 1625,
        paymentDate: "2025-12-25",
        status: "paid",
        notes: "راتب شهر ديسمبر + حوافز"
    },
    {
        id: 3,
        employeeName: "محمد علي",
        position: "مندوب مبيعات",
        baseSalary: 900,
        bonuses: 100,
        deductions: 30,
        netSalary: 970,
        paymentDate: "2025-12-25",
        status: "paid",
        notes: "راتب شهر ديسمبر"
    },
    {
        id: 4,
        employeeName: "فاطمة حسين",
        position: "سكرتيرة",
        baseSalary: 800,
        bonuses: 80,
        deductions: 25,
        netSalary: 855,
        paymentDate: "2025-12-25",
        status: "pending",
        notes: "راتب شهر ديسمبر"
    },
    {
        id: 5,
        employeeName: "خالد وليد",
        position: "حارس",
        baseSalary: 700,
        bonuses: 50,
        deductions: 20,
        netSalary: 730,
        paymentDate: "2025-12-25",
        status: "pending",
        notes: "راتب شهر ديسمبر"
    }
];

function initSalariesManagement() {
    renderSalariesTable();
    setupSalariesEventListeners();
    updateSalaryStats();
}


function renderSalariesTable(salaries = salariesData) {
    const tableBody = document.getElementById('salariesTableBody');
    if (!tableBody) return;
    
    tableBody.innerHTML = '';
    
    salaries.forEach(salary => {
        const row = document.createElement('tr');
        
        row.innerHTML = `
            <td>
                <strong>${salary.employeeName}</strong><br>
                <small style="color: var(--gray-color);">${salary.position}</small>
            </td>
            <td>${salary.baseSalary.toLocaleString()} دينار</td>
            <td>${salary.bonuses.toLocaleString()} دينار</td>
            <td>${salary.deductions.toLocaleString()} دينار</td>
            <td>${salary.netSalary.toLocaleString()} دينار</td>
            <td>${salary.paymentDate}</td>
            <td>
                <span class="status ${salary.status}">
                    ${salary.status === 'paid' ? 'مسدد' : 'قيد الانتظار'}
                </span>
            </td>
            <td>${salary.notes}</td>
            <td>
                <button class="btn btn-secondary tooltip" style="padding: 6px 12px; font-size: 0.9rem;" onclick="editSalary(${salary.id})" data-tooltip="تعديل">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-success tooltip" style="padding: 6px 12px; font-size: 0.9rem;" onclick="markSalaryAsPaid(${salary.id})" data-tooltip="تسديد">
                    <i class="fas fa-check"></i>
                </button>
                <button class="btn btn-danger tooltip" style="padding: 6px 12px; font-size: 0.9rem;" onclick="deleteSalary(${salary.id})" data-tooltip="حذف">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        
        tableBody.appendChild(row);
    });
}

function updateSalaryStats() {
    const totalBaseSalary = salariesData.reduce((sum, salary) => sum + salary.baseSalary, 0);
    const totalBonuses = salariesData.reduce((sum, salary) => sum + salary.bonuses, 0);
    const totalDeductions = salariesData.reduce((sum, salary) => sum + salary.deductions, 0);
    const totalNetSalary = salariesData.reduce((sum, salary) => sum + salary.netSalary, 0);
    const paidCount = salariesData.filter(s => s.status === 'paid').length;
    const pendingCount = salariesData.filter(s => s.status === 'pending').length;
    
    const totalEmployeesElement = document.getElementById('totalEmployees');
    const totalSalariesElement = document.getElementById('totalSalaries');
    const totalBonusElement = document.getElementById('totalBonus');
    const pendingSalariesElement = document.getElementById('pendingSalaries');
    const salaryBadgeElement = document.getElementById('salaryBadge');
    
    if (totalEmployeesElement) {
        totalEmployeesElement.innerHTML = salariesData.length;
    }
    
    if (totalSalariesElement) {
        totalSalariesElement.innerHTML = `${totalNetSalary.toLocaleString()} <span style="font-size: 1rem;">دينار</span>`;
    }
    
    if (totalBonusElement) {
        totalBonusElement.innerHTML = `${totalBonuses.toLocaleString()} <span style="font-size: 1rem;">دينار</span>`;
    }
    
    if (pendingSalariesElement) {
        pendingSalariesElement.innerHTML = pendingCount;
    }
    
    if (salaryBadgeElement) {
        salaryBadgeElement.innerHTML = pendingCount;
    }
}

function setupSalariesEventListeners() {
    
    const salarySearch = document.getElementById('salarySearch');
    if (salarySearch) {
        salarySearch.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const filteredSalaries = salariesData.filter(salary => 
                salary.employeeName.toLowerCase().includes(searchTerm) || 
                salary.position.toLowerCase().includes(searchTerm) ||
                salary.notes.toLowerCase().includes(searchTerm)
            );
            renderSalariesTable(filteredSalaries);
        });
    }
    
    const salaryStatusFilter = document.getElementById('salaryStatusFilter');
    if (salaryStatusFilter) {
        salaryStatusFilter.addEventListener('change', function() {
            const status = this.value;
            let filteredSalaries = [];
            
            if (status === 'all') {
                filteredSalaries = salariesData;
            } else {
                filteredSalaries = salariesData.filter(s => s.status === status);
            }
            
            renderSalariesTable(filteredSalaries);
        });
    }
    
    const addSalaryBtn = document.getElementById('addSalaryBtn');
    if (addSalaryBtn) {
        addSalaryBtn.addEventListener('click', openAddSalaryModal);
    }
    
    
    const saveSalaryBtn = document.getElementById('saveSalaryBtn');
    if (saveSalaryBtn) {
        saveSalaryBtn.addEventListener('click', saveNewSalary);
    }
    
    
    const closeSalaryModalBtn = document.getElementById('closeSalaryModalBtn');
    const cancelAddSalaryBtn = document.getElementById('cancelAddSalaryBtn');
    
    if (closeSalaryModalBtn) {
        closeSalaryModalBtn.addEventListener('click', closeAddSalaryModal);
    }
    
    if (cancelAddSalaryBtn) {
        cancelAddSalaryBtn.addEventListener('click', closeAddSalaryModal);
    }
    
    
    const exportSalaryBtn = document.getElementById('exportSalaryBtn');
    if (exportSalaryBtn) {
        exportSalaryBtn.addEventListener('click', exportSalariesData);
    }
    
    
    const baseSalaryInput = document.getElementById('baseSalary');
    const bonusesInput = document.getElementById('bonuses');
    const deductionsInput = document.getElementById('deductions');
    
    if (baseSalaryInput && bonusesInput && deductionsInput) {
        [baseSalaryInput, bonusesInput, deductionsInput].forEach(input => {
            input.addEventListener('input', calculateNetSalary);
        });
    }
}


function openAddSalaryModal() {
    openModal('addSalaryModal');
    const employeeNameInput = document.getElementById('employeeName');
    if (employeeNameInput) employeeNameInput.focus();
    
    
    const paymentDateInput = document.getElementById('paymentDate');
    if (paymentDateInput) paymentDateInput.valueAsDate = new Date();
    
    showNotification('فتح نموذج إضافة راتب جديد');
}


function closeAddSalaryModal() {
    closeModal('addSalaryModal');
    const form = document.getElementById('addSalaryForm');
    if (form) form.reset();
    
    const paymentDateInput = document.getElementById('paymentDate');
    if (paymentDateInput) paymentDateInput.valueAsDate = new Date();
    
    
    const saveSalaryBtn = document.getElementById('saveSalaryBtn');
    if (saveSalaryBtn) {
        saveSalaryBtn.innerHTML = '<i class="fas fa-save"></i> حفظ الراتب';
        saveSalaryBtn.onclick = saveNewSalary;
    }
}

function calculateNetSalary() {
    const baseSalary = parseFloat(document.getElementById('baseSalary')?.value) || 0;
    const bonuses = parseFloat(document.getElementById('bonuses')?.value) || 0;
    const deductions = parseFloat(document.getElementById('deductions')?.value) || 0;
    const netSalary = baseSalary + bonuses - deductions;
    
    const netSalaryInput = document.getElementById('netSalary');
    if (netSalaryInput) {
        netSalaryInput.value = netSalary;
    }
    
    return netSalary;
}

function saveNewSalary() {
    const employeeName = document.getElementById('employeeName')?.value.trim();
    const position = document.getElementById('position')?.value.trim();
    const baseSalary = parseFloat(document.getElementById('baseSalary')?.value);
    const bonuses = parseFloat(document.getElementById('bonuses')?.value) || 0;
    const deductions = parseFloat(document.getElementById('deductions')?.value) || 0;
    const netSalary = parseFloat(document.getElementById('netSalary')?.value);
    const paymentDate = document.getElementById('paymentDate')?.value;
    const status = document.getElementById('salaryStatus')?.value;
    const notes = document.getElementById('salaryNotes')?.value.trim();
    
    
    if (!employeeName || !position || !baseSalary || !paymentDate) {
        showNotification('الرجاء ملء جميع الحقول المطلوبة بشكل صحيح', 'error');
        return;
    }
    
    if (baseSalary < 0 || bonuses < 0 || deductions < 0) {
        showNotification('القيم يجب أن تكون أرقاماً موجبة', 'error');
        return;
    }
    
    
    const salaryIdInput = document.getElementById('salaryId');
    const salaryId = salaryIdInput ? parseInt(salaryIdInput.value) : null;
    
    if (salaryId) {
        
        updateSalary(salaryId, { 
            employeeName, position, baseSalary, bonuses, deductions, 
            netSalary, paymentDate, status, notes 
        });
    } else {
        
        const newSalary = {
            id: salariesData.length > 0 ? Math.max(...salariesData.map(s => s.id)) + 1 : 1,
            employeeName: employeeName,
            position: position,
            baseSalary: baseSalary,
            bonuses: bonuses,
            deductions: deductions,
            netSalary: netSalary,
            paymentDate: paymentDate,
            status: status,
            notes: notes || 'لا توجد ملاحظات'
        };
        
        salariesData.unshift(newSalary);
        renderSalariesTable();
        updateSalaryStats();
        showNotification(`تم إضافة راتب ${employeeName} بنجاح`);
    }
    
    closeAddSalaryModal();
}

function editSalary(id) {
    const salary = salariesData.find(s => s.id === id);
    if (!salary) return;
    
    
    document.getElementById('salaryId').value = salary.id;
    document.getElementById('employeeName').value = salary.employeeName;
    document.getElementById('position').value = salary.position;
    document.getElementById('baseSalary').value = salary.baseSalary;
    document.getElementById('bonuses').value = salary.bonuses;
    document.getElementById('deductions').value = salary.deductions;
    document.getElementById('netSalary').value = salary.netSalary;
    document.getElementById('paymentDate').value = salary.paymentDate;
    document.getElementById('salaryStatus').value = salary.status;
    document.getElementById('salaryNotes').value = salary.notes || '';
    
    const saveSalaryBtn = document.getElementById('saveSalaryBtn');
    if (saveSalaryBtn) {
        saveSalaryBtn.innerHTML = '<i class="fas fa-save"></i> تحديث البيانات';
        saveSalaryBtn.onclick = saveNewSalary;
    }
    
    
    openModal('addSalaryModal');
    showNotification('فتح نموذج تعديل بيانات الراتب');
}

function updateSalary(id, data) {
    const salaryIndex = salariesData.findIndex(s => s.id === id);
    if (salaryIndex !== -1) {
        salariesData[salaryIndex] = {
            id: id,
            employeeName: data.employeeName,
            position: data.position,
            baseSalary: data.baseSalary,
            bonuses: data.bonuses,
            deductions: data.deductions,
            netSalary: data.netSalary,
            paymentDate: data.paymentDate,
            status: data.status,
            notes: data.notes || 'لا توجد ملاحظات'
        };
        
        renderSalariesTable();
        updateSalaryStats();
        showNotification(`تم تحديث بيانات راتب ${data.employeeName} بنجاح`);
    }
}

function markSalaryAsPaid(id) {
    const salary = salariesData.find(s => s.id === id);
    if (salary && salary.status === 'pending') {
        salary.status = 'paid';
        renderSalariesTable();
        updateSalaryStats();
        showNotification(`تم تسديد راتب ${salary.employeeName} بنجاح`);
    } else if (salary && salary.status === 'paid') {
        showNotification('الراتب مسدد بالفعل', 'warning');
    }
}


function deleteSalary(id) {
    if (confirm('هل أنت متأكد من حذف هذا الراتب؟')) {
        salariesData = salariesData.filter(s => s.id !== id);
        renderSalariesTable();
        updateSalaryStats();
        showNotification('تم حذف الراتب بنجاح');
    }
}


function exportSalariesData() {
    const dataStr = JSON.stringify(salariesData, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `salaries-data-${new Date().toISOString().split('T')[0]}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
    
    showNotification('تم تصدير بيانات الرواتب بنجاح');
}


function generatePayrollReport(month, year) {
    const monthNames = [
        'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
        'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
    ];
    
    const report = {
        month: monthNames[month - 1],
        year: year,
        totalEmployees: salariesData.length,
        totalBaseSalary: salariesData.reduce((sum, s) => sum + s.baseSalary, 0),
        totalBonuses: salariesData.reduce((sum, s) => sum + s.bonuses, 0),
        totalDeductions: salariesData.reduce((sum, s) => sum + s.deductions, 0),
        totalNetSalary: salariesData.reduce((sum, s) => sum + s.netSalary, 0),
        employees: salariesData.map(s => ({
            name: s.employeeName,
            position: s.position,
            baseSalary: s.baseSalary,
            bonuses: s.bonuses,
            deductions: s.deductions,
            netSalary: s.netSalary,
            status: s.status
        }))
    };
    
    return report;
}


function processMonthlySalaries() {
    
    let processedCount = 0;
    
    salariesData.forEach(salary => {
        if (salary.status === 'pending') {
            salary.status = 'paid';
            processedCount++;
        }
    });
    
    renderSalariesTable();
    updateSalaryStats();
    
    if (processedCount > 0) {
        showNotification(`تم تسديد ${processedCount} رواتب بنجاح`);
    } else {
        showNotification('لا توجد رواتب قيد الانتظار', 'info');
    }
}