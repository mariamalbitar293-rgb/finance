let budgetChart, revenueExpenseChart, salaryChart;

function initCharts() {
    
    const budgetCtx = document.getElementById('budgetChart');
    if (budgetCtx) {
        budgetChart = new Chart(budgetCtx.getContext('2d'), {
            type: 'doughnut',
            data: {
                labels: ['الرواتب', 'المصروفات التشغيلية', 'التسويق والإعلان', 'الموجودات والمعدات', 'مصاريف أخرى'],
                datasets: [{
                    data: [7800, 4750, 2850, 2300, 1500],
                    backgroundColor: [
                        'var(--primary-color)',
                        'var(--success-color)',
                        'var(--danger-color)',
                        'var(--warning-color)',
                        'var(--accent-color)'
                    ],
                    borderWidth: 2,
                    borderColor: '#fff'
                }]
            },
            options: getChartOptions('توزيع الميزانية السنوية')
        });
    }
    
    const revenueCtx = document.getElementById('revenueExpenseChart');
    if (revenueCtx) {
        revenueExpenseChart = new Chart(revenueCtx.getContext('2d'), {
            type: 'line',
            data: {
                labels: ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'],
                datasets: [
                    {
                        label: 'الإيرادات',
                        data: [2500, 2800, 3000, 3200, 2900, 3100, 3400, 3600, 3300, 3500, 3700, 3800],
                        borderColor: 'var(--success-color)',
                        backgroundColor: 'rgba(46, 204, 113, 0.1)',
                        borderWidth: 3,
                        fill: true,
                        tension: 0.3
                    },
                    {
                        label: 'المصروفات',
                        data: [1400, 1500, 1600, 1700, 1550, 1650, 1800, 1900, 1750, 1850, 1950, 2000],
                        borderColor: 'var(--danger-color)',
                        backgroundColor: 'rgba(231, 76, 60, 0.1)',
                        borderWidth: 3,
                        fill: true,
                        tension: 0.3
                    }
                ]
            },
            options: getChartOptions('الإيرادات والمصروفات', true)
        });
    }
    
    const salaryCtx = document.getElementById('salaryChart');
    if (salaryCtx) {
        salaryChart = new Chart(salaryCtx.getContext('2d'), {
            type: 'bar',
            data: {
                labels: ['أحمد محمد', 'سارة خالد', 'محمد علي', 'فاطمة حسين', 'خالد وليد'],
                datasets: [
                    {
                        label: 'الراتب الأساسي',
                        data: [1200, 1500, 900, 800, 700],
                        backgroundColor: 'var(--primary-color)',
                        borderColor: 'var(--secondary-color)',
                        borderWidth: 1
                    },
                    {
                        label: 'الحوافز',
                        data: [150, 200, 100, 80, 50],
                        backgroundColor: 'var(--success-color)',
                        borderColor: '#27ae60',
                        borderWidth: 1
                    },
                    {
                        label: 'صافي الراتب',
                        data: [1300, 1625, 970, 855, 730],
                        backgroundColor: 'var(--warning-color)',
                        borderColor: '#e67e22',
                        borderWidth: 1
                    }
                ]
            },
            options: getChartOptions('توزيع الرواتب', true)
        });
    }
}

function getChartOptions(title, showLegend = false) {
    const options = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            tooltip: {
                rtl: true,
                callbacks: {
                    label: function(context) {
                        let label = context.dataset.label || context.label || '';
                        if (label) {
                            label += ': ';
                        }
                        const value = context.parsed ? context.parsed.y || context.parsed : context.raw;
                        label += value.toLocaleString() + ' دينار';
                        return label;
                    }
                }
            }
        },
        animation: {
            duration: 1500,
            easing: 'easeInOutQuart'
        }
    };
    
    if (showLegend) {
        options.plugins.legend = {
            position: 'top',
            rtl: true,
            labels: {
                font: {
                    family: "'Cairo', sans-serif",
                    size: 12
                }
            }
        };
    }
    
    if (title) {
        options.plugins.title = {
            display: true,
            text: title,
            font: {
                size: 16,
                family: "'Cairo', sans-serif"
            }
        };
    }
    
    return options;
}

function updateYearlyCharts(year) {
    
    const yearlyData = {
        '2025': {
            budget: [7800, 4750, 2850, 2300, 1500],
            revenue: [2500, 2800, 3000, 3200, 2900, 3100, 3400, 3600, 3300, 3500, 3700, 3800],
            expenses: [1400, 1500, 1600, 1700, 1550, 1650, 1800, 1900, 1750, 1850, 1950, 2000]
        },
        '2024': {
            budget: [7500, 4500, 2700, 2200, 1400],
            revenue: [2200, 2400, 2700, 2900, 2600, 2800, 3100, 3300, 3000, 3200, 3400, 3500],
            expenses: [1300, 1400, 1500, 1600, 1450, 1550, 1700, 1800, 1650, 1750, 1850, 1900]
        },
        '2023': {
            budget: [7000, 4200, 2500, 2000, 1300],
            revenue: [2000, 2200, 2400, 2600, 2300, 2500, 2800, 3000, 2700, 2900, 3100, 3200],
            expenses: [1200, 1300, 1400, 1500, 1350, 1450, 1600, 1700, 1550, 1650, 1750, 1800]
        }
    };
    
    const data = yearlyData[year] || yearlyData['2025'];
    
    if (budgetChart) {
        budgetChart.data.datasets[0].data = data.budget;
        budgetChart.update('none');
    }
    
    if (revenueExpenseChart) {
        revenueExpenseChart.data.datasets[0].data = data.revenue;
        revenueExpenseChart.data.datasets[1].data = data.expenses;
        revenueExpenseChart.update('none');
    }
    
    if (budgetChart) budgetChart.update();
    if (revenueExpenseChart) revenueExpenseChart.update();
}

function destroyCharts() {
    if (budgetChart) {
        budgetChart.destroy();
        budgetChart = null;
    }
    if (revenueExpenseChart) {
        revenueExpenseChart.destroy();
        revenueExpenseChart = null;
    }
    if (salaryChart) {
        salaryChart.destroy();
        salaryChart = null;
    }
}

function exportChart(chartId, fileName) {
    const chartElement = document.getElementById(chartId);
    if (!chartElement) return;
    
    const canvas = chartElement.querySelector('canvas');
    if (!canvas) return;
    
    const link = document.createElement('a');
    link.download = fileName + '.png';
    link.href = canvas.toDataURL('image/png');
    link.click();
}