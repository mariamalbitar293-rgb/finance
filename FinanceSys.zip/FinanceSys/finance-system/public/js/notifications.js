class NotificationSystem {
    constructor() {
        this.notifications = [];
        this.init();
    }
    
    init() {
        this.loadNotifications();
        this.renderNotificationBadge();
    }
    
    loadNotifications() {
        
        this.notifications = [
            { id: 1, title: 'دفعة جديدة', message: 'عميل محمد سدد دفعة بقيمة 50 دينار', type: 'success', time: 'منذ 5 دقائق', read: false },
            { id: 2, title: 'تذكير دفع', message: 'دفعة إيجار المحل مستحقة غداً', type: 'warning', time: 'منذ ساعة', read: false },
            { id: 3, title: 'تقرير شهري', message: 'تقرير الأداء الشهري جاهز', type: 'info', time: 'منذ يوم', read: true }
        ];
    }
    
    renderNotificationBadge() {
        const unreadCount = this.notifications.filter(n => !n.read).length;
        const badgeElement = document.querySelector('.notification-badge');
        
        if (badgeElement) {
            badgeElement.textContent = unreadCount;
            badgeElement.style.display = unreadCount > 0 ? 'flex' : 'none';
        }
    }
    
    addNotification(title, message, type = 'info') {
        const newNotification = {
            id: Date.now(),
            title: title,
            message: message,
            type: type,
            time: 'الآن',
            read: false
        };
        
        this.notifications.unshift(newNotification);
        this.renderNotificationBadge();
        this.showToastNotification(newNotification);
        
        
        this.saveNotifications();
    }
    
    
    showToastNotification(notification) {
        
        const toast = document.createElement('div');
        toast.className = `notification-toast notification-${notification.type}`;
        toast.innerHTML = `
            <div class="toast-header">
                <strong>${notification.title}</strong>
                <small>${notification.time}</small>
                <button type="button" class="toast-close">&times;</button>
            </div>
            <div class="toast-body">
                ${notification.message}
            </div>
        `;
        
        
        toast.style.animation = 'slideInRight 0.3s ease-out';
        
        const container = document.getElementById('notification-container') || this.createNotificationContainer();
        container.appendChild(toast);
        
        setTimeout(() => {
            this.removeToast(toast);
        }, 5000);
        
        const closeBtn = toast.querySelector('.toast-close');
        closeBtn.addEventListener('click', () => this.removeToast(toast));
        
        toast.addEventListener('click', () => {
            this.markAsRead(notification.id);
            this.removeToast(toast);
        });
    }
    
    createNotificationContainer() {
        const container = document.createElement('div');
        container.id = 'notification-container';
        container.style.cssText = `
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 9999;
            max-width: 350px;
        `;
        document.body.appendChild(container);
        return container;
    }
    
    removeToast(toast) {
        toast.style.animation = 'fadeOut 0.3s ease-out';
        setTimeout(() => {
            if (toast.parentNode) {
                toast.parentNode.removeChild(toast);
            }
        }, 300);
    }
    
    markAsRead(id) {
        const notification = this.notifications.find(n => n.id === id);
        if (notification) {
            notification.read = true;
            this.renderNotificationBadge();
            this.saveNotifications();
        }
    }
    
    markAllAsRead() {
        this.notifications.forEach(n => n.read = true);
        this.renderNotificationBadge();
        this.saveNotifications();
    }
    
    deleteNotification(id) {
        this.notifications = this.notifications.filter(n => n.id !== id);
        this.renderNotificationBadge();
        this.saveNotifications();
    }
    
    deleteAllNotifications() {
        if (confirm('هل تريد حذف جميع الإشعارات؟')) {
            this.notifications = [];
            this.renderNotificationBadge();
            this.saveNotifications();
        }
    }
    
    saveNotifications() {
        try {
            localStorage.setItem('finance_system_notifications', JSON.stringify(this.notifications));
        } catch (error) {
            console.error('Error saving notifications:', error);
        }
    }
    
    loadFromStorage() {
        try {
            const saved = localStorage.getItem('finance_system_notifications');
            if (saved) {
                this.notifications = JSON.parse(saved);
                this.renderNotificationBadge();
            }
        } catch (error) {
            console.error('Error loading notifications:', error);
        }
    }

    showNotificationsList() {
        
        let modal = document.getElementById('notifications-modal');
        
        if (!modal) {
            modal = document.createElement('div');
            modal.id = 'notifications-modal';
            modal.className = 'modal-overlay';
            modal.innerHTML = this.getNotificationsModalHTML();
            document.body.appendChild(modal);
        }
        
        
        this.updateNotificationsList();
        
        
        modal.style.display = 'flex';
        
        
        this.setupNotificationsModalEvents();
    }
    
    
    getNotificationsModalHTML() {
        return `
            <div class="modal" style="max-width: 500px;">
                <div style="padding: 20px; border-bottom: 1px solid #f0f0f0; display: flex; justify-content: space-between; align-items: center;">
                    <h3 style="margin: 0; display: flex; align-items: center; gap: 10px;">
                        <i class="fas fa-bell"></i> الإشعارات
                        <span class="notification-count" style="background: var(--primary-color); color: white; padding: 2px 8px; border-radius: 20px; font-size: 0.8rem;"></span>
                    </h3>
                    <div>
                        <button class="btn btn-sm btn-secondary mark-all-read-btn" style="margin-left: 10px;">
                            <i class="fas fa-check-double"></i> وضع علامة مقروء للجميع
                        </button>
                        <button class="btn btn-sm btn-danger delete-all-btn" style="margin-left: 10px;">
                            <i class="fas fa-trash"></i> حذف الكل
                        </button>
                        <button class="btn btn-sm btn-secondary close-notifications-btn" style="margin-left: 10px;">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>
                <div id="notifications-list" style="max-height: 400px; overflow-y: auto; padding: 20px;">
                    <!-- سيتم تعبئة الإشعارات هنا -->
                </div>
            </div>
        `;
    }
    
    
    updateNotificationsList() {
        const listElement = document.getElementById('notifications-list');
        const countElement = document.querySelector('.notification-count');
        
        if (!listElement || !countElement) return;
        
        const unreadCount = this.notifications.filter(n => !n.read).length;
        countElement.textContent = unreadCount;
        
        if (this.notifications.length === 0) {
            listElement.innerHTML = `
                <div style="text-align: center; padding: 40px; color: var(--gray-color);">
                    <i class="fas fa-bell-slash" style="font-size: 3rem; margin-bottom: 20px;"></i>
                    <p>لا توجد إشعارات</p>
                </div>
            `;
            return;
        }
        
        listElement.innerHTML = this.notifications.map(notification => `
            <div class="notification-item ${notification.read ? 'read' : 'unread'}" data-id="${notification.id}">
                <div style="display: flex; align-items: flex-start; gap: 15px; padding: 15px; border-bottom: 1px solid #f0f0f0;">
                    <div style="flex-shrink: 0;">
                        <div class="notification-icon ${notification.type}">
                            <i class="fas fa-${this.getNotificationIcon(notification.type)}"></i>
                        </div>
                    </div>
                    <div style="flex: 1;">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                            <strong>${notification.title}</strong>
                            <small style="color: var(--gray-color);">${notification.time}</small>
                        </div>
                        <p style="margin: 0; color: #666;">${notification.message}</p>
                        ${!notification.read ? '<div class="unread-dot"></div>' : ''}
                    </div>
                    <button class="btn btn-sm btn-danger delete-notification-btn" data-id="${notification.id}" style="flex-shrink: 0;">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>
        `).join('');
    }
    
    getNotificationIcon(type) {
        const icons = {
            'success': 'check-circle',
            'warning': 'exclamation-triangle',
            'error': 'times-circle',
            'info': 'info-circle'
        };
        return icons[type] || 'bell';
    }
    
    
    setupNotificationsModalEvents() {
        
        const closeBtn = document.querySelector('.close-notifications-btn');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                const modal = document.getElementById('notifications-modal');
                if (modal) modal.style.display = 'none';
            });
        }
        
        
        const markAllBtn = document.querySelector('.mark-all-read-btn');
        if (markAllBtn) {
            markAllBtn.addEventListener('click', () => {
                this.markAllAsRead();
                this.updateNotificationsList();
            });
        }
        
        
        const deleteAllBtn = document.querySelector('.delete-all-btn');
        if (deleteAllBtn) {
            deleteAllBtn.addEventListener('click', () => {
                this.deleteAllNotifications();
                this.updateNotificationsList();
            });
        }
        
        
        document.querySelectorAll('.delete-notification-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const id = parseInt(btn.getAttribute('data-id'));
                this.deleteNotification(id);
                this.updateNotificationsList();
            });
        });
        
        
        document.querySelectorAll('.notification-item').forEach(item => {
            item.addEventListener('click', (e) => {
                if (!e.target.closest('.delete-notification-btn')) {
                    const id = parseInt(item.getAttribute('data-id'));
                    this.markAsRead(id);
                    this.updateNotificationsList();
                }
            });
        });
        
        
        const modal = document.getElementById('notifications-modal');
        if (modal) {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    modal.style.display = 'none';
                }
            });
        }
    }
}


let notificationSystem = null;

function initNotificationSystem() {
    notificationSystem = new NotificationSystem();
    
    
    const notificationIcon = document.querySelector('.notifications');
    if (notificationIcon) {
        notificationIcon.addEventListener('click', () => {
            notificationSystem.showNotificationsList();
        });
    }
    
    
    addNotificationStyles();
}

function addNotificationStyles() {
    if (document.getElementById('notification-styles')) return;
    
    const style = document.createElement('style');
    style.id = 'notification-styles';
    style.textContent = `
        .notification-toast {
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 10px;
            overflow: hidden;
            border-right: 4px solid;
            animation-duration: 0.3s;
        }
        
        .notification-success {
            border-right-color: var(--success-color);
        }
        
        .notification-warning {
            border-right-color: var(--warning-color);
        }
        
        .notification-error {
            border-right-color: var(--danger-color);
        }
        
        .notification-info {
            border-right-color: var(--primary-color);
        }
        
        .toast-header {
            padding: 10px 15px;
            background: #f8f9fa;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .toast-header strong {
            color: var(--dark-color);
        }
        
        .toast-header small {
            color: var(--gray-color);
        }
        
        .toast-close {
            background: none;
            border: none;
            font-size: 1.2rem;
            color: var(--gray-color);
            cursor: pointer;
            padding: 0;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .toast-body {
            padding: 15px;
            color: #666;
        }
        
        .notification-item {
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        
        .notification-item:hover {
            background-color: #f8f9fa;
        }
        
        .notification-item.unread {
            background-color: rgba(67, 97, 238, 0.05);
        }
        
        .notification-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.2rem;
        }
        
        .notification-icon.success {
            background-color: var(--success-color);
        }
        
        .notification-icon.warning {
            background-color: var(--warning-color);
        }
        
        .notification-icon.error {
            background-color: var(--danger-color);
        }
        
        .notification-icon.info {
            background-color: var(--primary-color);
        }
        
        .unread-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background-color: var(--primary-color);
            display: inline-block;
            margin-top: 5px;
        }
        
        @keyframes fadeOut {
            from { opacity: 1; }
            to { opacity: 0; transform: translateX(-100%); }
        }
    `;
    
    document.head.appendChild(style);
}

function sendTestNotification(type = 'info') {
    if (!notificationSystem) return;
    
    const messages = {
        'success': { title: 'عملية ناجحة', message: 'تم حفظ البيانات بنجاح' },
        'warning': { title: 'تنبيه', message: 'هناك دفعات مستحقة قريباً' },
        'error': { title: 'خطأ', message: 'حدث خطأ في عملية الحفظ' },
        'info': { title: 'معلومة', message: 'هناك تحديث جديد للنظام' }
    };
    
    const message = messages[type] || messages.info;
    notificationSystem.addNotification(message.title, message.message, type);
}


function setupAutomaticNotifications() {
    
    setInterval(() => {
        checkDuePayments();
    }, 3600000);
    
    
    checkMonthlyReports();
}


function checkDuePayments() {
    
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    
    if (Math.random() > 0.7 && notificationSystem) {
        notificationSystem.addNotification(
            'تذكير دفع',
            'يوجد 3 دفعات مستحقة خلال الأيام القليلة القادمة',
            'warning'
        );
    }
}

function checkMonthlyReports() {
    const today = new Date();
    const lastDayOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0);
    
    
    if (today.getDate() >= 25 && notificationSystem) {
        notificationSystem.addNotification(
            'تقرير نهاية الشهر',
            'تقرير الأداء الشهري جاهز للإعداد',
            'info'
        );
    }
}

function sendCustomNotification(title, message, type = 'info') {
    if (!notificationSystem) return;
    notificationSystem.addNotification(title, message, type);
}