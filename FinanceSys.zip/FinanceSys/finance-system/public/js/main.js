function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
}

let clientsData = [
    { id: 1, name: "محمد", principal: 200, paid: 100, phone: "0599123456", date: "2025-12-10", status: "partial", notes: "هون تكون عملية حسابه الكل المجموع" },
    { id: 2, name: "أحمد", principal: 500, paid: 300, phone: "0599765432", date: "2025-12-12", status: "partial", notes: "متبقي 200 دينار" }
];

document.addEventListener('DOMContentLoaded', function() {
    
    const dateElement = document.getElementById('current-date');
    if (dateElement) {
        const now = new Date();
        dateElement.textContent = now.toLocaleDateString('ar-EG');
    }
    
    setupEventListeners();
    
    if (document.getElementById('clientsTableBody')) {
        renderClientsTable();
    }
});

function setupEventListeners() {
    
    const toggleBtn = document.getElementById('toggleSidebarBtn');
    if (toggleBtn) {
        toggleBtn.addEventListener('click', toggleSidebar);
    }
    
    const floatingBtn = document.getElementById('floatingAddBtn');
    if (floatingBtn) {
        floatingBtn.addEventListener('click', openAddClientModal);
    }
    
    const addBtn = document.getElementById('addClientBtn');
    if (addBtn) {
        addBtn.addEventListener('click', openAddClientModal);
    }
    
    const searchInput = document.getElementById('clientSearch');
    if (searchInput) {
        searchInput.addEventListener('input', searchClients);
    }
    
    setupModalButtons();
    
    document.querySelectorAll('.modal-overlay').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                closeModal(this.id);
            }
        });
    });
    
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            document.querySelectorAll('.modal-overlay').forEach(modal => {
                closeModal(modal.id);
            });
        }
    });
}

function setupModalButtons() {
    const saveBtn = document.getElementById('saveClientBtn');
    const saveAnotherBtn = document.getElementById('saveAndAddAnotherBtn');
    const cancelBtn = document.getElementById('cancelAddClientBtn');
    
    if (saveBtn) {
        saveBtn.addEventListener('click', function() {
            saveNewClient(false);
        });
    }
    
    if (saveAnotherBtn) {
        saveAnotherBtn.addEventListener('click', function() {
            saveNewClient(true);
        });
    }
    
    if (cancelBtn) {
        cancelBtn.addEventListener('click', function() {
            closeModal('addClientModal');
        });
    }
    
    
    const principalInput = document.getElementById('principalAmount');
    const paidInput = document.getElementById('paidAmount');
    
    if (principalInput) {
        principalInput.addEventListener('input', updatePaymentProgress);
    }
    
    if (paidInput) {
        paidInput.addEventListener('input', updatePaymentProgress);
    }
}

function toggleSidebar() {
    document.body.classList.toggle('sidebar-collapsed');
}

function renderClientsTable(clients = clientsData) {
    const tableBody = document.getElementById('clientsTableBody');
    if (!tableBody) return;
    
    tableBody.innerHTML = '';
    
    clients.forEach(client => {
        const remaining = client.principal - client.paid;
        
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${client.name}</td>
            <td>${client.principal.toLocaleString()} دينار</td>
            <td>${client.paid.toLocaleString()} دينار</td>
            <td>${remaining.toLocaleString()} دينار</td>
            <td>${client.notes || 'لا توجد'}</td>
            <td>${client.date}</td>
            <td>
                <button class="btn-action btn-edit" onclick="editClient(${client.id})">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn-action btn-delete" onclick="deleteClient(${client.id})">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        tableBody.appendChild(row);
    });
}

function searchClients() {
    const searchTerm = document.getElementById('clientSearch').value.toLowerCase();
    const filtered = clientsData.filter(client => 
        client.name.toLowerCase().includes(searchTerm) ||
        client.phone.includes(searchTerm) ||
        client.notes.toLowerCase().includes(searchTerm)
    );
    renderClientsTable(filtered);
}


function openAddClientModal() {
    
    const form = document.getElementById('addClientForm');
    if (form) form.reset();
    
    const dateInput = document.getElementById('clientDate');
    if (dateInput) {
        dateInput.valueAsDate = new Date();
    }
    
    const clientId = document.getElementById('clientId');
    if (clientId) clientId.value = '';
    
    const saveAnotherBtn = document.getElementById('saveAndAddAnotherBtn');
    if (saveAnotherBtn) {
        saveAnotherBtn.style.display = 'inline-flex';
    }
    
    updatePaymentProgress();
    
    openModal('addClientModal');
    
    const nameInput = document.getElementById('clientName');
    if (nameInput) nameInput.focus();
}

function updatePaymentProgress() {
    const principal = parseFloat(document.getElementById('principalAmount')?.value) || 0;
    const paid = parseFloat(document.getElementById('paidAmount')?.value) || 0;
    const progressBar = document.getElementById('paymentProgress');
    const percentageText = document.getElementById('paymentPercentage');
    
    if (!progressBar || !percentageText) return;
    
    if (principal > 0) {
        const percentage = Math.min(100, (paid / principal) * 100);
        progressBar.style.width = percentage + '%';
        percentageText.textContent = percentage.toFixed(1) + '%';
    } else {
        progressBar.style.width = '0%';
        percentageText.textContent = '0%';
    }
}

function saveNewClient(addAnother = false) {
    
    const name = document.getElementById('clientName')?.value.trim();
    const phone = document.getElementById('clientPhone')?.value.trim();
    const principal = parseFloat(document.getElementById('principalAmount')?.value);
    const paid = parseFloat(document.getElementById('paidAmount')?.value) || 0;
    const date = document.getElementById('clientDate')?.value;
    const notes = document.getElementById('clientNotes')?.value.trim() || '';
    

    if (!name || isNaN(principal)) {
        alert('الرجاء إدخال اسم العميل والمبلغ الأساسي');
        return;
    }
    
    if (paid > principal) {
        alert('المبلغ المدفوع لا يمكن أن يكون أكبر من المبلغ الأساسي');
        return;
    }

    const clientId = document.getElementById('clientId')?.value;
    
    if (clientId) {
        
        updateClient(parseInt(clientId), { name, phone, principal, paid, date, notes });
        closeModal('addClientModal');
    } else {
        
        const newClient = {
            id: clientsData.length + 1,
            name,
            phone: phone || '',
            principal,
            paid,
            date: date || new Date().toISOString().split('T')[0],
            status: paid === principal ? 'paid' : paid > 0 ? 'partial' : 'pending',
            notes
        };
        
        clientsData.unshift(newClient);
        renderClientsTable();
        
        if (addAnother) {
            document.getElementById('addClientForm').reset();
            document.getElementById('clientDate').valueAsDate = new Date();
            document.getElementById('clientName').focus();
            updatePaymentProgress();
        } else {
            closeModal('addClientModal');
        }
    }
}

function editClient(id) {
    const client = clientsData.find(c => c.id === id);
    if (!client) return;
    
    document.getElementById('clientId').value = client.id;
    document.getElementById('clientName').value = client.name;
    document.getElementById('clientPhone').value = client.phone || '';
    document.getElementById('principalAmount').value = client.principal;
    document.getElementById('paidAmount').value = client.paid;
    document.getElementById('clientDate').value = client.date;
    document.getElementById('clientNotes').value = client.notes || '';
    
    const saveAnotherBtn = document.getElementById('saveAndAddAnotherBtn');
    if (saveAnotherBtn) {
        saveAnotherBtn.style.display = 'none';
    }
    
    updatePaymentProgress();
    
    openModal('addClientModal');
}

function updateClient(id, data) {
    const index = clientsData.findIndex(c => c.id === id);
    if (index !== -1) {
        clientsData[index] = {
            ...clientsData[index],
            ...data,
            status: data.paid === data.principal ? 'paid' : data.paid > 0 ? 'partial' : 'pending'
        };
        renderClientsTable();
    }
}

function deleteClient(id) {
    if (confirm('هل أنت متأكد من حذف هذا العميل؟')) {
        clientsData = clientsData.filter(c => c.id !== id);
        renderClientsTable();
    }
}

function formatCurrency(amount) {
    return `${parseFloat(amount).toLocaleString('ar-EG')} دينار`;
}