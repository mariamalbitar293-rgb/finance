<?php
// تحميل CodeIgniter للاتصال بقاعدة البيانات
require __DIR__ . '/../app/Config/Paths.php';
require __DIR__ . '/../app/Config/Database.php';

$db = \Config\Database::connect();

if ($db->connID) {
    echo "<!DOCTYPE html>
<html lang='ar' dir='rtl'>
<head>
    <meta charset='UTF-8'>
    <title>نجح الاتصال!</title>
    <style>
        body { font-family: 'Cairo', Tahoma, Arial; text-align: center; margin-top: 100px; background: #f0f8ff; }
        h2 { color: green; font-size: 3rem; }
        p, ul, h3 { font-size: 1.5rem; }
        ul { list-style: none; }
        li { margin: 15px; font-weight: bold; }
    </style>
</head>
<body>
    <h2>🎉 الاتصال بقاعدة البيانات ناجح تمامًا!</h2>
    <p><strong>قاعدة البيانات:</strong> " . $db->getDatabase() . "</p>
    <h3>الجداول الموجودة:</h3>
    <ul>";
    foreach ($db->listTables() as $table) {
        echo "<li>$table</li>";
    }
    echo "</ul>
    <h3>عدد العملاء في جدول clients: <strong>" . $db->table('clients')->countAll() . "</strong></h3>
    <p style='color: #2980b9; font-size: 2rem; margin-top: 60px;'>الآن النظام جاهز لربطه بالقاعدة بشكل كامل! 🚀</p>
</body>
</html>";
} else {
    echo "<h2 style='color:red; font-size: 3rem;'>❌ فشل الاتصال بقاعدة البيانات</h2>";
    echo "<p style='font-size: 1.5rem;'>تحققي من إعدادات app/Config/Database.php (اسم المستخدم، كلمة السر، اسم القاعدة)</p>";
}