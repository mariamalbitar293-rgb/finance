<?php

$clientData = $clientData ?? [];
?>

<div class="modal-overlay" id="addClientModal">
    <div class="modal">
        <div style="padding: 25px; border-bottom: 1px solid #f0f0f0; display: flex; justify-content: space-between; align-items: center;">
            <h2 style="color: var(--dark-color); margin: 0; display: flex; align-items: center; gap: 10px;">
                <i class="fas fa-user-plus"></i> <?= isset($isEdit) && $isEdit ? 'تعديل بيانات العميل' : 'إضافة عميل جديد' ?>
            </h2>
            <button style="background: none; border: none; font-size: 1.5rem; color: var(--gray-color); cursor: pointer;" id="closeModalBtn">&times;</button>
        </div>
        
        <div style="padding: 25px; max-height: 70vh; overflow-y: auto;">
            <form id="addClientForm">
                <input type="hidden" id="clientId" value="<?= $clientData['id'] ?? '' ?>">
                <div style="display: flex; gap: 20px; margin-bottom: 25px; flex-wrap: wrap;">
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">اسم العميل</label>
                        <input type="text" id="clientName" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" placeholder="أدخل اسم العميل الكامل" required value="<?= $clientData['name'] ?? '' ?>">
                    </div>
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">رقم الهاتف</label>
                        <input type="tel" id="clientPhone" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" placeholder="أدخل رقم الهاتف" value="<?= $clientData['phone'] ?? '' ?>">
                    </div>
                </div>
                
                <div style="display: flex; gap: 20px; margin-bottom: 25px; flex-wrap: wrap;">
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">المبلغ الأساسي (دينار)</label>
                        <input type="number" id="principalAmount" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" placeholder="المبلغ الإجمالي المستحق" required min="1" value="<?= $clientData['principal'] ?? '' ?>">
                    </div>
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">المبلغ الذي تم دفعه (دينار)</label>
                        <input type="number" id="paidAmount" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" placeholder="المبلغ الذي تم سداده" required min="0" value="<?= $clientData['paid'] ?? '' ?>">
                    </div>
                </div>
                
                <div style="display: flex; gap: 20px; margin-bottom: 25px; flex-wrap: wrap;">
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">تاريخ المعاملة</label>
                        <input type="date" id="clientDate" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;" required value="<?= $clientData['date'] ?? date('Y-m-d') ?>">
                    </div>
                    <div style="flex: 1; min-width: 250px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">حالة السداد</label>
                        <select id="clientStatus" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;">
                            <option value="paid" <?= ($clientData['status'] ?? '') == 'paid' ? 'selected' : '' ?>>مسدد بالكامل</option>
                            <option value="partial" <?= ($clientData['status'] ?? 'partial') == 'partial' ? 'selected' : '' ?>>مسدد جزئياً</option>
                            <option value="pending" <?= ($clientData['status'] ?? '') == 'pending' ? 'selected' : '' ?>>غير مسدد</option>
                        </select>
                    </div>
                </div>
                
                <div style="margin-bottom: 25px;">
                    <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">ملاحظات إضافية</label>
                    <textarea id="clientNotes" style="width: 100%; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease; min-height: 100px;" placeholder="أضف أي ملاحظات حول العميل أو المعاملة..."><?= $clientData['notes'] ?? '' ?></textarea>
                </div>
                
                <!-- شريط تقدم السداد -->
                <div style="margin-bottom: 25px;">
                    <label style="display: block; margin-bottom: 10px; font-weight: 600; color: var(--dark-color);">نسبة السداد</label>
                    <div style="width: 100%; background-color: #f0f0f0; border-radius: 10px; overflow: hidden;">
                        <div id="paymentProgress" style="height: 10px; border-radius: 10px; transition: width 0.8s ease; background: linear-gradient(90deg, var(--success-color), #27ae60); width: 0%;"></div>
                    </div>
                    <div id="paymentPercentage" style="text-align: center; margin-top: 5px; font-weight: 600; color: var(--primary-color);">0%</div>
                </div>
            </form>
        </div>
        
        <div style="padding: 20px 25px; background-color: #f8f9fa; display: flex; justify-content: flex-end; gap: 15px; border-top: 1px solid #f0f0f0;">
            <button class="btn btn-secondary" id="cancelAddClientBtn">إلغاء</button>
            <button class="btn btn-success" id="saveClientBtn">
                <i class="fas fa-save"></i> <?= isset($isEdit) && $isEdit ? 'تحديث البيانات' : 'حفظ العميل' ?>
            </button>
            <?php if (!isset($isEdit) || !$isEdit): ?>
            <button class="btn btn-primary" id="saveAndAddAnotherBtn">
                <i class="fas fa-plus-circle"></i> حفظ وإضافة آخر
            </button>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>

document.addEventListener('DOMContentLoaded', function() {
    updatePaymentProgress();
    
    document.getElementById('principalAmount')?.addEventListener('input', updatePaymentProgress);
    document.getElementById('paidAmount')?.addEventListener('input', updatePaymentProgress);
});

function updatePaymentProgress() {
    const principalInput = document.getElementById('principalAmount');
    const paidInput = document.getElementById('paidAmount');
    const progressBar = document.getElementById('paymentProgress');
    const percentageText = document.getElementById('paymentPercentage');
    
    if (!principalInput || !paidInput || !progressBar || !percentageText) return;
    
    const principal = parseFloat(principalInput.value) || 0;
    const paid = parseFloat(paidInput.value) || 0;
    
    if (principal > 0) {
        const percentage = Math.min(100, (paid / principal) * 100);
        
        progressBar.style.width = percentage + '%';
        percentageText.textContent = percentage.toFixed(1) + '%';
        
        if (percentage === 100) {
            progressBar.style.background = 'linear-gradient(90deg, var(--success-color), #27ae60)';
            percentageText.style.color = 'var(--success-color)';
        } else if (percentage > 0) {
            progressBar.style.background = 'linear-gradient(90deg, var(--warning-color), #e67e22)';
            percentageText.style.color = 'var(--warning-color)';
        } else {
            progressBar.style.background = 'linear-gradient(90deg, var(--primary-color), var(--secondary-color))';
            percentageText.style.color = 'var(--primary-color)';
        }
    } else {
        progressBar.style.width = '0%';
        percentageText.textContent = '0%';
    }
}
</script>