<?php
namespace App\Models;

use CodeIgniter\Model;

class SalaryModel extends Model
{
    protected $table = 'salaries';
    protected $primaryKey = 'id';
    protected $allowedFields = ['employee_name', 'basic_salary', 'bonuses', 'deductions', 'net_salary', 'payment_date', 'status'];
    protected $useTimestamps = true;
    
    public function getStats($month = null)
    {
        $builder = $this->db->table($this->table);
        
        $stats = [
            'total_salaries' => 0,
            'avg_salary' => 0,
            'total_bonuses' => 0,
            'total_deductions' => 0
        ];
        
        if ($month) {
            $builder->like('payment_date', $month);
        }
        
        $result = $builder->selectSum('basic_salary', 'total_basic')
                         ->selectSum('bonuses', 'total_bonuses')
                         ->selectSum('deductions', 'total_deductions')
                         ->selectAvg('net_salary', 'avg_salary')
                         ->get()
                         ->getRowArray();
        
        if ($result) {
            $stats['total_salaries'] = $result['total_basic'] ?? 0;
            $stats['avg_salary'] = $result['avg_salary'] ?? 0;
            $stats['total_bonuses'] = $result['total_bonuses'] ?? 0;
            $stats['total_deductions'] = $result['total_deductions'] ?? 0;
        }
        
        return $stats;
    }
}