<?php
namespace App\Models;

use CodeIgniter\Model;

class CommitmentModel extends Model
{
    protected $table = 'commitments';
    protected $primaryKey = 'id';
    protected $allowedFields = ['name', 'type', 'amount', 'payment_day', 'start_date', 'end_date', 'recipient', 'status', 'notes', 'paid_amount', 'monthly_payment'];
    protected $useTimestamps = true;
    
    public function getStats()
    {
        $builder = $this->db->table($this->table);
        
        $stats = [
            'total_monthly' => 0,
            'total_debts' => 0,
            'total_deductions' => 0,
            'active_count' => 0
        ];
        
        $monthly = $builder->selectSum('amount', 'total')
                          ->where('type', 'monthly')
                          ->get()
                          ->getRowArray();
        $stats['total_monthly'] = $monthly['total'] ?? 0;
        
        $debts = $builder->selectSum('amount', 'total')
                        ->selectSum('paid_amount', 'paid')
                        ->where('type', 'debt')
                        ->get()
                        ->getRowArray();
        $stats['total_debts'] = ($debts['total'] ?? 0) - ($debts['paid'] ?? 0);
        
        $deductions = $builder->selectSum('amount', 'total')
                             ->where('type', 'deduction')
                             ->get()
                             ->getRowArray();
        $stats['total_deductions'] = $deductions['total'] ?? 0;
        
        $active = $builder->where('status', 'active')
                         ->countAllResults();
        $stats['active_count'] = $active;
        
        return $stats;
    }
}