<?php
namespace App\Models;

use CodeIgniter\Model;

class YearlyReportModel extends Model
{
    protected $table = 'yearly_reports';
    protected $primaryKey = 'id';
    protected $allowedFields = ['year', 'revenue', 'expenses', 'profit', 'budget_data'];
    protected $useTimestamps = true;
    
    public function getYearlyData($year)
    {
        $builder = $this->db->table($this->table);
        
        $data = $builder->where('year', $year)
                       ->get()
                       ->getRowArray();
        
        if (!$data) {
            
            return [
                'year' => $year,
                'revenue' => 34500,
                'expenses' => 18200,
                'profit' => 16300,
                'budget_data' => json_encode([
                    'salaries' => 7800,
                    'operational' => 4750,
                    'marketing' => 2850,
                    'assets' => 2300,
                    'other' => 1500
                ])
            ];
        }
        
        return $data;
    }
}