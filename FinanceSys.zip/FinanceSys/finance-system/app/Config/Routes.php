<?php

namespace Config;

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes = Services::routes();


if (config('Feature')->autoRoutesImproved ?? false) {
    $routes->setAutoRoute(true);
}

/**
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */


$routes->get('/', 'Main::index');


$routes->get('dashboard', 'Dashboard::index');
$routes->get('dashboard/', 'Dashboard::index');


$routes->get('test-db', 'Dashboard::testDb');


$routes->get('dashboard/clients', 'Dashboard::clients');
$routes->get('dashboard/yearlyReports', 'Dashboard::yearlyReports');
$routes->get('dashboard/salaries', 'Dashboard::salaries');
$routes->get('dashboard/commitments', 'Dashboard::commitments');
$routes->get('dashboard/assets', 'Dashboard::assets');


$routes->get('Dashboard/testDb', 'Dashboard::testDb');
$routes->get('dashboard/testDb', 'Dashboard::testDb');

/**
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 */
if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}