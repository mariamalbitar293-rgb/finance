<?php
// ملف المساعدات - helpers.php

if (!function_exists('base_url')) {
    function base_url($path = '')
    {
        // الحصول على المسار الأساسي
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost:8080';
        $base = $protocol . $host;
        
        return $base . '/' . ltrim($path, '/');
    }
}

if (!function_exists('site_url')) {
    function site_url($path = '')
    {
        return base_url($path);
    }
}

if (!function_exists('csrf_hash')) {
    function csrf_hash()
    {
        return md5(session_id() . uniqid(rand(), true));
    }
}

if (!function_exists('csrf_token')) {
    function csrf_token()
    {
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }
}
