<?= $this->extend('layouts/main') ?>

<?= $this->section('title') ?>
لوحة التحكم
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="content-wrapper">
    
    <div class="dashboard-overview">
        <h1 class="main-title">
            <i class="fas fa-tachometer-alt"></i> مرحباً بك في نظام إدارة الحسابات المالية
        </h1>
        <p class="welcome-text">
            اختر من القائمة الجانبية للوصول إلى الأقسام المختلفة
        </p>

        <div class="quick-stats mt-5">
            <div class="row">
                <div class="col-md-3">
                    <div class="stat-box primary">
                        <i class="fas fa-users"></i>
                        <h4>العملاء</h4>
                        <p>إدارة حسابات العملاء</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-box success">
                        <i class="fas fa-chart-line"></i>
                        <h4>التقارير السنوية</h4>
                        <p>تحليل الأداء المالي</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-box warning">
                        <i class="fas fa-money-check-alt"></i>
                        <h4>الرواتب</h4>
                        <p>إدارة الرواتب والمصروفات</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-box danger">
                        <i class="fas fa-hand-holding-usd"></i>
                        <h4>الالتزامات</h4>
                        <p>تتبع الديون والالتزامات</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>