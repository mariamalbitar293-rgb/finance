<?= $this->extend('layouts/main') ?>

<?= $this->section('title') ?>
العملاء
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="content-wrapper">
    <div class="content-body" style="padding: 20px;">
        <h1 style="text-align:center; color:green; font-size:3rem;">! البيانات ظهرت من قاعدة البيانات</h1>
        <h2 style="text-align:center;">عدد العملاء: <strong style="font-size:2rem; color:#2980b9;"><?= count($clients) ?></strong></h2>

        <?php if (empty($clients)): ?>
            <p style="text-align:center; color:red; font-size:1.5rem;">لا توجد بيانات (لكن هذا مستحيل لأننا نعرف أن هناك 8)</p>
        <?php else: ?>
            <table style="width:100%; border-collapse:collapse; margin-top:30px; font-size:1.2rem;">
                <thead style="background:#3498db; color:white;">
                    <tr>
                        <th style="padding:15px; border:1px solid #ddd;">#</th>
                        <th style="padding:15px; border:1px solid #ddd;">الاسم</th>
                        <th style="padding:15px; border:1px solid #ddd;">الهاتف</th>
                        <th style="padding:15px; border:1px solid #ddd;">المبلغ الأساسي</th>
                        <th style="padding:15px; border:1px solid #ddd;">المدفوع</th>
                        <th style="padding:15px; border:1px solid #ddd;">المتبقي</th>
                        <th style="padding:15px; border:1px solid #ddd;">التاريخ</th>
                        <th style="padding:15px; border:1px solid #ddd;">الملاحظات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($clients as $i => $client): ?>
                        <?php $remaining = $client['principal'] - $client['paid']; ?>
                        <tr style="background:<?= $i % 2 == 0 ? '#f8f9fa' : 'white' ?>;">
                            <td style="padding:15px; border:1px solid #ddd; text-align:center;"><?= $i + 1 ?></td>
                            <td style="padding:15px; border:1px solid #ddd;"><strong><?= esc($client['name']) ?></strong></td>
                            <td style="padding:15px; border:1px solid #ddd; text-align:center;"><?= esc($client['phone'] ?? '-') ?></td>
                            <td style="padding:15px; border:1px solid #ddd; text-align:center;"><?= number_format($client['principal'], 2) ?></td>
                            <td style="padding:15px; border:1px solid #ddd; text-align:center;"><?= number_format($client['paid'], 2) ?></td>
                            <td style="padding:15px; border:1px solid #ddd; text-align:center; color:<?= $remaining > 0 ? 'red' : 'green' ?>;"><strong><?= number_format($remaining, 2) ?></strong></td>
                            <td style="padding:15px; border:1px solid #ddd; text-align:center;"><?= esc($client['date']) ?></td>
                            <td style="padding:15px; border:1px solid #ddd;"><?= esc($client['notes'] ?? '-') ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<?= $this->endSection() ?>