﻿<?php

namespace App\Controllers;

use App\Models\ClientModel;
use CodeIgniter\Controller;

class Dashboard extends BaseController
{
    public function index()
    {
        return view('dashboard/index');
    }

    public function clients()
{
    $db = \Config\Database::connect();

    $clients = $db->table('clients')->get()->getResultArray();

    $data = [
        'title' => 'حسابات العملاء',
        'clients' => $clients,
    ];

    return view('dashboard/clients', $data);
}
    public function yearlyReports()
    {
        return view('dashboard/yearly_reports');
    }

    public function salaries()
    {
        return view('dashboard/salaries');
    }

    public function commitments()
    {
        return view('dashboard/commitments');
    }

    public function assets()
    {
        return view('dashboard/assets');
    }

    public function testDb()
    {
        $db = \Config\Database::connect();

        if ($db->connID) {
            echo "<h2 style='color:green; text-align:center; margin-top:100px; direction:rtl; font-family:Tahoma, Arial;'>🎉 الاتصال بقاعدة البيانات ناجح تمامًا!</h2>";
            echo "<p style='text-align:center; font-size:1.5rem;'>قاعدة البيانات: <strong>" . $db->getDatabase() . "</strong></p>";
            echo "<h3 style='text-align:center;'>الجداول الموجودة:</h3>";
            echo "<ul style='text-align:center; list-style:none; font-size:1.2rem;'>";
            foreach ($db->listTables() as $table) {
                echo "<li><strong>$table</strong></li>";
            }
            echo "</ul>";
            echo "<h3 style='text-align:center; font-size:1.4rem;'>عدد العملاء في الجدول: <strong>" . $db->table('clients')->countAll() . "</strong></h3>";
            echo "<p style='text-align:center; color:#2980b9; margin-top:50px;'>الآن النظام متصل بقاعدة البيانات بنجاح! 🚀</p>";
        } else {
            echo "<h2 style='color:red; text-align:center; direction:rtl;'>❌ فشل الاتصال بقاعدة البيانات</h2>";
            echo "<p style='text-align:center;'>تحققي من الإعدادات في app/Config/Database.php (اسم المستخدم، كلمة السر، اسم القاعدة)</p>";
        }
    }
    
    public function testClients()
    {
        $model = new ClientModel();
        $clients = $model->findAll();
        
        echo "<h2>اختبار عرض جميع العملاء</h2>";
        echo "عدد العملاء: " . count($clients) . "<br><br>";
        
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>ID</th><th>الاسم</th><th>الهاتف</th><th>المبلغ الأساسي</th><th>المسدد</th><th>الحالة</th></tr>";
        
        foreach ($clients as $client) {
            echo "<tr>";
            echo "<td>" . $client['id'] . "</td>";
            echo "<td>" . $client['name'] . "</td>";
            echo "<td>" . $client['phone'] . "</td>";
            echo "<td>" . $client['principal'] . "</td>";
            echo "<td>" . $client['paid'] . "</td>";
            echo "<td>" . $client['status'] . "</td>";
            echo "</tr>";
        }
        
        echo "</table>";
        die();
    }
}